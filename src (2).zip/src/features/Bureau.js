import { createSlice } from "@reduxjs/toolkit";
const initialState = {
  finalScore: 0,
  BureauData: {
    als: undefined,
    ce: undefined,
    cibsrc: undefined,
    es: undefined,
    rhs: undefined,
    tus: undefined,
    wso: undefined,
  },
};

export const BureauSlice = createSlice({
  name: "Bureau",
  initialState,
  reducers: {
    changeValueBureau: (state, action) => {
      // Redux Toolkit allows us to write "mutating" logic in reducers. It
      // doesn't actually mutate the state because it uses the Immer library,
      // which detects changes to a "draft state" and produces a brand new
      // immutable state based off those changes
      if (action.payload.type == "als") {
        state.BureauData = {
          ...state.BureauData,
          als: action.payload.value,
        };
      } else if (action.payload.type == "ce") {
        state.BureauData = {
          ...state.BureauData,
          ce: action.payload.value,
        };
      } else if (action.payload.type == "cibsrc") {
        state.BureauData = {
          ...state.BureauData,
          cibsrc: action.payload.value,
        };
      } else if (action.payload.type == "es") {
        state.BureauData = { ...state.BureauData, es: action.payload.value };
      } else if (action.payload.type == "rhs") {
        state.BureauData = {
          ...state.BureauData,
          rhs: action.payload.value,
        };
      } else if (action.payload.type == "tus") {
        state.BureauData = {
          ...state.BureauData,
          tus: action.payload.value,
        };
      } else if (action.payload.type == "wso") {
        state.BureauData = {
          ...state.BureauData,
          wso: action.payload.value,
        };
      } else if (action.payload.type == "reset") {
        state.BureauData = {
          als: undefined,
          ce: undefined,
          cibsrc: undefined,
          es: undefined,
          rhs: undefined,
          tus: undefined,
          wso: undefined,
        };
      } else {
      }
    },
    decrement: (state) => {
      state.finalScore -= 1;
    },
    incrementByAmount: (state, action) => {
      state.finalScore += action.payload;
    },
  },
});

// Action creators are generated for each case reducer function
export const { changeValueBureau, decrement, incrementByAmount } =
  BureauSlice.actions;

export default BureauSlice.reducer;
