export {default as Navbar} from "./navbar/Navbar"
export {default as SectionScore} from "./sectionScore/SectionScore"