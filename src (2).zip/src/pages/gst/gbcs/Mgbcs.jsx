import React, { useState } from "react";
import { Box } from "@mui/system";
import { Select, MenuItem, OutlinedInput, InputLabel } from "@mui/material";
import FormControl from "@mui/material/FormControl";
import { Button, Typography } from "@mui/material";
import { TextField } from "@mui/material";
import Grid from "@mui/material/Grid";
import { SectionScore } from "../../../composite";
import { bcvMergedData } from "../../../data/gst";
import { useDispatch } from "react-redux";
import { changeValueGst } from "../../../features/gst";
export default function Mgbcs() {
  const [sectionScore, setsectionScore] = useState(0);
  const [bct, setbct] = useState("");
  const [relation, setrelation] = useState("");
  const [number, setNumber] = useState(0);
  let numberofApllicants = 0;
  const dispatch = useDispatch();
  const handleCalculateIcbr = (a) => {
    var str = (bct + relation + a).split(" ").join("");
    console.log(str);
    var score = 0;
    bcvMergedData.map((x) => {
      if (x.value == str) {
        score = x.ccScore;
      }
    });
    setsectionScore(score);
    dispatch(changeValueGst({ value: score, type: "bcs" }));
  };
  const patnerOptions = ["relative of partner", "partner"];
  const plcOptions = ["director", "director and shareholder"];
  const proprietorhsipOptions = ["proprietor", "relative of partner"];
  const publicLimitedOptions = [
    "director",
    "relative of director / shareholder",
  ];
  const BuisnessConstituionType = [
    "proprietorship",
    "public limited",
    "partner",
    "private limited company",
  ];
  // const relations = ["director", "patner"];

  return (
    <>
      <Box
        sx={{
          padding: "0px 10px",
          borderRadius: "10px",
        }}
      >
        <div className="flex">
          <div className="flex-grow">
            <Box sx={{ padding: "0px 0px" }}>
              <Typography
                variant="h7"
                sx={{ fontWeight: 700 }}
              >
                GST | BUSINESS CONSTITUTION SCORE
              </Typography>

              <Box sx={{ marginTop: "0px" }}>
                <Grid container spacing={2}>
                  <Grid item xs={3}>
                    <FormControl sx={{ m: 1, width: "100%" }}>
                      <InputLabel id="demo-multiple-name-label">
                        BC Type
                      </InputLabel>
                      <Select
                        labelId="demo-multiple-name-label"
                        id="demo-multiple-name"
                        value={bct}
                        onChange={(e) => {
                          setbct(e.target.value);
                          setNumber("");
                          handleCalculateIcbr();
                        }}
                        input={<OutlinedInput label="Name" />}
                        // MenuProps={MenuProps}
                      >
                        {BuisnessConstituionType.map((name) => (
                          <MenuItem
                            key={name}
                            value={name}
                            // style={getStyles(name, personName, theme)}
                          >
                            {name}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item xs={3}>
                    <FormControl sx={{ m: 1, width: "100%" }}>
                      <InputLabel id="demo-multiple-name-label">
                        Relation
                      </InputLabel>
                      <Select
                        disabled={bct.length > 0 ? false : true}
                        labelId="demo-multiple-name-label"
                        id="demo-multiple-name"
                        value={relation}
                        onChange={(e) => {
                          setrelation(e.target.value);
                          setNumber("");
                          handleCalculateIcbr();
                        }}
                        input={<OutlinedInput label="Name" />}
                        // MenuProps={MenuProps}
                      >
                        {bct == "partner"
                          ? patnerOptions.map((name) => (
                              <MenuItem
                                key={name}
                                value={name}
                                // style={getStyles(name, personName, theme)}
                              >
                                {name}
                              </MenuItem>
                            ))
                          : bct == "private limited company"
                          ? plcOptions.map((name) => (
                              <MenuItem
                                key={name}
                                value={name}
                                // style={getStyles(name, personName, theme)}
                              >
                                {name}
                              </MenuItem>
                            ))
                          : bct == "proprietorship"
                          ? proprietorhsipOptions.map((name) => (
                              <MenuItem
                                key={name}
                                value={name}
                                // style={getStyles(name, personName, theme)}
                              >
                                {name}
                              </MenuItem>
                            ))
                          : bct == "public limited"
                          ? publicLimitedOptions.map((name) => (
                              <MenuItem
                                key={name}
                                value={name}
                                // style={getStyles(name, personName, theme)}
                              >
                                {name}
                              </MenuItem>
                            ))
                          : ""}
                      </Select>
                    </FormControl>
                  </Grid>

                  <Grid item xs={3}>
                    <FormControl sx={{ m: 1, width: "100%" }}>
                      <TextField
                        type={"number"}
                        label="Number of Applicants"
                        sx={{ width: "100%" }}
                        name="email"
                        value={number}
                        onChange={(e) => {
                          numberofApllicants = e.target.value;
                          setNumber(e.target.value);
                          handleCalculateIcbr(e.target.value);
                        }}
                      />
                    </FormControl>
                  </Grid>
                </Grid>
              </Box>
            </Box>
          </div>
          <div className="score">{sectionScore}</div>
        </div>
      </Box>
    </>
  );
}
