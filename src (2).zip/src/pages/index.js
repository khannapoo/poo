export { default as Login } from "./login/Login";
// export {default as Banking} from "./banking2/Banking"
export { default as Gst } from "./gst/Gst";
export { default as Banking } from "./banking/Banking";
export { default as Mbcds } from "./banking/bcds/Mbcds";
export { default as Mbclur } from "./banking/bclur/Mbclur";
export { default as Mbes } from "./banking/bes/Mbes";
export { default as Mbocbr } from "./banking/bocbr/Mbocbr";
export { default as Micbr } from "./banking/Icbr/Micbr";
export { default as All } from "./all/All";

//  all gst exports
export { default as Mgaos } from "./gst/gaos/Mgaos";
export { default as Mgas } from "./gst/gas/Mgas";
export { default as Mgbcs } from "./gst/gbcs/Mgbcs";
export { default as Mgmgs } from "./gst/gmgs/Mgmgs";
export { default as Mgpis } from "./gst/gpis/Mgpis";
export { default as Mggis } from "./gst/gsis/Mgsis";
export { default as Mgssc } from "./gst/gssc/Mgssc";
export { default as Mgvcs } from "./gst/gvcs/Mgvcs";
export { default as Mgvs } from "./gst/gvs/Mgvs";
// export { default as M } from "./gst/gvcs/Mgvcs";

// export { default as Gstall } from "./gstall/Gstall";
