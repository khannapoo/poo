import React from "react";

export default function Gstall() {
  return <div>Gstall</div>;
}
