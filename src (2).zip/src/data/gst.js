// for primary industry
export const primaryIndustry = [
  {
    value: "Agri and Food",
    secondary: [
      {value:"Animal Products",type:"amber",ccScore:"15"},
      {value:"Bakery",type:"Green",ccScore:"20"},
      {value:"Beer, Wine & Distilled Alcoholic Beverages ",type:"red",ccScore:"10"},
{value:"Bottled Water",type:"Green",ccScore:"20"},
{value:"Cocoa products & confectionery",type:"Green",ccScore:"20"},
{value:"Edible Oils",type:"Green",ccScore:"20"},
{value:"Food & Beverages",type:"Green",ccScore:"20"},
{value:"Food Grains, Seeds",type:"red",ccScore:"10"},
{value:"Food Processing",type:"Green",ccScore:"20"},
{value:"Fruit and nuts",type:"amber",ccScore:"15"},
{value:"Groceries and related products",type:"Green",ccScore:"20"},
{value:"Marine foods",type:"Green",ccScore:"20"},
{value:"Packaged food",type:"Green",ccScore:"20"},
{value:"Poultry, Dairy & Meat",type:"amber",ccScore:"15"},
{value:"Soft Drinks",type:"Green",ccScore:"20"},
{value:"Soya bean products",type:"Green",ccScore:"20"},
{value:"Spices",type:"Green",ccScore:"20"},
{value:"Starches",type:"Green",ccScore:"20"},
{value:"Sugar",type:"Green",ccScore:"20"},
{value:"Tobacco Products",type:"Green",ccScore:"20"},
{value:"Vegetables",type:"Green",ccScore:"20"},
   ],
  },
  {
    value: "Automobile",
    secondary: [
      {value:"2 and 3 Wheelers",type:"Amber",ccScore:"15"},
{value:"Auto Ancillaries",type:"amber",ccScore:"15"},
{value:"Auto Design",type:"amber",ccScore:"15"},
{value:"Cycle & Spare Parts &  Accessories",type:"Green",ccScore:"20"},
{value:"LCVs/ HCVs (Commercial Vehicles)",type:"red",ccScore:"10"},
{value:"Passenger Cars",type:"red",ccScore:"10"},
{value:"Tractors",type:"red",ccScore:"10"},
{value:"Tyres ",type:"amber",ccScore:"15"},
    ],
  },
  {
    value: "Books, Office Supplies & Stationery",
    secondary: [
      {value:"Books, Office Supplies & Stationery",type:"Green",ccScore:"20"},
    ],
  },
  {
    value: "Cement",
    secondary: [
      {value:"Cement products & asbestos products",type:"amber",ccScore:"15"},
    ],
  },
  {
    value: "Commission Agents",
    secondary: [
      {value:"Commission agents",type:"amber",ccScore:"15"},
    ],
  },
  {
    value: "Construction",
    secondary: [
    {value:"Builders, Construction Contractors",type:"Red",ccScore:"10"},
    {value:"Ceramic Tiles & Sanitaryware",type:"amber",ccScore:"15"},
    {value:"Construction Equipment(Cranes etc)",type:"red",ccScore:"10"},
    {value:"Construction Materials",type:"red",ccScore:"10"},
    ],
  },

  {
    value: "Containers & Packaging",
    secondary: [
      {value:"Packaging",type:"Green",ccScore:"20"},
    ],
  },
  {
    value: "Contraceptives",
    secondary: [
      {value:"Contraceptives",type:"Green",ccScore:"20"},
    ],
  },
  {
    value: "Contractor",
    secondary: [
      {value:"Equipment Contractor",type:"amber",ccScore:"15"},
      {value:"Labour Contractor",type:"amber",ccScore:"15"},
      {value:"Security guards , Office staff",type:"amber",ccScore:"15"},
    ],
  },
  {
    value: "Durables",
    secondary: [
      {value:"Electrical Goods ( Incl  Invertor ) ",type:"Green",ccScore:"20"},
      {value:"Hardware, Plumbing & Heating Equipment",type:"Green",ccScore:"20"},
      {value:"Professional & Commercial Equipment",type:"Green",ccScore:"20"},
    ],
  }, 

  {
    value: "Energy",
    secondary: [
      {value:"Refineries",type:"amber",ccScore:"15"},
    ],
  }, 

  {
    value: "Entertainment & Leisure",
    secondary: [
      {value:"Hotels & Restaurants",type:"amber",ccScore:"15"},
    {value:"Recreation & Amusement Parks",type:"amber",ccScore:"15"},
    {value:"Travel Services",type:"red",ccScore:"10"},
    ],
  }, 

  {
    value: "Entertainment & Leisure",
    secondary: [
      {value:"Hotels & Restaurants",type:"amber",ccScore:"15"},
    {value:"Recreation & Amusement Parks",type:"amber",ccScore:"15"},
    {value:"Travel Services",type:"red",ccScore:"10"},
    ],
  }, 
  {
    value: "Fabricators",
    secondary: [
      {value:"Steel & Other Fabricator",type:"amber",ccScore:"15"},
    ],
  }, 
  {
    value: "Financial Services",
    secondary: [
      {value:"Asset Management",type:"red",ccScore:"10"},
      {value:"Banking",type:"red",ccScore:"10"},
      {value:"Collection Agencies",type:"red",ccScore:"10"},
      {value:"Direct Sales  Associates",type:"red",ccScore:"10"},
      {value:"Field verification RCU agencies",type:"red",ccScore:"10"},
      {value:"Insurance",type:"red",ccScore:"10"},
      {value:"NBFC",type:"red",ccScore:"10"},
      {value:"Recovery Agencies",type:"red",ccScore:"10"},
      ],
  }, 

  {
    value: "FMCG & Household Products",
    secondary: [
      {value:"Detergents & Intermediates",type:"Green",ccScore:"20"},
      {value:"Dry Cells",type:"Green",ccScore:"20"},
      {value:"Electronic Equipment",type:"Green",ccScore:"20"},
      {value:"FMCG",type:"Green",ccScore:"20"},
      {value:"Personal Care",type:"Green",ccScore:"20"},
      ],
  }, 
  {
    value: "Glass Products",
    secondary: [
      {value:"Glass & Glass Products",type:"Green",ccScore:"20"},
      ],
  }, 
  {
    value: "Handicrafts & Artificial Items",
    secondary: [
      {value:"Handicrafts",type:"Green",ccScore:"20"},
      {value:"Imitation Jewellery",type:"amber",ccScore:"15"},
    ],
  }, 
  {
    value: "Hardware Equipment",
    secondary: [
      {value:"Networking",type:"Green",ccScore:"20"},
      {value:"Office Equipment",type:"Green",ccScore:"20"},
      {value:"Sanitary , Lighting , Decorative Items",type:"Green",ccScore:"20"},  
    ],
  }, 

  {
    value: "HealthCare",
    secondary: [
      {value:"Diagnostic Centers",type:"Green",ccScore:"20"},
      {value:"DRUGS & PHARMACEUTICALS,DRUG PROPRIETARIES & DRUGGISTS",type:"Green",ccScore:"20"},
      {value:"Hospitals",type:"Green",ccScore:"20"},
      {value:"Medical Equipment",type:"Green",ccScore:"20"},
      {value:"Medical Supplies",type:"Green",ccScore:"20"},
    ],
  }, 

  {
    value: "Hobby, Toy, Game, Camera & Photographic Supply Stores",
    secondary: [
      {value:"Hobby, Toy, Game, Camera & Photographic Supply Stores ",type:"Green",ccScore:"20"},
    ],
  }, 

  {
    value: "Home Furniture & Furnishing",
    secondary: [
      {value:"Home Furniture & Furnishing",type:"amber",ccScore:"15"},
    ],
  }, 

  {
    value: "Industrial equipment",
    secondary: [
      {value:"Abrasives & Grinding",type:"Green",ccScore:"20"},
      {value:"Bearings",type:"Green",ccScore:"20"},
      {value:"Compressors, Motors & Generators",type:"Green",ccScore:"20"},
      {value:"Electrical Equipments",type:"Green",ccScore:"20"},
      {value:"Electrodes Graphite",type:"Green",ccScore:"20"},
      {value:"Engineering",type:"Green",ccScore:"20"},
      {value:"Engines",type:"Green",ccScore:"20"},
      {value:"Fasteners",type:"Green",ccScore:"20"},
      {value:"Industrial furnaces",type:"Green",ccScore:"20"},
      {value:"Industrial machinery (excl. chem. & text.)",type:"Green",ccScore:"20"},
      {value:"Industrial machinery- chemical and textiles",type:"Green",ccScore:"20"},
      {value:"Machine Tools",type:"Green",ccScore:"20"},
      {value:"Material handling equipments",type:"Green",ccScore:"20"},
      {value:"Motors & generators",type:"Green",ccScore:"20"},
      {value:"Prime movers",type:"Green",ccScore:"20"},
      {value:"Printing machinery",type:"Green",ccScore:"20"},
      {value:"Pumps",type:"Green",ccScore:"20"},
      {value:"Storage Batteries",type:"Green",ccScore:"20"},
      {value:"Structural Analysis",type:"Green",ccScore:"20"},
      {value:"Switching apparatus",type:"Green",ccScore:"20"},
      {value:"Textiles Machinery",type:"Green",ccScore:"20"},
      {value:"Transformers",type:"Green",ccScore:"20"},
      {value:"Transmission Line Towers & Equipment",type:"Green",ccScore:"20"},
      {value:"Turnkey Services",type:"Green",ccScore:"20"},
      {value:"Valves+B21",type:"Green",ccScore:"20"},
      {value:"Welding machinery",type:"Green",ccScore:"20"},    
    ],
  },  

  {
    value: "Institutions & Trusts",
    secondary: [
      {value:"Coaching Classes",type:"amber",ccScore:"15"},
      {value:"Schools & Colleges",type:"red",ccScore:"10"},
    ],
  }, 

  {
    value: "IT",
    secondary: [
      {value:"Computer - Education",type:"amber",ccScore:"15"},
      {value:"Computer - Software",type:"amber",ccScore:"15"},
      {value:"Computers(Hardware) & Electronics",type:"amber",ccScore:"15"},
      {value:"ERP",type:"Green",ccScore:"20"},
      {value:"ITES/ Call Centers",type:"red",ccScore:"10"},
    ],
  }, 
  
  {
    value: "Jewellery",
    secondary: [
      {value:"Gems & Jewellery",type:"red",ccScore:"10"},
    ],
  }, 

  {
    value: "Kirana",
    secondary: [
      {value:"General Merchandise Stores",type:"Green",ccScore:"20"},
    ],
  }, 

  {
    value: "Leather Footwear",
    secondary: [
      {value:"Leather Footwear",type:"Green",ccScore:"20"},
    ],
  }, 

  {
    value: "Luggage & Leather Goods",
    secondary: [
      {value:"Luggage & Leather Goods",type:"Green",ccScore:"20"},
    ],
  }, 

  {
    value: "Media",
    secondary: [
      {value:"Advertising",type:"Amber",ccScore:"15"},
      {value:"Broadcasting",type:"Green",ccScore:"20"},
      {value:"Cable and other pay television services",type:"Red",ccScore:"10"},
      {value:"Post Production & Animation",type:"Green",ccScore:"20"},
      {value:"Publishing",type:"Green",ccScore:"20"},
    ],
  }, 

  {
    value: "Metal & Mining",
    secondary: [
      {value:"Aluminum & Aluminum Products(manufacturer)",type:"Red",ccScore:"10"},
      {value:"Castings & forgings",type:"Red",ccScore:"10"},
      {value:"Coal and Lignite",type:"amber",ccScore:"15"},
      {value:"Copper & copper products",type:"amber",ccScore:"15"},
      {value:"Crude Oil and natural gas",type:"red",ccScore:"10"},
      {value:"Ferro alloys",type:"amber",ccScore:"15"},
      {value:"Ferrous metals",type:"amber",ccScore:"15"},
      {value:"Granite & other Non-Metal minerals",type:"amber",ccScore:"15"},
      {value:"Metal Products (other than Steel, Aluminium and Copper)",type:"amber",ccScore:"15"},
      {value:"Minerals",type:"amber",ccScore:"15"},
      {value:"Non-ferrous metals",type:"amber",ccScore:"15"},
      {value:"Pig iron",type:"amber",ccScore:"15"},
      {value:"Stainless Steel",type:"NULL",ccScore:"0"},
      {value:"Steel tubes & pipes",type:"amber",ccScore:"15"},
      {value:"Steel wires",type:"amber",ccScore:"15"},
      {value:"Wires and Cables",type:"amber",ccScore:"15"},      
    ],
  }, 

  {
    value: "Mobile Business",
    secondary: [
      {value:"Mobile Trading / Service Centre",type:"red",ccScore:"10"},
      {value:"Recharges Coupon",type:"red",ccScore:"10"},   
    ],
  }, 

  {
    value: "Opticians",
    secondary: [
      {value:"Opticians",type:"Green",ccScore:"20"},
    ],
  }, 

  {
    value: "Other Leather products",
    secondary: [
      {value:"Other Leather products",type:"Green",ccScore:"20"},
    ],
  }, 

  {
    value: "Paper",
    secondary: [
      {value:"Paper and Paper Products",type:"amber",ccScore:"15"},
    ],
  }, 

  {
    value: "Pens and Pencils",
    secondary: [
      {value:"Pens and Pencils",type:"Green",ccScore:"20"},
    ],
  }, 

  {
    value: "Petroleum, Plastics & Chemicals",
    secondary: [
      {value:"Alkalis",type:"Amber",ccScore:"15"},
      {value:"Carbon black",type:"amber",ccScore:"15"},
      {value:"Caustic Soda",type:"Green",ccScore:"20"},
      {value:"Dyes and pigments",type:"Green",ccScore:"20"},
      {value:"Fertilizers (all categories)",type:"Green",ccScore:"20"},
      {value:"Industrial Gases",type:"Green",ccScore:"20"},
      {value:"Inorganic chemicals ( Not defined elsewhere)",type:"Green",ccScore:"20"},
      {value:"Organic Chemicals ( Not defined elsewhere)",type:"Green",ccScore:"20"},
      {value:"Other Chemicals",type:"Green",ccScore:"20"},
      {value:"Paints & Varnishes",type:"Green",ccScore:"20"},
      {value:"Paints Equipment",type:"Green",ccScore:"20"},
      {value:"Pesticides",type:"Green",ccScore:"20"},
      {value:"Petrochemicals",type:"Green",ccScore:"20"},
      {value:"Petrol, Diesel sale",type:"amber",ccScore:"15"},
      {value:"Petroleum Products",type:"amber",ccScore:"15"},
      {value:"Photographic & Allied Products",type:"Green",ccScore:"20"},
      {value:"Plastic Films",type:"Green",ccScore:"20"},
      {value:"Plastic packaging goods",type:"Green",ccScore:"20"},
      {value:"Plastic resins",type:"Green",ccScore:"20"},
      {value:"Plastic tubes & sheets, other plastic products",type:"Green",ccScore:"20"},
      {value:"Polymers",type:"Green",ccScore:"20"},
      {value:"Refractories & Intermediates",type:"NULL",ccScore:"0"},
      {value:"Thermoplastics",type:"Green",ccScore:"20"},
    ],
  },   

  {
    value: "Professional",
    secondary: [
      {value:"Doctor , Engineer , CA",type:"Green",ccScore:"20"},
    ],
  },   

  {
    value: "Rubber",
    secondary: [
      {value:"Rubber & rubber products",type:"Green",ccScore:"20"},
    ],
  },   

  
  {
    value: "Services",
    secondary: [
      {value:"Automatic Merchandising Machine Operators",type:"Green",ccScore:"20"},
      {value:"Catalog & Mail-order Houses",type:"Green",ccScore:"20"},
      {value:"Consultants",type:"Green",ccScore:"20"},
      {value:"Direct Selling Establishments",type:"Green",ccScore:"20"},
      {value:"Education Consulting",type:"Green",ccScore:"20"},
      {value:"Entertainment and media content provider",type:"Green",ccScore:"20"},
      {value:"Executive Search",type:"Green",ccScore:"20"},
      {value:"Hair Saloon & Parlors",type:"Green",ccScore:"20"},
      {value:"HR and Medical transcription",type:"Green",ccScore:"20"},
      {value:"Industrial Services",type:"Green",ccScore:"20"},
      {value:"Internet Services",type:"red",ccScore:"10"},
      {value:"IT Consulting",type:"Green",ccScore:"20"},
      {value:"Legal Services (solicitor firms)",type:"red",ccScore:"10"},
      {value:"Motion Picture production, distribution and exhibition",type:"Green",ccScore:"20"},
      {value:"Other communication services (wireless services, telex services, fax services, pager services, other telephone services, other communication services)",type:"Green",ccScore:"20"},
      {value:"Professionals ",type:"Green",ccScore:"20"},
      {value:"Public Relations",type:"Green",ccScore:"20"},
      {value:"Technical consultancy and engineering services",type:"Green",ccScore:"20"},
      {value:"Telephone communication services",type:"amber",ccScore:"15"},
      {value:"Water transport(Shipping Companies)",type:"Green",ccScore:"20"},
    ],
  },   

  {
    value: "Sports Goods",
    secondary: [
      {value:"Sports Goods",type:"Green",ccScore:"20"},
    ],
  },   
  {
    value: "Textiles",
    secondary: [
      {value:"Blended yarn",type:"amber",ccScore:"15"},
      {value:"Readymade Garments",type:"amber",ccScore:"15"},
      {value:"Textiles - Cotton",type:"amber",ccScore:"15"},
      {value:"Textiles - Silk",type:"amber",ccScore:"15"},
      {value:"Textiles - Synthetic",type:"amber",ccScore:"15"},
      {value:"Textiles (Other than Cotton, Jute & Yarn, Silk and Synthetic)",type:"amber",ccScore:"15"},
      {value:"Woolen Textiles",type:"amber",ccScore:"15"},
    ],
  },   

  {
    value: "Transportation & Logistics",
    secondary: [
      {value:"CLEARING & FORWARDING AGENTS",type:"Green",ccScore:"20"},
      {value:"Courier",type:"Green",ccScore:"20"},
      {value:"Goods Transport Services (Road)",type:"Green",ccScore:"20"},
      {value:"Land Transportation Equipment",type:"Green",ccScore:"20"},
      {value:"Passenger Transport Services (Road)",type:"Green",ccScore:"20"},
      {value:"Storage & Warehousing",type:"Green",ccScore:"20"},   
    ],
  },   

  {
    value: "Wood and wood products",
    secondary: [
      {value:"Wood and wood products",type:"amber",ccScore:"15"},
    ],
  }, 
];

//  for secondary industry
export const secondaryIndustry = [
  {
    value: "Agri & Food",
    secondary: [
        {value:"Animal Products",type:"amber",ccScore:"10"},
        {value:"Bakery",type:"Green",ccScore:"20"},
        {value:"Beer, Wine & Distilled Alcoholic Beverages ",type:"red",ccScore:"0"},
        {value:"Bottled Water",type:"Green",ccScore:"20"},
        {value:"Cocoa products & confectionery",type:"Green",ccScore:"20"},
        {value:"Edible Oils",type:"Green",ccScore:"20"},
        {value:"Food & Beverages",type:"Green",ccScore:"20"},
        {value:"Food Grains, Seeds",type:"red",ccScore:"0"},
        {value:"Food Processing",type:"Green",ccScore:"20"},
        {value:"Fruit and nuts",type:"amber",ccScore:"10"},
        {value:"Groceries and related products",type:"Green",ccScore:"20"},
        {value:"Marine foods",type:"Green",ccScore:"20"},
        {value:"Packaged food",type:"Green",ccScore:"20"},
        {value:"Poultry, Dairy & Meat",type:"amber",ccScore:"10"},
        {value:"Soft Drinks",type:"Green",ccScore:"20"},
        {value:"Soya bean products",type:"Green",ccScore:"20"},
        {value:"Spices",type:"Green",ccScore:"20"},
        {value:"Starches",type:"Green",ccScore:"20"},
        {value:"Sugar",type:"Green",ccScore:"20"},
        {value:"Tobacco Products",type:"Green",ccScore:"20"},
        {value:"Vegetables",type:"Green",ccScore:"20"},        
      ],
    },

    {
      value: "Automobiles",
      secondary: [
        {value:"2 and 3 Wheelers",type:"Amber",ccScore:"10"},
        {value:"Auto Ancillaries",type:"amber",ccScore:"10"},
        {value:"Auto Design",type:"amber",ccScore:"10"},
        {value:"Cycle & Spare Parts &  Accessories",type:"Green",ccScore:"20"},
        {value:"LCVs/ HCVs (Commercial Vehicles)",type:"red",ccScore:"0"},
        {value:"Passenger Cars",type:"red",ccScore:"0"},
        {value:"Tractors",type:"red",ccScore:"0"},
        {value:"Tyres ",type:"amber",ccScore:"10"},       
        ],
      },
      {
        value: "Books, Office Supplies & Stationery",
        secondary: [
          {value:"Books, Office Supplies & Stationery",type:"Green",ccScore:"20"},
        ],
      },
      
      {
        value: "Cement",
        secondary: [
          {value:"Cement products & asbestos products",type:"amber",ccScore:"10"},
        ],
      },
      
      {
        value: "Commission Agents",
        secondary: [
          {value:"Commission agents",type:"amber",ccScore:"10"},
        ],
      },
      
      
      {
        value: "Construction",
        secondary: [
          {value:"Builders, Construction Contractors",type:"Red",ccScore:"0"},
          {value:"Ceramic Tiles & Sanitaryware",type:"amber",ccScore:"10"},
          {value:"Construction Equipment(Cranes etc)",type:"red",ccScore:"0"},
          {value:"Construction Materials",type:"red",ccScore:"0"},        
        ],
      },

      {
        value: "Containers & Packaging",
        secondary: [
          {value:"Packaging",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Contraceptives",
        secondary: [
          {value:"Contraceptives",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Contractor",
        secondary: [
          {value:"Equipment Contractor",type:"amber",ccScore:"10"},
          {value:"Labour Contractor",type:"amber",ccScore:"10"},
          {value:"Security guards , Office staff",type:"amber",ccScore:"10"},
        ],
      },
      
      {
        value: "Durables",
        secondary: [
          {value:"Electrical Goods ( Incl  Invertor ) ",type:"Green",ccScore:"20"},
          {value:"Hardware, Plumbing & Heating Equipment",type:"Green",ccScore:"20"},
          {value:"Professional & Commercial Equipment",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Energy",
        secondary: [
          {value:"Refineries",type:"amber",ccScore:"10"},
        ],
      },

      {
        value: "Entertainment & Leisure",
        secondary: [
          {value:"Hotels & Restaurants",type:"amber",ccScore:"10"},
          {value:"Recreation & Amusement Parks",type:"amber",ccScore:"10"},
          {value:"Travel Services",type:"red",ccScore:"0"},
        ],
      },

      {
        value: "Fabricators",
        secondary: [
          {value:"Steel & Other Fabricator",type:"amber",ccScore:"10"},
        ],
      },

      {
        value: "Financial Services",
        secondary: [
          {value:"Asset Management",type:"red",ccScore:"0"},
          {value:"Banking",type:"red",ccScore:"0"},
          {value:"Collection Agencies",type:"red",ccScore:"0"},
          {value:"Direct Sales  Associates",type:"red",ccScore:"0"},
          {value:"Field verification RCU agencies",type:"red",ccScore:"0"},
          {value:"Insurance",type:"red",ccScore:"0"},
          {value:"NBFC",type:"red",ccScore:"0"},
          {value:"Recovery Agencies",type:"red",ccScore:"0"}, 
        ],
      },

      {
        value: "FMCG & Household Products",
        secondary: [
          {value:"Detergents & Intermediates",type:"Green",ccScore:"20"},
          {value:"Dry Cells",type:"Green",ccScore:"20"},
          {value:"Electronic Equipment",type:"Green",ccScore:"20"},
          {value:"FMCG",type:"Green",ccScore:"20"},
          {value:"Personal Care",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Glass Products",
        secondary: [
          {value:"Glass & Glass Products",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Handicrafts & Artificial Items",
        secondary: [
          {value:"Handicrafts",type:"Green",ccScore:"20"},
          {value:"Imitation Jewellery",type:"amber",ccScore:"10"},
        ],
      },

      {
        value: "Hardware Equipment  ",
        secondary: [
          {value:"Networking",type:"Green",ccScore:"20"},
          {value:"Office Equipment",type:"Green",ccScore:"20"},
          {value:"Sanitary , Lighting , Decorative Items",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "HealthCare",
        secondary: [
          {value:"Diagnostic Centers",type:"Green",ccScore:"20"},
          {value:"DRUGS & PHARMACEUTICALS,DRUG PROPRIETARIES & DRUGGISTS",type:"Green",ccScore:"20"},
          {value:"Hospitals",type:"Green",ccScore:"20"},
          {value:"Medical Equipment",type:"Green",ccScore:"20"},
          {value:"Medical Supplies",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Hobby, Toy, Game, Camera & Photographic Supply Stores",
        secondary: [
          {value:"Hobby, Toy, Game, Camera & Photographic Supply Stores ",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Home Furniture & Furnishing",
        secondary: [
          {value:"Home Furniture & Furnishing",type:"amber",ccScore:"10"},
        ],
      },

      {
        value: "Industrial equipment",
        secondary: [
          {value:"Abrasives & Grinding",type:"Green",ccScore:"20"},
          {value:"Bearings",type:"Green",ccScore:"20"},
          {value:"Compressors, Motors & Generators",type:"Green",ccScore:"20"},
          {value:"Electrical Equipments",type:"Green",ccScore:"20"},
          {value:"Electrodes Graphite",type:"Green",ccScore:"20"},
{value:"Engineering",type:"Green",ccScore:"20"},
{value:"Engines",type:"Green",ccScore:"20"},
{value:"Fasteners",type:"Green",ccScore:"20"},
{value:"Industrial furnaces",type:"Green",ccScore:"20"},
{value:"Industrial machinery (excl. chem. & text.)",type:"Green",ccScore:"20"},
{value:"Industrial machinery- chemical and textiles",type:"Green",ccScore:"20"},
{value:"Machine Tools",type:"Green",ccScore:"20"},
{value:"Material handling equipments",type:"Green",ccScore:"20"},
{value:"Motors & generators",type:"Green",ccScore:"20"},
{value:"Prime movers",type:"Green",ccScore:"20"},
{value:"Printing machinery",type:"Green",ccScore:"20"},
{value:"Pumps",type:"Green",ccScore:"20"},
{value:"Storage Batteries",type:"Green",ccScore:"20"},
{value:"Structural Analysis",type:"Green",ccScore:"20"},
{value:"Switching apparatus",type:"Green",ccScore:"20"},
{value:"Textiles Machinery",type:"Green",ccScore:"20"},
{value:"Transformers",type:"Green",ccScore:"20"},
{value:"Transmission Line Towers & Equipment",type:"Green",ccScore:"20"},
{value:"Turnkey Services",type:"Green",ccScore:"20"},
{value:"Valves+B21",type:"Green",ccScore:"20"},
{value:"Welding machinery",type:"Green",ccScore:"20"},
        ],
      },
     
      {
        value: "Institutions & Trusts",
        secondary: [
          {value:"Coaching Classes",type:"amber",ccScore:"10"},
          {value:"Schools & Colleges",type:"red",ccScore:"0"},
        ],
      },

      {
        value: "IT",
        secondary: [
          {value:"Computer - Education",type:"amber",ccScore:"10"},
          {value:"Computer - Software",type:"amber",ccScore:"10"},
          {value:"Computers(Hardware) & Electronics",type:"amber",ccScore:"10"},
          {value:"ERP",type:"Green",ccScore:"20"},
          {value:"ITES/ Call Centers",type:"red",ccScore:"0"},
        ],
      },

      {
        value: "Jewellery",
        secondary: [
          {value:"Gems & Jewellery",type:"red",ccScore:"0"},
        ],
      },


      {
        value: "Kirana  ",
        secondary: [
          {value:"General Merchandise Stores",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Leather Footwear",
        secondary: [
          {value:"Leather Footwear",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Luggage & Leather Goods",
        secondary: [
          {value:"Luggage & Leather Goods",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Media",
        secondary: [
          {value:"Advertising",type:"Amber",ccScore:"10"},
          {value:"Broadcasting",type:"Green",ccScore:"20"},
          {value:"Cable and other pay television services",type:"Red",ccScore:"0"},
          {value:"Post Production & Animation",type:"Green",ccScore:"20"},
          {value:"Publishing",type:"Green",ccScore:"20"},
       ],
      },

      {
        value: "Metal & Mining",
        secondary: [
          {value:"Aluminum & Aluminum Products(manufacturer)",type:"Red",ccScore:"0"},
          {value:"Castings & forgings",type:"Red",ccScore:"0"},
          {value:"Coal and Lignite",type:"amber",ccScore:"10"},
          {value:"Copper & copper products",type:"amber",ccScore:"10"},
          {value:"Crude Oil and natural gas",type:"red",ccScore:"0"},
          {value:"Ferro alloys",type:"amber",ccScore:"10"},
          {value:"Ferrous metals",type:"amber",ccScore:"10"},
          {value:"Granite & other Non-Metal minerals",type:"amber",ccScore:"10"},
          {value:"Metal Products (other than Steel, Aluminium and Copper)",type:"amber",ccScore:"10"},
          {value:"Minerals",type:"amber",ccScore:"10"},
          {value:"Non-ferrous metals",type:"amber",ccScore:"10"},
          {value:"Pig iron",type:"amber",ccScore:"10"},
          {value:"Steel tubes & pipes",type:"amber",ccScore:"10"},
          {value:"Steel wires",type:"amber",ccScore:"10"},
          {value:"Wires and Cables",type:"amber",ccScore:"10"},
        ],
      },

      {
        value: "Mobile Business",
        secondary: [
          {value:"Mobile Trading / Service Centre",type:"red",ccScore:"0"},
          {value:"Recharges Coupon",type:"red",ccScore:"0"},
        ],
      },

      
      {
        value: "Opticians",
        secondary: [
          {value:"Opticians",type:"Green",ccScore:"20"},
        ],
      },


      {
        value: "Other Leather products",
        secondary: [
          {value:"Other Leather products",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Paper",
        secondary: [
          {value:"Paper and Paper Products",type:"amber",ccScore:"10"},
        ],
      },

      {
        value: "Pens and Pencils",
        secondary: [
          {value:"Pens and Pencils",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Petroleum, Plastics & Chemicals",
        secondary: [
          {value:"Alkalis",type:"Amber",ccScore:"10"},
          {value:"Carbon black",type:"amber",ccScore:"10"},
          {value:"Caustic Soda",type:"Green",ccScore:"20"},
          {value:"Dyes and pigments",type:"Green",ccScore:"20"},
          {value:"Fertilizers (all categories)",type:"Green",ccScore:"20"},
          {value:"Industrial Gases",type:"Green",ccScore:"20"},
          {value:"Inorganic chemicals ( Not defined elsewhere)",type:"Green",ccScore:"20"},
          {value:"Organic Chemicals ( Not defined elsewhere)",type:"Green",ccScore:"20"},
          {value:"Other Chemicals",type:"Green",ccScore:"20"},
          {value:"Paints & Varnishes",type:"Green",ccScore:"20"},
          {value:"Paints Equipment",type:"Green",ccScore:"20"},
          {value:"Pesticides",type:"Green",ccScore:"20"},
          {value:"Petrochemicals",type:"Green",ccScore:"20"},
          {value:"Petrol, Diesel sale",type:"amber",ccScore:"10"},
          {value:"Petroleum Products",type:"amber",ccScore:"10"},
          {value:"Photographic & Allied Products",type:"Green",ccScore:"20"},
          {value:"Plastic Films",type:"Green",ccScore:"20"},
          {value:"Plastic packaging goods",type:"Green",ccScore:"20"},
          {value:"Plastic resins",type:"Green",ccScore:"20"},
          {value:"Plastic tubes & sheets, other plastic products",type:"Green",ccScore:"20"},
          {value:"Polymers",type:"Green",ccScore:"20"},
          {value:"Thermoplastics",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Professional",
        secondary: [
          {value:"Doctor , Engineer , CA",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Rubber",
        secondary: [
          {value:"Rubber & rubber products",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Services",
        secondary: [
          {value:"Automatic Merchandising Machine Operators",type:"Green",ccScore:"20"},
          {value:"Catalog & Mail-order Houses",type:"Green",ccScore:"20"},
          {value:"Consultants",type:"Green",ccScore:"20"},
          {value:"Direct Selling Establishments",type:"Green",ccScore:"20"},
          {value:"Education Consulting",type:"Green",ccScore:"20"},
          {value:"Entertainment and media content provider",type:"Green",ccScore:"20"},
          {value:"Executive Search",type:"Green",ccScore:"20"},
          {value:"Hair Saloon & Parlors",type:"Green",ccScore:"20"},
          {value:"HR and Medical transcription",type:"Green",ccScore:"20"},
          {value:"Industrial Services",type:"Green",ccScore:"20"},
          {value:"Internet Services",type:"red",ccScore:"0"},
          {value:"IT Consulting",type:"Green",ccScore:"20"},
          {value:"Legal Services (solicitor firms)",type:"red",ccScore:"0"},
          {value:"Motion Picture production, distribution and exhibition",type:"Green",ccScore:"20"},
          {value:"Other communication services (wireless services, telex services, fax services, pager services, other telephone services, other communication services)",type:"Green",ccScore:"20"},
          {value:"Professionals ",type:"Green",ccScore:"20"},
          {value:"Public Relations",type:"Green",ccScore:"20"},
          {value:"Technical consultancy and engineering services",type:"Green",ccScore:"20"},
          {value:"Telephone communication services",type:"amber",ccScore:"10"},
          {value:"Water transport(Shipping Companies)",type:"Green",ccScore:"20"},
       ],
      },

      {
        value: "Sports Goods",
        secondary: [
          {value:"Sports Goods",type:"Green",ccScore:"20"},
        ],
      },

      {
        value: "Textiles",
        secondary: [
          {value:"Blended yarn",type:"amber",ccScore:"10"},
          {value:"Readymade Garments",type:"amber",ccScore:"10"},
          {value:"Textiles - Cotton",type:"amber",ccScore:"10"},
          {value:"Textiles - Silk",type:"amber",ccScore:"10"},
          {value:"Textiles - Synthetic",type:"amber",ccScore:"10"},
          {value:"Textiles (Other than Cotton, Jute & Yarn, Silk and Synthetic)",type:"amber",ccScore:"10"},
          {value:"Woolen Textiles",type:"amber",ccScore:"10"},
        ],
      },

      {
        value: "Transportation & Logistics",
        secondary: [
          {value:"CLEARING & FORWARDING AGENTS",type:"Green",ccScore:"20"},
          {value:"Courier",type:"Green",ccScore:"20"},
          {value:"Goods Transport Services (Road)",type:"Green",ccScore:"20"},
          {value:"Land Transportation Equipment",type:"Green",ccScore:"20"},
          {value:"Passenger Transport Services (Road)",type:"Green",ccScore:"20"},
          {value:"Storage & Warehousing",type:"Green",ccScore:"20"},
        ],
      },


      {
        value: "Wood and wood products",
        secondary: [
          {value:"Wood and wood products",type:"amber",ccScore:"10"},
        ],
      },
  ];
  
export const bcvMergedData = [
  { value: "publiclimiteddirector2", category: "B", ccScore: 30 },
  { value: "publiclimiteddirector1", category: "D", ccScore: 20 },
  { value: "patnerpatner0", category: "D", ccScore: 20 },
  { value: "patnerrelativeofpatner0", category: "C", ccScore: 30 },
  { value: "privatelimitedcompanydirector2", category: "B", ccScore: 30 },
  { value: "privatelimitedcompanydirector1", category: "D", ccScore: 20 },
  {
    value: "privatelimitedcompanydirectorandshareholder0",
    category: "E",
    ccScore: 10,
  },
  { value: "proprietorshiprelativeofpartner0", category: "E", ccScore: 10 },
  { value: "proprietorshipproprietor1", category: "A", ccScore: 30 },
  { value: "proprietorshipproprietor2", category: "A", ccScore: 30 },
  { value: "proprietorshipproprietor0", category: "E", ccScore: 10 },
  { value: "publiclimiteddirector2", category: "B", ccScore: 30 },
  { value: "publiclimiteddirector1", category: "D", ccScore: 20 },
  {
    value: "publiclimitedrelativeofdirector/shareholder0",
    category: "E",
    ccScore: 10,
  },
];

export const addressMergedData = [
  { value: "permanentselfownedgodown/factory", ccScore: 50 },
  { value: "currentselfownedgodown/factory", ccScore: 0 },
  { value: "permanentselfownedpromotersresidenceaddress", ccScore: 30 },
  { value: "currentselfownedpromotersresidenceaddress", ccScore: 0 },
];
