# import json
# import datetime
# import pandas as pd
# from collections import OrderedDict
# #
# # def append_statistics(filepath):
# #
# #     with open(filepath, 'r') as fp:
# #         information = json.load(fp)
# #
# #     print(information.keys)
# #
# #     # with open(filepath, 'w') as fp:
# #     #     json.dump(information, fp, indent=2)
# #
# # append_statistics(r"C:\Users\shethd\OneDrive - Dun and Bradstreet\Project_Document\DataIngestion\GDO\UnifiedUnity\GeneralSection.json")
# finaldict = []
# dfgeneral = pd.read_csv(r"C:\Users\shethd\OneDrive - Dun and Bradstreet\Project_Document\DataIngestion\GDO\UnifiedUnity\Relcn_Non_loop_All_4746fa0afb6845739494b18470a93b7c.csv")
# dfgeneral.fillna("")
#
# # print(dfgeneral)
# for (index, row) in dfgeneral.iterrows():
#
#     mydict = {k: v for k, v in
#               (('id', str(dfgeneral.at[index, "duns_no"])), ('Action', {"IfExists": "Update", "IfNotExists": "Skip"}
#                                                              ), ('UpdateDate', "<TD>"), ("Country", 356))}
#     # readiness of the columns
#     rowrequired = pd.DataFrame(row).T.iloc[:,1:-1]
#     rowrequired.columns = [item.rsplit('_', 1)[1] for item in rowrequired.columns.to_list()]
#     rowrequired.columns = [item.rsplit(':', 1)[1] for item in rowrequired.columns.to_list()]
#     mydict["Sections"] = []
#
#     sectiondict = OrderedDict()
#     sectiondict["Name"] = dfgeneral.at[index, "SheetName"]
#     sectiondict["SectionLoops"] = []
#
#     SectionLoopsdict = OrderedDict()
#     SectionLoopsdict["FieldSets"] = []
#
#     FieldSetsdict = {}
#     FieldSetsdict["FieldSetId"] = -1
#     FieldSetsdict["FieldSetLoops"] = []
#
#     FieldSetLoopsdict = OrderedDict()
#     FieldSetLoopsdict["Index"] = 0
#     Fields=[]
#     #     print(colname.str.split("_")[1])
#     for (columnName, columnData) in rowrequired.iteritems():
#         Fields.append({columnName:str(columnData.iat[0])})
#
#     FieldSetLoopsdict["Fields"] = Fields
#     FieldSetsdict["FieldSetLoops"].append(FieldSetLoopsdict)
#     SectionLoopsdict["FieldSets"].append(FieldSetsdict)
#     sectiondict["SectionLoops"].append(SectionLoopsdict)
#     mydict["Sections"].append(sectiondict)
#
#     finaldict.append(mydict)
#
# print(finaldict)

# ==================================================================================================
import json
import datetime
import re

import pandas as pd
import numpy as np
from collections import OrderedDict
#
# def append_statistics(filepath):
#
#     with open(filepath, 'r') as fp:
#         information = json.load(fp)
#
#     print(information.keys)
#
#     # with open(filepath, 'w') as fp:
#     #     json.dump(information, fp, indent=2)
#
# append_statistics(r"C:\Users\shethd\OneDrive - Dun and Bradstreet\Project_Document\DataIngestion\GDO\UnifiedUnity\GeneralSection.json")
finaldict = []
dfgeneral = pd.read_csv(r"C:\Users\shethd\OneDrive - Dun and Bradstreet\Project_Document\DataIngestion\GDO\UnifiedUnity\csvs\History_MCA_Non_Loop_All_d81a4bb182954968966e7e1b13002125.csv",
                        parse_dates=["Update_Date_fb","DATE_OF_REGISTRATION_ff"],infer_datetime_format=True)
dfgeneral.fillna("")
dfgeneral["No.of Members_FE"] = dfgeneral["No.of Members_FE"].astype(str).str.replace("nan","")

def createNLfieldsetloops(index,fields):
    FieldSetLoops=[]
    FieldSetLoopsdict = {}
    FieldSetLoopsdict["Index"]=index
    FieldSetLoopsdict["Fields"]=fields
    FieldSetLoops.append(FieldSetLoopsdict)
    return FieldSetLoops

def createNLfieldsets(FieldSetId,FieldSetLoops):
    FieldSets=[]
    FieldSetLoopsdict = {}
    FieldSetLoopsdict["FieldSetId"]=FieldSetId
    FieldSetLoopsdict["FieldSetLoops"]=FieldSetLoops
    FieldSets.append(FieldSetLoopsdict)
    return FieldSets

def createNLsectionloops(FieldSets):
    SectionLoopslist = []
    FieldSetsdict={}
    FieldSetsdict["FieldSets"]=FieldSets
    SectionLoopslist.append(FieldSetsdict)
    return SectionLoopslist

def createNLsection(section,SectionLoops):
    sectionlist=[]
    sectiondict={}
    sectiondict["Name"]=section
    sectiondict["SectionLoops"]=SectionLoops
    sectionlist.append(sectiondict)
    return sectionlist

for (index, row) in dfgeneral.iterrows():

    mydict = {k: v for k, v in
              (('Id', int(dfgeneral.at[index, "duns_no"])),
               ('UpdateDate', "<TD>"),
               ('Action', {"IfExists": "Update", "IfNotExists": "Skip"}),
               ("Country", 356))}
    # readiness of the columns
    rowrequired = pd.DataFrame(row).T.iloc[:,2:-1]
    rowrequired = rowrequired.fillna("")

    rowrequired.columns = [item.rsplit("_")[-1] for item in rowrequired.columns.to_list()]
    name = re.split(r'[^0-9a-zA-Z]', dfgeneral.at[index, "SheetName"])[0]

    # rowrequired.columns = [item.rsplit(':', 1)[0] for item in rowrequired.columns.to_list()]
    # N=> INNER MOST
    Fields={str(columnName):{"Value":(str(columnData.iat[0]))} if (str(columnData.iat[0]))!="" else {"Action":{"IfExists": "Skip"}} for (columnName, columnData) in rowrequired.iteritems()}
    # N-1
    # FieldSetLoops=createNLfieldsetloops(0,Fields)
    # N-2
    # FieldSets=createNLfieldsets(-1,createNLfieldsetloops(0,Fields))
    # N-3
    # SectionLoops=createNLsectionloops(createNLfieldsets(-1,createNLfieldsetloops(0,Fields)))
    # N-4
    sections = createNLsection(name,createNLsectionloops(createNLfieldsets(-1,createNLfieldsetloops(0,Fields))))

    mydict["Sections"] = sections
    finaldict.append(mydict)

print(finaldict)
json_results = json.dumps(finaldict,indent=2)
with open(r'C:\Users\shethd\OneDrive - Dun and Bradstreet\Project_Document\DataIngestion\GDO\UnifiedUnity\csvs/'+"duns1_5_99c9e02cd62d49e493b1e27ff5199255"+'.json', 'w') as json_file:
    json_file.write(json_results)
#============================================================================================
# import os
# import json
# import pandas as pd
# import re
# from datetime import datetime
#
#
# def create_json_file(name, record):
#     copy_original = record.copy() # Take a row copy
#     del copy_original['duns_no'] # Delete duns_no and SheetName colums and keep remaining columns
#     del copy_original['SheetName']
#
#     item_dict = dict()
#
#     for key, value in copy_original.items(): # Loop all columns and create dictionary object
#         key_ = str(re.split(r'[^0-9a-zA-Z]', key)[-1])
#         value = str(value).replace('nan', '').strip()
#         if value:
#             item_dict[key_] = {
#                 "Value":value
#             }
#         else:
#             item_dict[key_] = {
#                 "Action": {
#                     "IfExists": "Delete"
#                 }
#             }
#
#     dummy_dict = dict()
#     dummy_dict["Id"] = record['duns_no']
#     dummy_dict["UpdateDate"] = datetime.today().strftime("%m/%d/%Y")
#     dummy_dict["Action"] = {
#       "IfExists": "Update",
#       "IfNotExists": "Skip"
#     }
#     dummy_dict["Country"] = 356
#     dummy_dict['Sections'] = [
#         {
#             "Name": name,
#             "SectionLoops": [
#                 {
#                     "FieldSets": [
#                         {
#                             "FieldSetId": -1,
#                             "FieldSetLoops": [
#                                 {
#                                     "Index": 0,
#                                     "Fields": item_dict # Column details
#                                 }
#                             ]
#                         }
#                     ]
#                 }
#             ]
#         }
#     ]
#     return dummy_dict
#
#
# if __name__ == '__main__':
#     folder_path = r'C:\Users\shethd\OneDrive - Dun and Bradstreet\Project_Document\DataIngestion\GDO\UnifiedUnity\csvs' # List of csv files folder path
#     for file in os.listdir(folder_path):
#         print(file)
#         json_results = []
#
#         sheet_name = re.split(r'[^0-9a-zA-Z]', file)[0]
#
#         df = pd.read_csv(folder_path+'\\'+file) # Load csv file
#         df = df.drop_duplicates('duns_no')
#         rows = df.to_dict(orient='records')
#
#         for row in rows:
#             result = create_json_file(sheet_name, row) # Convert row into dictionary
#             json_results.append(result)
#
#         json_results = json.dumps(json_results, indent=2)
#
#         # Json files folder path
#         with open(r'C:\Users\shethd\OneDrive - Dun and Bradstreet\Project_Document\DataIngestion\GDO\UnifiedUnity\csvs/'+file+'.json', 'w') as json_file:
#             json_file.write(json_results)
