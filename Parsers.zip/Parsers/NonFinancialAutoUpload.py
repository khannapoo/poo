import logging
import os
import traceback
import openpyxl
import pandas as pd
import paramiko
import pysftp as pysftp
from SetLogger import Logs
from office365.runtime.auth.client_credential import ClientCredential
from office365.sharepoint.client_context import ClientContext
from datetime import date,datetime,timedelta
import time
from datetime import date
from SendEmail import SendEmail as mail
from DatabaseConfigFile import *
from SharepointSettings import settings_FinancialNonFinancial
import pyodbc
from pathlib import Path
from openpyxl import load_workbook
from pretty_html_table import build_table
import  numpy as np
import pysftp

class AutoNonFinancial:

    def ManageSQLConnection(self,df,logger,Action):

        try:

            sql_conn = pyodbc.connect(
                'DRIVER='+ mysql["DRIVER"] + ';SERVER='+ mysql["SERVER"] +
                ';DATABASE='+ mysql["DATABASE"] + ';UID='+ mysql["UID"] + ';PWD='+ mysql[
                    "PWD"] + '')
            cursor = sql_conn.cursor()
            cursor.fast_executemany = True

            sql_query = pd.read_sql_query(
                "SELECT * FROM [fileparser_inhousejobs] WHERE JobName='" + str(
                    AutoFinUploadJob["Job"]) + "'",
                sql_conn)

            JobID = sql_query['id']
            MY_TABLE = 'fileparser_jobhistory'
            df["JobID"] = JobID[0]
            if Action == "Insert":
                insert_to_tbl_stmt = "INSERT INTO [fileparser_jobhistory] (RunBy,OutputFilePath,LogPath,RunDuration,JobID_id,JobStatus) VALUES ('%s','%s','%s','%s',%s,'%s')" % (
                df["RunBy"][0],df["OutputFilePath"][0],df["LogPath"][0],df["RunDuration"][0],df["JobID"][0],
                str(df["JobStatus"][0]))
                # insert_to_tbl_stmt='''INSERT INTO {MY_TABLE} ('RunBy','OutputFilePath','LogPath','RunDuration','JobID') VALUES (?,?,?,?,?) '''
                # insert_to_tmp_tbl_stmt = f"INSERT INTO {MY_TABLE} ('RunBy','OutputFilePath','LogPath','RunDuration','JobID') VALUES (?,?,?,?,?)"
                cursor.execute(insert_to_tbl_stmt)
                print(f'{len(df)} rows inserted to the {MY_TABLE} table')
            else:
                sql_query1 = pd.read_sql_query(
                    "SELECT TOP 1 * FROM [fileparser_jobhistory] ORDER BY id DESC",
                    sql_conn)
                JobHistoryID = sql_query1['id']
                # "Update [fileparser_jobhistory] set RunBy = ?,OutputFilePath= ?,LogPath= ?,RunDuration= ?,JobID_id= ?,JobStatus= ? where id = ?" %(df["RunBy"][0],df["OutputFilePath"][0],df["LogPath"][0],df["RunDuration"][0],df["JobID"][0],str(df["JobStatus"][0]))
                update_to_tbl_stmt = "Update [fileparser_jobhistory] set RunBy = '%s'," \
                                     "OutputFilePath= '%s'," \
                                     "LogPath= '%s',RunDuration='%s'," \
                                     "JobID_id= '%s',JobStatus= '%s'where id = '%s'" % (
                                     str(df["RunBy"][1]),str(df["OutputFilePath"][1]),str(df["LogPath"][1]),
                                     str(df["RunDuration"][1]),str(df["JobID"][1]),str(df["JobStatus"][1]),
                                     str(JobHistoryID[0]))
                # insert_to_tbl_stmt='''INSERT INTO {MY_TABLE} ('RunBy','OutputFilePath','LogPath','RunDuration','JobID') VALUES (?,?,?,?,?) '''
                # insert_to_tmp_tbl_stmt = f"INSERT INTO {MY_TABLE} ('RunBy','OutputFilePath','LogPath','RunDuration','JobID') VALUES (?,?,?,?,?)"
                cursor.execute(update_to_tbl_stmt)
                sql_conn.commit()
                print(f'{len(df)} rows updated to the {MY_TABLE} table')
            cursor.commit()
            cursor.close()
            sql_conn.close()

        except Exception as ex:
            logger.error("SQL Error")
            logger.error(str(ex))

    def __init__(self):
        self.DFSharepointFolderDetails = pd.DataFrame(
            columns=['Folder Name','File Count','Folder Status','ProcessedDateTime'])

    def findInDict(self,needle,haystack):
        for key in haystack.keys():
            try:
                value = haystack[key]
            except:
                continue
            if key == needle:
                return value
            if isinstance(value,dict):
                x = self.findInDict(needle,value)
                if x is not None:
                    return x

    def SharepointOperation(self,action,file,logger,fileType):

        SharepointFolderDetails = []
        AutoNonFinancialObj = AutoNonFinancial()
        try:

            ctx = ClientContext(settings_FinancialNonFinancial.get('team_site_url')).with_credentials(
                ClientCredential(settings_FinancialNonFinancial['client_credentials']['client_id'],
                                 settings_FinancialNonFinancial['client_credentials']['client_secret']))

            if (action == "Upload File"):
                if (fileType=="LOGS"):
                    path = file
                    folder_url = '/Shared Documents/SupremeCourt/AutoFin-NonFinUpload/Logs_Stats/'
                    with open(path, 'rb') as content_file:
                        file_content = content_file.read()
                    target_folder = ctx.web.get_folder_by_server_relative_url(folder_url)
                    name = os.path.basename(path)
                    target_folder.upload_file(name, file_content)
                    ctx.execute_query()
                elif (fileType=="CSV"):
                    folder_url = '/Shared Documents/SupremeCourt/AutoFin-NonFinUpload/ProcessedNonFinCSVFiles/'
                    for file in os.listdir(OutPutFileNonFinancial["OutPutFileNonFinancial"]):
                        try:
                            if not file.endswith(".csv"):
                                continue
                            target_folder = ctx.web.get_folder_by_server_relative_url(folder_url)
                            path = os.path.join(OutPutFileNonFinancial["OutPutFileNonFinancial"],file)
                            name = os.path.basename(os.path.join(OutPutFileNonFinancial["OutPutFileNonFinancial"],file))
                            with open(path, 'rb') as content_file:
                                file_content = content_file.read()

                            target_folder.upload_file(name, file_content)
                            ctx.execute_query()
                        except Exception as ex:
                            logger.error("Could not upload the file to csv")

                return "File uploaded"

            elif (action == "Download File"):
                try:
                    try:
                        folder_url = '/Shared Documents/SupremeCourt/AutoFin-NonFinUpload/'
                        folders = ctx.web.get_folder_by_server_relative_url(folder_url).folders

                        ctx.load(folders)
                        ctx.execute_query()
                        FileListCount = []
                        # len(folders)
                        for folder,i in zip(folders,range(0,len(folders))):
                            try:
                                t0 = time.time()
                                FileCoun = 0

                                FolderName = str(folder.properties["Name"])
                                files = ctx.web.get_folder_by_server_relative_url(
                                    folder_url + FolderName+ "/InputFinancial_NonFinancialExcel/").files
                                if FolderName == "Logs_Stats" \
                                or FolderName == "Vendor_2":
                                    continue
                                # files = folder.files
                                ctx.load(files)
                                ctx.execute_query()
                                if (len(files) > 0):
                                    List = [FolderName,len(files),"File Available",str(today)+"_"+str(logtime)]
                                else:
                                    List = [FolderName,len(files),"Folder Empty",str(today)+"_"+str(logtime)]
                                SharepointFolderDetails.append(List)

                                AutoNonFinancialObj.DFSharepointFolderDetails.loc[
                                    len(AutoNonFinancialObj.DFSharepointFolderDetails)] = List
                                for cur_file,i in zip(files,range(0,len(files))):

                                    if 'Non Financial'in (str(cur_file.properties["Name"])):
                                        FileCoun = FileCoun + 1

                                        download_FileName = os.path.join(InPutFilesNonFinancial[
                                                                             "InPutFilesNonFinancial"],
                                                                          FolderName + "_" + os.path.basename(
                                                                             cur_file.properties["Name"]))
                                        file_url = '/sites/RMSCCAM/Shared Documents/SupremeCourt/AutoFin-NonFinUpload/'+FolderName+'/InputFinancial_NonFinancialExcel/'+os.path.basename(
                                                                             cur_file.properties["Name"])

                                        with open(download_FileName,"wb") as local_file:
                                            file  = ctx.web.get_file_by_server_relative_url(file_url).download(
                                                local_file).execute_query()

                                        logger.info("File name: {0}".format(
                                            str(FolderName + "_" + cur_file.properties["Name"])))
                                        # delete the file from sharepoint
                                        # file.delete_object()
                                        # ctx.execute_query()
                                FileListCount.append(FileCoun)
                            except Exception as ex:
                                logger.error(str(ex) + traceback.format_exc())
                                continue

                    except Exception as ex:
                        logger.error(str(ex) + traceback.format_exc())

                    if len(folders) != 0:
                        t1 = time.time()
                        Series = pd.Series(FileListCount)
                        AutoNonFinancialObj.DFSharepointFolderDetails["FileCount"] = Series
                        elapsed = time.strftime("%H:%M:%S %Z",time.gmtime(t1 - t0))

                        logger.info("Folder has been downloaded")
                        logger.info("Total time to download the files is " + str(elapsed))
                        return "Folder has been downloaded",AutoNonFinancialObj
                    else:
                        logger.info("No folders to download")
                        return "Folder has not been downloaded",AutoNonFinancialObj

                except Exception as ex:
                    logger.error(str(ex) + traceback.format_exc())
                    logger.error(str(folder.properties["Name"]) + "Folder has not been downloaded")
                    return "Folder has not been downloaded",AutoNonFinancialObj

            elif (action == "Delete File"):
                try:
                    folder_url = '/Shared Documents/SupremeCourt/AutoFin-NonFinUpload/ProcessedNonFinCSVFiles/'
                    files = ctx.web.get_folder_by_server_relative_url(folder_url).files

                    ctx.load(files)
                    ctx.execute_query()
                    FileListCount = []
                    # len(folders)
                    for file, i in zip(files, range(0, len(files))):
                        try:
                            TimeCreated = (str(file.properties['TimeCreated']).split('T')[0])
                            TimeCreated = datetime.strptime(TimeCreated, '%Y-%m-%d')
                            YesterdayDate =datetime.strptime(Yesterday["Yesterday"], '%Y-%m-%d')
                            if TimeCreated==YesterdayDate:
                                file.delete_object()
                                ctx.execute_query()
                                logger.info("CSV File was deleted")
                            # FileListCount.append(FileCoun)
                        except Exception as ex:
                            logger.error(str(ex) + traceback.format_exc())
                            continue

                    return "CSV Files have been deleted", AutoNonFinancialObj

                except Exception as ex:
                    logger.error(str(ex) + traceback.format_exc())

        except Exception as ex:
            logger.error(str(ex) + traceback.format_exc())

    def UpdateFieldIDDataframes (self,df,logger):
        try:
            df['FieldId'] = df.groupby('Duns_No').cumcount() + 1
            df['FieldId'] = -df['FieldId'].astype(int)
            df.applymap(lambda x: x.strip() if type(x) == str else x)
            # Share Capital
            if 'Update Date_fb' in df:
                df['Update Date_fb'] = pd.to_datetime(df['Update Date_fb'], errors='coerce')
                df['Update Date_fb'] = df['Update Date_fb'].dt.strftime('%Y-%m-%d')

            # General_Loop
            elif 'Report Base Date_zd' in df:
                df['Report Base Date_zd'] = pd.to_datetime(df['Report Base Date_zd'], errors='coerce')
                df['Report Base Date_zd'] = df['Report Base Date_zd'].dt.strftime('%Y-%m-%d')

            # Equity - Sh Holding
            elif 'Shareholding as at (date)_pc' in df:
                df['Shareholding as at (date)_pc'] = pd.to_datetime(df['Shareholding as at (date)_pc'], errors='coerce')
                df['Shareholding as at (date)_pc'] = df['Shareholding as at (date)_pc'].dt.strftime('%Y-%m-%d')

            # Cin_Investigation
            elif 'Date of Contact (ddmmyyyy)_kl' in df:
                df['Date of Contact (ddmmyyyy)_kl'] = pd.to_datetime(df['Date of Contact (ddmmyyyy)_kl'], errors='coerce')
                df['Date of Contact (ddmmyyyy)_kl'] = df['Date of Contact (ddmmyyyy)_kl'].dt.strftime('%Y-%m-%d')

            # General Ho Address
            elif 'Report Base Date_zd (yyyy-mm-dd)' in df:
                df['Report Base Date_zd (yyyy-mm-dd)'] = pd.to_datetime(df['Report Base Date_zd (yyyy-mm-dd)'], errors='coerce')
                df['Report Base Date_zd (yyyy-mm-dd)'] = df['Report Base Date_zd (yyyy-mm-dd)'].dt.strftime('%Y-%m-%d')

            # Management
            elif 'Update Date__mgmt_EB (yyyy-mm-dd)' in df:
                df['Update Date__mgmt_EB (yyyy-mm-dd)'] = pd.to_datetime(df['Update Date__mgmt_EB (yyyy-mm-dd)'], errors='coerce')
                df['Update Date__mgmt_EB (yyyy-mm-dd)'] = df['Update Date__mgmt_EB (yyyy-mm-dd)'].dt.strftime('%Y-%m-%d')
            elif 'Date of Appointment_mgmt_FT (yyyy-mm-dd)' in df:
                df['Date of Appointment_mgmt_FT (yyyy-mm-dd)'] = pd.to_datetime(df['Date of Appointment_mgmt_FT (yyyy-mm-dd)'], errors='coerce')
                df['Date of Appointment_mgmt_FT (yyyy-mm-dd)'] = df['Date of Appointment_mgmt_FT (yyyy-mm-dd)'].dt.strftime('%Y-%m-%d')

            # Capital
            elif 'Date of Change_rc (yyyy-mm-dd)' in df:
                df['Date of Change_rc (yyyy-mm-dd)'] = pd.to_datetime(df['Date of Change_rc (yyyy-mm-dd)'], errors='coerce')
                df['Date of Change_rc (yyyy-mm-dd)'] = df['Date of Change_rc (yyyy-mm-dd)'].dt.strftime('%Y-%m-%d')

            # Legal Name
            elif 'Date of change_ks (yyyy-mm-dd)' in df:
                df['Date of change_ks (yyyy-mm-dd)'] = pd.to_datetime(df['Date of change_ks (yyyy-mm-dd)'],errors='coerce')
                df['Date of change_ks (yyyy-mm-dd)'] = df['Date of change_ks (yyyy-mm-dd)'].dt.strftime('%Y-%m-%d')

            # Old Address
            elif 'Date of Change_bi (yyyy-mm-dd)' in df:
                df['Date of Change_bi (yyyy-mm-dd)'] = pd.to_datetime(df['Date of Change_bi (yyyy-mm-dd)'],errors='coerce')
                df['Date of Change_bi (yyyy-mm-dd)'] = df['Date of Change_bi (yyyy-mm-dd)'].dt.strftime('%Y-%m-%d')

            # Legal Structres
            elif 'Date of Change_nn (yyyy-mm-dd)' in df:
                df['Date of Change_nn (yyyy-mm-dd)'] = pd.to_datetime(df['Date of Change_nn (yyyy-mm-dd)'],errors='coerce')
                df['Date of Change_nn (yyyy-mm-dd)'] = df['Date of Change_nn (yyyy-mm-dd)'].dt.strftime('%Y-%m-%d')

            # Court Orders
            elif 'Date on Event take place_lg (yyyy-mm-dd)' in df:
                df['Date on Event take place_lg (yyyy-mm-dd)'] = pd.to_datetime(df['Date on Event take place_lg (yyyy-mm-dd)'],errors='coerce')
                df['Date on Event take place_lg (yyyy-mm-dd)'] = df['Date on Event take place_lg (yyyy-mm-dd)'].dt.strftime('%Y-%m-%d')

        except Exception as ex:
            logger.error(str(ex))

    def ValidateDUNSNumber(self, df, logger):
        try:
            # covert the column into string
            df['Duns_No'] = df['Duns_No'].astype('str')
            # Mask the Dataframe
            mask = (df['Duns_No'].str.len() == 9)
            df = df.loc[mask]
            df.reset_index(inplace=True,drop=True)
            return df
        except Exception as ex:
            logger.error(str(ex))
            
    def AutoNonFinancialProcess(self,logger):
        Inputdirectory = InPutFilesNonFinancial["InPutFilesNonFinancial"]
        Outputdirectory = OutPutFileNonFinancial["OutPutFileNonFinancial"]

        dataAll = [['General_Loop','NL','NA','N'],
                ['General_EXIM_Loop','L','P','Y'],
                ['Auditors Name_Hist_Loop','L','P','Y'],
                ['Share capital_History Non Loop','L','P','Y'],
                ['Equity - Sh Holding','L','P','Y'],
                ['Pref- Sh Holding','L','P','Y'],
                ['Subsidiary_Relcon_Loop','L','P','Y'],
                ['Parent_Relcon_Non Loop','NL','NA','N'],
                ['Financial Date_His_Nonloop','NL','NA','N'],
                ['Register Add_Hist_Loop','L','P','Y'],
                ['Cin_Investigation','L','P','Y'],
                ['Affiliate_Relcon_Loop','L','P','Y'],
                ['General Ho Address','NL','NA','N'],
                ['Management','L','P','Y'],
                ['Capital','L','A','N'],
                ['Legal_Name','L','A','N'],
                ['Old_Address','L','A','N'],
                ['New_Address','L','A','N'],
                ['Legal_Structure','L','A','N'],
                ['Court_Orders','L','A','N']]
        df_NonFin = pd.DataFrame(dataAll,columns=['Sheets','Looping/NonLooping','Prepend','Deletion'])
        df_NonFin.set_index('Sheets', inplace=True)
        FTPStats = []
        StatsList = []
        global Stats
        global FTPStatdf
        FTPStatdf = pd.DataFrame()
        Stats = pd.DataFrame()
        dfgeneralAll = pd.DataFrame()
        dfParentAll = pd.DataFrame()
        dfFinancialAll= pd.DataFrame()
        dfGeneralHoAll= pd.DataFrame()


        dfGeneral_EXIMAll = pd.DataFrame()
        dfGeneral_EXIMAll_Delete = pd.DataFrame()

        dfCinInvestAll=pd.DataFrame()
        dfCinInvestAll_Delete = pd.DataFrame()

        dfEquityShHoldingAll=pd.DataFrame()
        dfEquityShHoldingAll_Delete = pd.DataFrame()

        dfSubsidiaryAll= pd.DataFrame()
        dfSubsidiaryAll_Delete= pd.DataFrame()

        dfPrefShHoldingAll= pd.DataFrame()
        dfPrefShHoldingAll_Delete = pd.DataFrame()

        dfAffiliateAll= pd.DataFrame()
        dfAffiliateAll_Delete = pd.DataFrame()

        dfCapitalAll= pd.DataFrame()
        dfCapitalAll_Delete = pd.DataFrame()

        dfRegisterAll= pd.DataFrame()
        dfRegisterAll_Delete = pd.DataFrame()

        dfLegal_NameAll= pd.DataFrame()
        dfLegal_NameAll_Delete = pd.DataFrame()

        dfOld_AddressAll= pd.DataFrame()
        dfOld_AddressAll_Delete = pd.DataFrame()

        dfNew_AddressAll= pd.DataFrame()
        dfNew_AddressAll_Delete = pd.DataFrame()

        dfLegal_StructureAll = pd.DataFrame()
        dfLegal_StructureAll_Delete = pd.DataFrame()

        dfCourt_OrdersAll = pd.DataFrame()
        dfCourt_OrdersAll_Delete = pd.DataFrame()

        dfAuditorsNameAll = pd.DataFrame()
        dfAuditorsNameAll_Delete = pd.DataFrame()

        dfSharecapitalAll = pd.DataFrame()
        dfSharecapitalAll_Delete = pd.DataFrame()

        dfMgmtAll= pd.DataFrame()
        dfMgmtAll_Delete = pd.DataFrame()


        try:
            logger.info("Process Started " + str(datetime.now().strftime('%d_%m_%Y %H_%M_%S')))
            logger.info("***********************************************************")
            logger.info("Process Started ")
            Message, AutoFinancialObj = self.SharepointOperation("Delete File", "", logger, "")
            if (Message.find('CSV Files have been deleted') != -1):
                logger.info("Step 1 : Folder has been downloaded from sharepoint")
            Message,AutoFinancialObj = self.SharepointOperation("Download File","",logger,"")
            if (Message.find('Folder has been downloaded') != -1):
                logger.info("Step 1 : Folder has been downloaded from sharepoint")

            # loop through the input directory
            for file in os.listdir(Inputdirectory):
                try:
                    if not file.endswith(".xlsm"):
                        continue
                    BoolGeneral = False
                    BoolGeneral_EXIM = False
                    BoolAuditorsName = False
                    BoolSharecapital = False
                    BoolEquityShHolding = False
                    BoolPrefShHolding = False
                    BoolSubsidiary = False
                    BoolParent = False
                    BoolFinancial = False
                    BoolRegister = False
                    BoolCinInvest = False
                    BoolAffiliate = False
                    BoolGeneralHo = False
                    BoolMgmt = False
                    BoolCapital = False
                    BoolLegal_Name = False
                    BoolOld_Address = False
                    BoolNew_Address = False
                    BoolLegal_Structure = False
                    BoolCourt_Orders = False

                    try:
                        t0 = time.time()
                        filename = Path(os.path.join(Inputdirectory,file))
                        filename1 = filename.name
                        FileWithoutExtn = os.path.splitext(filename1)[0]

                        wb = openpyxl.load_workbook(filename)
                        logger.info("File In Process : " + filename1)
                        # Check if worksheets exists
                        for sheet in wb.worksheets:
                            sheet = sheet.title
                    # =============================Non Looping==================================
                            if sheet == "General_Loop":
                                BoolGeneral = True
                                logger.info("Sheet is available =>" + sheet)
                            if sheet == "Parent_Relcon_Non Loop":
                                BoolParent = True
                                logger.info("Sheet is available =>" + sheet)
                            elif sheet == "Financial Date_His_Nonloop":
                                BoolFinancial = True
                                logger.info("Sheet is available =>" + sheet)
                            elif sheet == "General Ho Address":
                                BoolGeneralHo = True
                                logger.info("Sheet is available =>" + sheet)
                    #=============================Field Looping==================================
                            elif sheet == "General_EXIM_Loop":
                                BoolGeneral_EXIM = True
                                logger.info("Sheet is available =>" + sheet)
                            elif sheet == "Equity - Sh Holding":
                                BoolEquityShHolding = True
                            elif sheet == "Pref- Sh Holding":
                                BoolPrefShHolding = True
                            elif sheet == "Subsidiary_Relcon_Loop":
                                BoolSubsidiary = True
                            elif sheet == "Cin_Investigation":
                                BoolCinInvest = True
                            elif sheet == "Affiliate_Relcon_Loop":
                                BoolAffiliate = True
                            elif sheet == "Register Add_Hist_Loop":
                                BoolRegister = True
                            elif sheet == "Capital":
                                BoolCapital = True
                            elif sheet == "Legal_Name":
                                BoolLegal_Name = True
                            elif sheet == "Old_Address":
                                BoolOld_Address = True
                            elif sheet == "New_Address":
                                BoolNew_Address = True
                            elif sheet == "Legal_Structure":
                                BoolLegal_Structure = True
                            elif sheet == "Court_Orders":
                                BoolCourt_Orders = True
                            elif sheet == "Auditors Name_Hist_Loop":
                                BoolAuditorsName = True
                            elif sheet == "Share capital_History Non Loop":
                                BoolSharecapital = True
                    # =============================Section Looping==================================
                            elif sheet == "Management":
                                BoolMgmt = True

                        t1 = time.time()
                        elapsed = time.strftime("%H:%M:%S %Z", time.gmtime(t1 - t0))
                        # =============================Non Looping=====================================

                        # if BoolGeneral:
                        try:
                            dfgeneral = pd.read_excel(filename, sheet_name='General_Loop', index_col=None, na_values=['NA'],
                                                  usecols="A:E")

                            if not dfgeneral.empty:
                                df = self.ValidateDUNSNumber(dfgeneral,logger)
                                dfgeneral = df
                                if not dfgeneral.empty:
                                    dfgeneral.columns = ['Duns_No','Report Base Date_zd','Company_ab','EmailID_ax','FieldId']
                                    dfgeneral['FieldId'] = dfgeneral.groupby('Duns_No').cumcount()+1
                                    dfgeneral['FieldId'] = -dfgeneral['FieldId'].astype(int)
                                    dfgeneralAll = dfgeneralAll.append(dfgeneral)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfgeneral.at[0,'Duns_No'], FileWithoutExtn, "GeneralCSV", Status, str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "General", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])
                            else:
                                pass
                                logger.info("General worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "General", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, 'General Worksheet', Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))

                        # if BoolParent:
                        try:
                            dfParent = pd.read_excel(filename, sheet_name='Parent_Relcon_Non Loop', index_col=None, na_values=['NA'],
                                                  usecols="A:G")
                            if not dfParent.empty:
                                dfParent.columns = ['Duns_No',
                                                    'Corporate Identification Number (CIN) of the company',
                                                    'Name of the company_Relcon_DF',
                                                    'CIN / FCRN',
                                                    'Country_Relcon_DR','Holding_Relcon_DC',
                                                    '% of Share held_Relcon_DS']
                                df = self.ValidateDUNSNumber(dfParent, logger)
                                dfParent = df
                                if not dfParent.empty:
                                    dfParentAll = dfParentAll.append(dfParent)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfParent.at[0,'Duns_No'], FileWithoutExtn, "Parent_Relcon", Status, str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Parent_Relcon", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])

                            else:
                                pass
                                logger.info("Parent_Relcon_Non Loop worksheet is empty")

                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Parent_Relcon", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, 'Parent_Relcon', Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))

                        # if BoolFinancial:
                        try:
                            dfFinancial = pd.read_excel(filename, sheet_name='Financial Date_His_Nonloop', index_col=None, na_values=['NA'],
                                                  usecols="A:D")
                            if not dfFinancial.empty:
                                dfFinancial.columns = ['Duns_No',
                                                    'Company Name','Financial Date_history_jw',
                                                    'Tax Registration Number History_PN']
                                # dfParent['FieldId'] = dfParent.groupby('Duns_No').cumcount()+1
                                # dfParent['FieldId'] = -dfParent['FieldId'].astype(int)
                                df = self.ValidateDUNSNumber(dfFinancial, logger)
                                dfFinancial = df
                                if not dfFinancial.empty:
                                    dfFinancialAll = dfFinancialAll.append(dfFinancial)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfFinancial.at[0,'Duns_No'], FileWithoutExtn, "Financial Date_His_Nonloop", Status, str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Financial Date_His_Nonloop", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])

                            else:
                                pass
                                logger.info("Financial Date_His_Nonloop worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Financial Date_His_Nonloop", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, 'Financial Date_His_Nonloop', Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))

                        # if BoolGeneralHo:
                        try:
                            dfGeneralHo = pd.read_excel(filename, sheet_name='General Ho Address', index_col=None, na_values=['NA'],
                                                  usecols="A:T")
                            if not dfGeneralHo.empty:
                                dfGeneralHo.columns = ['Duns_No','Updated in DEWS_za','Office NUMBER_zb',
                                                       'Report Base Date_zd (yyyy-mm-dd)','Report Type_zh','Report Status_zi',
                                                       'Default currency_zg','Correspondent Agent_zk','Anlayst_zl',
                                                       'Data Entry Operator_zm','Keep on Marketing List_zo',
                                                       'Company Name_ab (Upper Case)','Floor/Unit No_tm','Building_al',
                                                       'Street 1_da',
                                                       'Street 2_db',
                                                       'City__im','State__di',
                                                       'Pincode__dg',
                                                       'Country__dd']
                                df = self.ValidateDUNSNumber(dfGeneralHo, logger)
                                dfGeneralHo = df
                                if not dfGeneralHo.empty:
                                # dfParent['FieldId'] = dfParent.groupby('Duns_No').cumcount()+1
                                # dfParent['FieldId'] = -dfParent['FieldId'].astype(int)
                                    dfGeneralHoAll = dfGeneralHoAll.append(dfGeneralHo)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfGeneralHo.at[0,'Duns_No'], FileWithoutExtn, "General Ho Address", Status, str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "General Ho Address", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])

                            else:
                                pass
                                logger.info("General Ho Address worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "General Ho Address", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, 'General Ho Address', Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))

                        # =============================Looping==================================

                        # if BoolGeneral_EXIM:
                        # BoolGeneral_EXIM:
                        try:
                            dfGeneral_EXIM = pd.read_excel(filename, sheet_name='General_EXIM_Loop', index_col=None, na_values=['NA'],
                                                  usecols="A:N")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if not dfGeneral_EXIM.empty:

                                dfGeneral_EXIM.columns = ['Duns_No',
                                                          'Corporate Identification Number (CIN) of the company',
                                                          'Year_hk',
                                                          'Import Raw Material',
                                                          'Component & Spare Parts'	,
                                                          'Capital Goods',
                                                          'Import(CIF Value)(in ''000)_hl',
                                                          'Units in Size_hm',
                                                          'Currency_hn',
                                                          'Export(FOB Value)',
                                                          'Export(FOB Value)(in ''000)_ho',
                                                          'Units in Size_hp',
                                                          'Currency_hq',
                                                          'FieldId']
                                df = self.ValidateDUNSNumber(dfGeneral_EXIM, logger)
                                dfGeneral_EXIM = df
                                if not dfGeneral_EXIM.empty:
                                # dfGeneral_EXIM['FieldId'] = dfGeneral_EXIM.groupby('Duns_No').cumcount() + 1
                                # dfGeneral_EXIM['FieldId'] = -dfGeneral_EXIM['FieldId'].astype(int)
                                    dfGeneral_EXIMAll = dfGeneral_EXIMAll.append(dfGeneral_EXIM)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfGeneral_EXIM.at[0,'Duns_No'], FileWithoutExtn, "General_EXIM", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                    if df_NonFin.at["General_EXIM_Loop","Looping/NonLooping"]=="L":
                                        s = pd.DataFrame(dfGeneral_EXIM.Duns_No.unique(),columns=['Duns_No'])
                                        dfGeneral_EXIMAll_Delete = dfGeneral_EXIMAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfGeneral_EXIM.at[0,'Duns_No'], FileWithoutExtn, "General_EXIM", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "General_EXIM", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])
                            else:
                                pass
                                logger.info("General_EXIM worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "General_EXIM", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "General_EXIMCSV", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))

                        # if BoolCinInvest:
                        try:
                            dfCinInvest = pd.read_excel(filename, sheet_name='Cin_Investigation', index_col=None, na_values=['NA'],
                                                  usecols="A:D")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if not dfCinInvest.empty:

                                dfCinInvest.columns = ['Duns_No',
                                                       'Date of Contact (ddmmyyyy)_kl',
                                                       'Other Comment_uy',
                                                       'FieldId']
                                # dfCinInvest['FieldId'] = dfCinInvest.groupby('Duns_No').cumcount() + 1
                                # dfCinInvest['FieldId'] = -dfCinInvest['FieldId'].astype(int)

                                df = self.ValidateDUNSNumber(dfCinInvest, logger)
                                dfCinInvest = df
                                if not dfCinInvest.empty:
                                    dfCinInvestAll = dfCinInvestAll.append(dfCinInvest)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfCinInvest.at[0,'Duns_No'], FileWithoutExtn, "Cin_Investigation", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                    if (df_NonFin.at["Cin_Investigation", "Looping/NonLooping"] == "L" and df_NonFin.at["Cin_Investigation", "Deletion"] == "Y"):
                                        s = pd.DataFrame(dfCinInvest.Duns_No.unique(),columns=['Duns_No'])
                                        dfCinInvestAll_Delete = dfCinInvestAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfCinInvest.at[0,'Duns_No'], FileWithoutExtn, "Cin_Investigation", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Cin_Investigation", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])
                            else:
                                pass
                                logger.info("CinInvest worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Cin_Investigation", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Cin_Investigation", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))

                        # if BoolEquityShHolding:
                        try:
                            dfEquityShHolding = pd.read_excel(filename, sheet_name='Equity - Sh Holding',
                                                        index_col=None, na_values=['NA'],
                                                        usecols="A:H")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if not dfEquityShHolding.empty:

                                dfEquityShHolding.columns = ['Duns_No','Subject Name',
                                                             'Total Number of equity shares - Subscribed capital',
                                                             'Name_ib',
                                                             'Number of shares_ik',
                                                             'Shares % Held_im',
                                                             'Shareholding as at (date)_pc',
                                                             'FieldId']
                                df = self.ValidateDUNSNumber(dfEquityShHolding, logger)
                                dfEquityShHolding = df
                                if not dfEquityShHolding.empty:
                                # dfEquityShHolding['FieldId'] = dfEquityShHolding.groupby('Duns_No').cumcount() + 1
                                # dfEquityShHolding['FieldId'] = -dfEquityShHolding['FieldId'].astype(int)
                                    dfEquityShHoldingAll = dfEquityShHoldingAll.append(dfEquityShHolding)
                                    Status = "File Processed"
                                    # Reset Index

                                    StatsList.append(
                                        [dfEquityShHolding.at[0,'Duns_No'], FileWithoutExtn, "Equity - Sh Holding", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                    if(df_NonFin.at["Equity - Sh Holding", "Looping/NonLooping"] == "L" and df_NonFin.at[
                                        "Equity - Sh Holding", "Deletion"] == "Y"):
                                        s = pd.DataFrame(dfEquityShHolding.Duns_No.unique(), columns=['Duns_No'])
                                        dfEquityShHoldingAll_Delete = dfEquityShHoldingAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfEquityShHolding.at[0,'Duns_No'], FileWithoutExtn, "Equity - Sh Holding", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Equity - Sh Holding", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])
                            else:
                                pass
                                logger.info("Equity - Sh Holding worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Equity - Sh Holding", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Equity - Sh Holding", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))

                        # if BoolPrefShHolding:
                        try:
                            dfPrefShHolding = pd.read_excel(filename, sheet_name='Pref- Sh Holding',
                                                        index_col=None, na_values=['NA'],
                                                        usecols="A:G")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if not dfPrefShHolding.empty:
                                dfPrefShHolding.columns = ['Duns_No','Subject Name',
                                                           'Total Number of Preference shares - Subscribed capital',
                                                           'Name_ib',
                                                           'Number of shares_io',
                                                           'Shares % Held_iq',
                                                           'FieldId']
                                # dfPrefShHolding['FieldId'] = dfPrefShHolding.groupby('Duns_No').cumcount() + 1
                                # dfPrefShHolding['FieldId'] = -dfPrefShHolding['FieldId'].astype(int)

                                df = self.ValidateDUNSNumber(dfPrefShHolding, logger)
                                dfPrefShHolding = df
                                if not dfPrefShHolding.empty:
                                    dfPrefShHoldingAll = dfPrefShHoldingAll.append(dfPrefShHolding)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfPrefShHolding.at[0,'Duns_No'], FileWithoutExtn, "Pref- Sh Holding", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                    if (df_NonFin.at["Pref- Sh Holding", "Looping/NonLooping"] == "L" and df_NonFin.at[
                                        "Pref- Sh Holding", "Deletion"] == "Y"):

                                        s = pd.DataFrame(dfPrefShHolding.Duns_No.unique(), columns=['Duns_No'])
                                        dfPrefShHoldingAll_Delete = dfPrefShHoldingAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfPrefShHolding.at[0,'Duns_No'], FileWithoutExtn, "Pref- Sh Holding", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Pref- Sh Holding", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])
                            else:
                                pass
                                logger.info("Pref- Sh Holding worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Pref- Sh Holding", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Pref- Sh Holding", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))

                        # if BoolSubsidiary:
                        try:
                            dfSubsidiary = pd.read_excel(filename, sheet_name='Subsidiary_Relcon_Loop',
                                                            index_col=None, na_values=['NA'],
                                                            usecols="A:H")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if (not dfSubsidiary.empty) and (not dfSubsidiary['Duns_No'].isnull().values.any()):
                                dfSubsidiary.columns = ['Duns_No',
                                                        'Corporate Identification Number (CIN) of the company',
                                                        'Name of the company_Relcon_CG','CIN / FCRN',
                                                        'Country_Relcon_CS',
                                                        'Holding/Subsidiary/Joint Ventures/Associate',
                                                        '% of Share held_Relcon_CW','FieldId']
                                # dfSubsidiary['FieldId'] = dfSubsidiary.groupby('Duns_No').cumcount() + 1
                                # dfSubsidiary['FieldId'] = -dfSubsidiary['FieldId'].astype(int)

                                df = self.ValidateDUNSNumber(dfSubsidiary, logger)
                                dfSubsidiary = df
                                if not dfSubsidiary.empty:

                                    dfSubsidiaryAll = dfSubsidiaryAll.append(dfSubsidiary)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfSubsidiary.at[0,'Duns_No'], FileWithoutExtn, "Subsidiary_Relcon_Loop", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])

                                    if (df_NonFin.at["Subsidiary_Relcon_Loop", "Looping/NonLooping"] == "L" and df_NonFin.at[
                                        "Subsidiary_Relcon_Loop", "Deletion"] == "Y"):

                                        s = pd.DataFrame(dfSubsidiary.Duns_No.unique(), columns=['Duns_No'])
                                        dfSubsidiaryAll_Delete = dfSubsidiaryAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfSubsidiary.at[0,'Duns_No'], FileWithoutExtn, "Subsidiary_Relcon_Loop", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Subsidiary_Relcon_Loop", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])
                            else:
                                pass
                                logger.info("Subsidiary_Relcon_Loop worksheet is empty or duns number is not available")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Subsidiary_Relcon_Loop", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Subsidiary_Relcon_Loop", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))

                        # if BoolAffiliate:
                        try:
                            dfAffiliate = pd.read_excel(filename, sheet_name='Affiliate_Relcon_Loop',
                                                            index_col=None, na_values=['NA'],
                                                            usecols="A:L")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if not dfAffiliate.empty and (not dfAffiliate['Duns_No'].isnull().values.any()) :
                                dfAffiliate.columns = ['Duns_No',
                                                       'Corporate Identification Number (CIN) of the company',
                                                       'Name of the company_Relcon_BH','CIN / FCRN',
                                                       'Country_Relcon_BT',
                                                       'Holding/Subsidiary/Joint Ventures/Associate',
                                                       'This Affiliate is Joint Venture_Relcon_BF',
                                                       'Subject holds Shares in Affiliate (Tick Box)_Relcon_BW',
                                                       'Affiliate holds Shares in Subject (Tick Box)_Relcon_BX',
                                                       '% of Share held_Relcon_FA','% of Share held_Relcon_FC',
                                                       'FieldId']
                                # dfAffiliate['FieldId'] = dfAffiliate.groupby('Duns_No').cumcount() + 1
                                # dfAffiliate['FieldId'] = -dfAffiliate['FieldId'].astype(int)
                                df = self.ValidateDUNSNumber(dfAffiliate, logger)
                                dfAffiliate = df
                                if not dfAffiliate.empty:
                                    dfAffiliateAll = dfAffiliateAll.append(dfAffiliate)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfAffiliate.at[0,'Duns_No'], FileWithoutExtn, "Affiliate_Relcon_Loop", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])

                                    if (df_NonFin.at["Affiliate_Relcon_Loop", "Looping/NonLooping"] == "L" and df_NonFin.at[
                                        "Affiliate_Relcon_Loop", "Deletion"] == "Y"):

                                        s = pd.DataFrame(dfAffiliate.Duns_No.unique(), columns=['Duns_No'])
                                        dfAffiliateAll_Delete = dfAffiliateAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfAffiliate.at[0,'Duns_No'], FileWithoutExtn, "Affiliate_Relcon_Loop", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Affiliate_Relcon_Loop", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])
                            else:
                                pass
                                logger.info("Affiliate_Relcon_Loop worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Affiliate_Relcon_Loop", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Affiliate_Relcon_Loop", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))

                        # if BoolRegister:
                        try:
                            dfRegister = pd.read_excel(filename, sheet_name='Register Add_Hist_Loop',
                                                            index_col=None, na_values=['NA'],
                                                            usecols="A:J")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if not dfRegister.empty and (not dfRegister['Duns_No'].isnull().values.any()):
                                dfRegister.columns = ['Duns_No','Company Name',
                                                      'Registered Address 1__Hist__jj',
                                                      'Registered Address 2__Hist__jk',
                                                      'Registered Address 2__Hist__jl',
                                                      'Registered City__Hist__tb',
                                                      'Registered Address State__Hist__jq',
                                                      'Registered Address Pincode__Hist__jr',
                                                      'Registered Country__Hist__js',
                                                      'FieldId']
                                # dfRegister['FieldId'] = dfRegister.groupby('Duns_No').cumcount() + 1
                                # dfRegister['FieldId'] = -dfRegister['FieldId'].astype(int)
                                df = self.ValidateDUNSNumber(dfRegister, logger)
                                dfRegister = df
                                if not dfRegister.empty:
                                    dfRegisterAll = dfRegisterAll.append(dfRegister)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfRegister.at[0,'Duns_No'], FileWithoutExtn, "Register Add_Hist_Loop", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                    if (df_NonFin.at["Register Add_Hist_Loop", "Looping/NonLooping"] == "L" and df_NonFin.at[
                                        "Register Add_Hist_Loop", "Deletion"] == "Y"):

                                        s = pd.DataFrame(dfRegister.Duns_No.unique(), columns=['Duns_No'])
                                        dfRegisterAll_Delete = dfRegisterAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfRegister.at[0,'Duns_No'], FileWithoutExtn, "Register Add_Hist_Loop", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Register Add_Hist_Loop", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])
                            else:
                                pass
                                logger.info("Register Add_Hist_Loop worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Register Add_Hist_Loop", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Register Add_Hist_Loop", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))

                        # if BoolCapital:
                        try:
                            dfCapital = pd.read_excel(filename, sheet_name='Capital',
                                                            index_col=None, na_values=['NA'],
                                                            usecols="A:G")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if not dfCapital.empty and (not dfCapital['Duns_No'].isnull().values.any()):
                                dfCapital.columns = ['Duns_No','Date of Change_rc (yyyy-mm-dd)',
                                                     'Type of Capital_mv',
                                                     'Increase/ decrease_rd',
                                                     'From INR_re',
                                                     'To INR_rf',
                                                     'FieldId']
                                # dfCapital['FieldId'] = dfCapital.groupby('Duns_No').cumcount() + 1
                                # dfCapital['FieldId'] = -dfCapital['FieldId'].astype(int)
                                df = self.ValidateDUNSNumber(dfCapital, logger)
                                dfCapital = df
                                if not dfCapital.empty:
                                    dfCapitalAll = dfCapitalAll.append(dfCapital)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfCapital.at[0,'Duns_No'], FileWithoutExtn, "Capital", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                    if (df_NonFin.at["Capital", "Looping/NonLooping"] == "L" and
                                            df_NonFin.at[
                                                "Capital", "Deletion"] == "Y"):
                                        s = pd.DataFrame(dfCapital.Duns_No.unique(), columns=['Duns_No'])
                                        dfCapitalAll_Delete = dfCapitalAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfCapital.at[0,'Duns_No'], FileWithoutExtn, "Capital", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Capital", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])

                            else:
                                pass
                                logger.info("Capital worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Capital", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Capital", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))

                        # if BoolLegal_Name:
                        try:
                            dfLegal_Name = pd.read_excel(filename, sheet_name='Legal_Name',
                                                            index_col=None, na_values=['NA'],
                                                            usecols="A:E")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if not dfLegal_Name.empty and (not dfCapital['Duns_No'].isnull().values.any()):
                                dfLegal_Name.columns = ['Duns_No',
                                                        'Old Name_kp',
                                                        'New Name_kq',
                                                        'Date of change_ks (yyyy-mm-dd)',
                                                        'FieldId']
                                # dfLegal_Name['FieldId'] = dfLegal_Name.groupby('Duns_No').cumcount() + 1
                                # dfLegal_Name['FieldId'] = -dfLegal_Name['FieldId'].astype(int)
                                df = self.ValidateDUNSNumber(dfLegal_Name, logger)
                                dfLegal_Name = df
                                if not dfLegal_Name.empty:
                                    dfLegal_NameAll = dfLegal_NameAll.append(dfLegal_Name)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfLegal_Name.at[0,'Duns_No'], FileWithoutExtn, "Legal_Name", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])

                                    if (df_NonFin.at["Legal_Name", "Looping/NonLooping"] == "L" and
                                            df_NonFin.at[
                                                "Legal_Name", "Deletion"] == "Y"):

                                        s = pd.DataFrame(dfLegal_Name.Duns_No.unique(), columns=['Duns_No'])
                                        dfLegal_NameAll_Delete = dfLegal_NameAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfLegal_Name.at[0,'Duns_No'], FileWithoutExtn, "Legal_Name", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Legal_Name", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])
                            else:
                                pass
                                logger.info("Legal_Name worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Legal_Name", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Legal_Name", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))

                        # if BoolOld_Address:
                        try:
                            dfOld_Address = pd.read_excel(filename, sheet_name='Old_Address',
                                                            index_col=None, na_values=['NA'],
                                                            usecols="A:J")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if (not dfOld_Address.empty) and (not dfCapital['Duns_No'].isnull().values.any()):
                                dfOld_Address.columns = ['Duns_No','Street Name1_bn','Street Name2_bo',
                                                         'Building_bq','City_ti','State_bv','Post Code_bw',
                                                         'Country_bx','Date of Change_bi (yyyy-mm-dd)','FieldId']
                                # dfOld_Address['FieldId'] = dfOld_Address.groupby('Duns_No').cumcount() + 1
                                # dfOld_Address['FieldId'] = -dfOld_Address['FieldId'].astype(int)
                                df = self.ValidateDUNSNumber(dfOld_Address, logger)
                                dfOld_Address = df
                                if not dfOld_Address.empty:
                                    dfOld_AddressAll = dfOld_AddressAll.append(dfOld_Address)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfOld_Address.at[0,'Duns_No'], FileWithoutExtn, "Old_Address", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                    if (df_NonFin.at["Old_Address", "Looping/NonLooping"] == "L" and
                                            df_NonFin.at[
                                                "Old_Address", "Deletion"] == "Y"):

                                        s = pd.DataFrame(dfOld_Address.Duns_No.unique(), columns=['Duns_No'])
                                        dfOld_AddressAll_Delete = dfOld_AddressAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfOld_Address.at[0,'Duns_No'], FileWithoutExtn, "Old_Address", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Old_Address", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])
                            else:
                                pass
                                logger.info("Old_Address worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Old_Address", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Old_Address", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))
                            continue

                        # if BoolNew_Address:
                        try:
                            dfNew_Address = pd.read_excel(filename, sheet_name='New_Address',
                                                            index_col=None, na_values=['NA'],
                                                            usecols="A:I")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if (not dfNew_Address.empty) and (not dfNew_Address['Duns_No'].isnull().values.any()):
                                dfNew_Address.columns = ['Duns_No','Street Name1_jj',
                                                         'Street Name2_jk','Building_jl',
                                                         'City_tb','State_jq','Post Code_jr',
                                                         'Country_js','FieldId']
                                # dfNew_Address['FieldId'] = dfNew_Address.groupby('Duns_No').cumcount() + 1
                                # dfNew_Address['FieldId'] = -dfNew_Address['FieldId'].astype(int)

                                df = self.ValidateDUNSNumber(dfNew_Address, logger)
                                dfNew_Address = df
                                if not dfNew_Address.empty:
                                    dfNew_AddressAll = dfNew_AddressAll.append(dfNew_Address)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfNew_Address.at[0,'Duns_No'], FileWithoutExtn, "New_Address", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                    if (df_NonFin.at["New_Address", "Looping/NonLooping"] == "L" and
                                            df_NonFin.at[
                                                "New_Address", "Deletion"] == "Y"):

                                        s = pd.DataFrame(dfNew_Address.Duns_No.unique(), columns=['Duns_No'])
                                        dfNew_AddressAll_Delete = dfNew_AddressAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfNew_Address.at[0,'Duns_No'], FileWithoutExtn, "New_Address", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "New_Address", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])


                            else:
                                pass
                                logger.info("New_Address worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "New_Address", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "New_Address", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))
                            continue

                        # if BoolLegal_Structure:
                        try:
                            dfLegal_Structure = pd.read_excel(filename, sheet_name='Legal_Structure',
                                                            index_col=None, na_values=['NA'],
                                                            usecols="A:G")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if (not dfLegal_Structure.empty) and (not dfLegal_Structure['Duns_No'].isnull().values.any()) :
                                dfLegal_Structure.columns = ['Duns_No',	'Old Legal structure_kt',
                                                             'New name of entity_lc',
                                                             'Date of Change_nn (yyyy-mm-dd)',
                                                             'old CIN_tk',
                                                             'new CIN_tl',
                                                             'FieldId']
                                # dfLegal_Structure['FieldId'] = dfLegal_Structure.groupby('Duns_No').cumcount() + 1
                                # dfLegal_Structure['FieldId'] = -dfLegal_Structure['FieldId'].astype(int)

                                df = self.ValidateDUNSNumber(dfLegal_Structure, logger)
                                dfLegal_Structure = df
                                if not dfLegal_Structure.empty:
                                    dfLegal_StructureAll = dfLegal_StructureAll.append(dfLegal_Structure)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfLegal_Structure.at[0,'Duns_No'], FileWithoutExtn, "Legal_Structure", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                    if (df_NonFin.at["Legal_Structure", "Looping/NonLooping"] == "L" and
                                            df_NonFin.at[
                                                "Legal_Structure", "Deletion"] == "Y"):

                                        s = pd.DataFrame(dfLegal_Structure.Duns_No.unique(), columns=['Duns_No'])
                                        dfLegal_StructureAll_Delete = dfLegal_StructureAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfLegal_Structure.at[0,'Duns_No'], FileWithoutExtn, "Legal_Structure", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Legal_Structure", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])
                            else:
                                pass
                                logger.info("Legal_Structure worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Legal_Structure", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Legal_Structure", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))
                            continue

                        # if BoolCourt_Orders:
                        try:
                            dfCourt_Orders = pd.read_excel(filename, sheet_name='Court_Orders',
                                                            index_col=None, na_values=['NA'],
                                                            usecols="A:E")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if (not dfCourt_Orders.empty) and (not dfCourt_Orders['Duns_No'].isnull().values.any()) :
                                dfCourt_Orders.columns = ['Duns_No','Merger/ Amalgamation_lh',
                                                          'Date on Event take place_lg (yyyy-mm-dd)',
                                                          'Other Party name_li',
                                                          'FieldId']
                                # dfCourt_Orders['FieldId'] = dfCourt_Orders.groupby('Duns_No').cumcount() + 1
                                # dfCourt_Orders['FieldId'] = -dfCourt_Orders['FieldId'].astype(int)

                                df = self.ValidateDUNSNumber(dfCourt_Orders, logger)
                                dfCourt_Orders = df
                                if not dfCourt_Orders.empty:
                                    dfCourt_OrdersAll = dfCourt_OrdersAll.append(dfCourt_Orders)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfCourt_Orders.at[0,'Duns_No'], FileWithoutExtn, "Court_Orders", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                    if (df_NonFin.at["Court_Orders", "Looping/NonLooping"] == "L" and
                                            df_NonFin.at[
                                                "Court_Orders", "Deletion"] == "Y"):
    
                                        s = pd.DataFrame(dfCourt_Orders.Duns_No.unique(), columns=['Duns_No'])
                                        dfCourt_OrdersAll_Delete = dfCourt_OrdersAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfCourt_Orders.at[0,'Duns_No'], FileWithoutExtn, "Court_Orders", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                        
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Court_Orders", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])

                            else:
                                pass
                                logger.info("Court_Orders worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Court_Orders", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Court_Orders", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))
                            continue

                        # if BoolAuditorsName:
                        try:
                            dfAuditorsName = pd.read_excel(filename, sheet_name='Auditors Name_Hist_Loop',
                                                            index_col=None, na_values=['NA'],
                                                            usecols="A:E")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if (not dfAuditorsName.empty) and (not dfAuditorsName['Duns_No'].isnull().values.any()) :
                                dfAuditorsName.columns = ['Duns_No','Company Name',
                                                          'Auditor Name__Hist__jx','Country__Hist__aj',
                                                          'FieldId']
                                # dfAuditorsName['FieldId'] = dfAuditorsName.groupby('Duns_No').cumcount() + 1
                                # dfAuditorsName['FieldId'] = -dfAuditorsName['FieldId'].astype(int)
                                df = self.ValidateDUNSNumber(dfAuditorsName, logger)
                                dfAuditorsName = df
                                if not dfAuditorsName.empty:
                                    dfAuditorsNameAll = dfAuditorsNameAll.append(dfAuditorsName)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfAuditorsName.at[0,'Duns_No'], FileWithoutExtn, "Auditors Name_Hist_Loop", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                    if (df_NonFin.at["Auditors Name_Hist_Loop", "Looping/NonLooping"] == "L" and
                                            df_NonFin.at[
                                                "Auditors Name_Hist_Loop", "Deletion"] == "Y"):

                                        s = pd.DataFrame(dfAuditorsName.Duns_No.unique(), columns=['Duns_No'])
                                        dfAuditorsNameAll_Delete = dfAuditorsNameAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfAuditorsName.at[0,'Duns_No'], FileWithoutExtn, "Auditors Name_Hist_Loop", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])

                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Auditors Name_Hist_Loop", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])

                            else:
                                pass
                                logger.info("Auditors Name_Hist_Loop worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Auditors Name_Hist_Loop", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Auditors Name_Hist_Loop", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))
                            continue

                        # if BoolSharecapital:
                        try:
                            dfSharecapital = pd.read_excel(filename, sheet_name='Share capital_History Non Loop',
                                                            index_col=None, na_values=['NA'],
                                                            usecols="A:Y")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if (not dfSharecapital.empty) and (not dfSharecapital['Duns_No'].isnull().values.any()) :
                                dfSharecapital.columns = ['Duns_No','Update Date_fb',
                                                          'Corporate Identification Number (CIN) of the company_fi',
                                                          'Authorised Capital_Equity','Authorised Capital_Preference',
                                                          'Authorised Capital Column _History_gj','Currency_History_gk',
                                                          'Issued Capital_Equity','Issued Capital_Preference',
                                                          'Issued Capital Column _History_gm','Currency_History_gn',
                                                          'Total amount of equity shares (in rupees) Subscribed capital rupees)_History_gt',
                                                          'PAR value _History_gu','Currency_History_gv',
                                                          'Total number of preference shares Subscribed capital_History_gx','PAR value_History_gy',
                                                          'Currency_History_gz','Paid up TYPE _history_hi','Paid up Capital_Equity',
                                                          'Paid up Capital_Preference','Amount _history_hj'
                                                         ,'Currency_History_hk','Capital As at_History_na',
                                                          'Last AGM Date_ju','FieldId']
                                df = self.ValidateDUNSNumber(dfSharecapital, logger)
                                dfSharecapital = df
                                if not dfSharecapital.empty:
                                    dfSharecapital['FieldId'] = dfSharecapital.groupby('Duns_No').cumcount() + 1
                                    dfSharecapital['FieldId'] = -dfSharecapital['FieldId'].astype(int)
                                    dfSharecapitalAll = dfSharecapitalAll.append(dfSharecapital)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfSharecapital.at[0,'Duns_No'], FileWithoutExtn, "Share capital_History Non Loop", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                    if (df_NonFin.at["Share capital_History Non Loop", "Looping/NonLooping"] == "L" and
                                            df_NonFin.at[
                                                "Auditors Name_Hist_Loop", "Deletion"] == "Y"):

                                        s = pd.DataFrame(dfSharecapital.Duns_No.unique(), columns=['Duns_No'])
                                        dfSharecapitalAll_Delete = dfSharecapitalAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfSharecapital.at[0,'Duns_No'], FileWithoutExtn, "Share capital_History Non Loop", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Share capital_History Non Loop", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])


                            else:
                                pass
                                logger.info("Share capital_History Non Loop worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Share capital_History Non Loop", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Auditors Name_Hist_Loop", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))
                            continue

                        # =============================Section Looping==================================
                        # if BoolMgmt:
                        try:
                            dfMgmt = pd.read_excel(filename, sheet_name="Management",
                                                            index_col=None, na_values=['NA'],
                                                            usecols="A:M")
                            # if dataframe is empty then just exit no further processing if it is not empty then first create delete file and then create insert file
                            if (not dfMgmt.empty) and (not dfMgmt['Duns_No'].isnull().values.any()):
                                dfMgmt.columns = ['Duns_No','Update Date__mgmt_EB (yyyy-mm-dd)',
                                                          'Corporate Dir_mgmt_IM  (Tick Box)',
                                                          'CEO_mgmt_EC (Tick Box)',
                                                          'Salutation _mgmt_ED (Mr/Mrs)',
                                                          'Name_mgmt_EE','Gender_mgmt_EJ (male/Female)',
                                                          'Identity Type_mgmt_EK','DIN/PAN_mgmt_EL',
                                                          'Designation_mgmt_FP',
                                                          'Date of Appointment_mgmt_FT (yyyy-mm-dd)',
                                                          'Active_mgmt_GJ (Tick Box)',
                                                          'SectionId']
                                # dfMgmt['FieldId'] = dfMgmt.groupby('Duns_No').cumcount() + 1
                                # dfMgmt['FieldId'] = -dfMgmt['FieldId'].astype(int)
                                df = self.ValidateDUNSNumber(dfMgmt, logger)
                                dfMgmt = df
                                if not dfMgmt.empty:
                                    dfMgmtAll = dfMgmtAll.append(dfMgmt)
                                    Status = "File Processed"
                                    StatsList.append(
                                        [dfMgmt.at[0,'Duns_No'], FileWithoutExtn, "Management", Status,
                                         str(today) + "_" + str(logtime),
                                         "Data Available - Insert Data"])
                                    if (df_NonFin.at["Auditors Name_Hist_Loop", "Looping/NonLooping"] == "L" and
                                            df_NonFin.at[
                                                "Management", "Deletion"] == "Y"):

                                        s = pd.DataFrame(dfMgmt.Duns_No.unique(), columns=['Duns_No'])
                                        dfMgmtAll_Delete = dfMgmtAll_Delete.append(s)
                                        Status = "File Processed"
                                        StatsList.append(
                                            [dfMgmt.at[0,'Duns_No'], FileWithoutExtn, "Management", Status,
                                             str(today) + "_" + str(logtime),
                                             "Data Available - Delete Data"])
                                else:
                                    pass
                                    logger.info("DUNS Number validation failed")
                                    Status = "File Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, "Management", Status,
                                         str(today) + "_" + str(logtime),
                                         "DUNS Number validation failed"])
                            else:
                                pass
                                logger.info("Management worksheet is empty")
                                Status = "File Processed"
                                StatsList.append(
                                    ["", FileWithoutExtn, "Management", Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])
                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["", FileWithoutExtn, "Auditors Name_Hist_Loop", Status, str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))
                            continue

                        os.remove(os.path.join(Inputdirectory, file))

                    except Exception as ex:
                        Status = 'File Not Processed'
                        StatsList.append(["",FileWithoutExtn,elapsed,Status,str(today)+"_"+str(logtime),
                                          str(ex)])
                        logger.error(filename)
                        # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                        logger.error(str(ex))
                        continue

                except Exception as ex:
                    Status = 'File Not Processed'
                    StatsList.append(["", FileWithoutExtn, elapsed, Status, str(today) + "_" + str(logtime),
                                      str(ex)])
                    logger.error(filename)
                    logger.error(str(ex))
                    continue

            logger.info("Process Completed")

            # Non Looping
            if not dfgeneralAll.empty:
                dfgeneralAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_generalAll.csv", index=False) if not dfgeneralAll.empty else ""
            if not dfParentAll.empty:
                dfParentAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_ParentAll.csv", index=False)
            if not dfFinancialAll.empty:
                dfFinancialAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_FinancialAll.csv", index=False)
            if not dfGeneralHoAll.empty:
                dfGeneralHoAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_GeneralHoAll.csv", index=False)

            # Looping
            if not dfGeneral_EXIMAll.empty:
                self.UpdateFieldIDDataframes(dfGeneral_EXIMAll, logger)
                dfGeneral_EXIMAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_General_EXIMAll.csv", index=False)
            if not dfGeneral_EXIMAll_Delete.empty:
                dfGeneral_EXIMAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_General_EXIMAll_Delete.csv", index=False)
            if not dfCinInvestAll.empty:
                self.UpdateFieldIDDataframes(dfCinInvestAll, logger)
                dfCinInvestAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_CinInvestAll.csv", index=False)
            if not dfCinInvestAll_Delete.empty:
                dfCinInvestAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_CinInvestAll_Delete.csv", index=False)
            if not dfEquityShHoldingAll.empty:
                self.UpdateFieldIDDataframes(dfEquityShHoldingAll, logger)
                dfEquityShHoldingAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_EquityShHoldingAll.csv", index=False)
            if not dfEquityShHoldingAll_Delete.empty:
                dfEquityShHoldingAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_EquityShHoldingAll_Delete.csv", index=False)
            if not dfSubsidiaryAll.empty:
                self.UpdateFieldIDDataframes(dfSubsidiaryAll, logger)
                dfSubsidiaryAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_SubsidiaryAll.csv", index=False)
            if not dfSubsidiaryAll_Delete.empty:
                dfSubsidiaryAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_SubsidiaryAll_Delete.csv", index=False)
            if not dfPrefShHoldingAll.empty:
                self.UpdateFieldIDDataframes(dfPrefShHoldingAll, logger)
                dfPrefShHoldingAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_PrefShHoldingAll.csv", index=False)
            if not dfPrefShHoldingAll_Delete.empty:
                dfPrefShHoldingAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_PrefShHoldingAll_Delete.csv", index=False)
            if not dfAffiliateAll.empty:
                self.UpdateFieldIDDataframes(dfAffiliateAll, logger)
                dfAffiliateAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_AffiliateAll.csv", index=False)
            if not dfAffiliateAll_Delete.empty:
                dfAffiliateAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_AffiliateAll_Delete.csv", index=False)
            if not dfCapitalAll.empty:
                self.UpdateFieldIDDataframes(dfCapitalAll, logger)
                dfCapitalAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_CapitalAll.csv", index=False)
            # if not dfCapitalAll_Delete.empty:
            #     dfCapitalAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_CapitalAll_Delete.csv", index=False)
            if not dfRegisterAll.empty:
                self.UpdateFieldIDDataframes(dfRegisterAll, logger)
                dfRegisterAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_RegisterAll.csv", index=False)
            if not dfRegisterAll_Delete.empty:
                dfRegisterAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_RegisterAll_Delete.csv", index=False)
            if not dfLegal_NameAll.empty:
                self.UpdateFieldIDDataframes(dfLegal_NameAll, logger)
                dfLegal_NameAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_Legal_NameAll.csv", index=False)
            # if not dfLegal_NameAll_Delete.empty:
            #     dfLegal_NameAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_Legal_NameAll_Delete.csv", index=False)
            if not dfOld_AddressAll.empty:
                self.UpdateFieldIDDataframes(dfOld_AddressAll, logger)
                dfOld_AddressAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_Old_AddressAll.csv", index=False)
            # if not dfOld_AddressAll_Delete.empty:
            #     dfOld_AddressAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_Old_AddressAll_Delete.csv", index=False)
            if not dfNew_AddressAll.empty:
                self.UpdateFieldIDDataframes(dfNew_AddressAll, logger)
                dfNew_AddressAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_New_AddressAll.csv", index=False)
            # if not dfNew_AddressAll_Delete.empty:
            #     dfNew_AddressAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_New_AddressAll_Delete.csv", index=False)
            if not dfLegal_StructureAll.empty:
                self.UpdateFieldIDDataframes(dfLegal_StructureAll, logger)
                dfLegal_StructureAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_Legal_StructureAll.csv", index=False)
            # if not dfLegal_StructureAll_Delete.empty:
            #     dfLegal_StructureAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_Legal_StructureAll_Delete.csv", index=False)
            if not dfCourt_OrdersAll.empty:
                self.UpdateFieldIDDataframes(dfCourt_OrdersAll, logger)
                dfCourt_OrdersAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_Court_OrdersAll.csv", index=False)
            # if not dfCourt_OrdersAll_Delete.empty:
            #     dfCourt_OrdersAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_Court_OrdersAll_Delete.csv", index=False)
            if not dfAuditorsNameAll.empty:
                self.UpdateFieldIDDataframes(dfAuditorsNameAll, logger)
                dfAuditorsNameAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_AuditorsNameAll.csv", index=False)
            if not dfAuditorsNameAll_Delete.empty:
                dfAuditorsNameAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_AuditorsNameAll_Delete.csv", index=False)
            if not dfSharecapitalAll.empty:
                self.UpdateFieldIDDataframes(dfSharecapitalAll, logger)
                dfSharecapitalAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_SharecapitalAll.csv", index=False)
            if not dfSharecapitalAll_Delete.empty:
                dfSharecapitalAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_SharecapitalAll_Delete.csv", index=False)
            if not dfMgmtAll.empty:
                self.UpdateFieldIDDataframes(dfMgmtAll, logger)
                dfMgmtAll.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_MgmtAll.csv", index=False)
            if not dfMgmtAll_Delete.empty:
                dfMgmtAll_Delete.to_csv(OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_MgmtAll_Delete.csv", index=False)


            # Upload CSV Files to Sharepoint
            MessageUploadOutput = self.SharepointOperation\
                ("Upload File",OutPutFileNonFinancial['OutPutFileNonFinancial'] + "Token_generalAll.csv",
                 logger,"CSV")
            if (MessageUploadOutput == "File uploaded"):
                logger.info("CSV files have been uploaded to sharepoint")

            # Upload files to FTP
            # cnopts = pysftp.CnOpts()
            # cnopts.hostkeys = None
            cnopts = pysftp.CnOpts()
            cnopts.hostkeys = paramiko.hostkeys.HostKeys(r'C:\Users\shethd\.ssh\known_hosts')

            hostName = "ftp.dnb.com"
            userName = "UBLT356IT"
            # userName = "UBLT356I"
            pswd = "P@ssW0rd@1234"

            try:
                with pysftp.Connection(host=hostName,username=userName,
                                       password=pswd,cnopts=cnopts) as sftp:
                    try:
                        logger.info("Connection established ... ")
                        # print(sftp.listdir())
                        with sftp.cd("/puts/"):
                            # print(sftp.listdir())
                            try:
                                # # Use put method to upload a file
                                # First trasfer all delete files
                                for file in os.listdir(Outputdirectory):
                                    try:
                                        if not file.endswith(".csv"):
                                            continue
                                        if 'Delete' in file:
                                            sftp.put(os.path.join(Outputdirectory,file), confirm = False)
                                            # , confirm = False
                                            FTPStats.append(
                                                [file, "FTP Transfer Successfull",str(today) + "_" + str(logtime),
                                                 "No Remarks"])
                                            time.sleep(1)
                                            os.remove(os.path.join(Outputdirectory, file))
                                    except Exception as ex:
                                        logger.error(str(ex))
                                        FTPStats.append(
                                            [file, "FTP Transfer Failed", str(today) + "_" + str(logtime),
                                             str(ex)])
                                        continue
                                # second trasfer all Insert files
                                for file in os.listdir(Outputdirectory):
                                    try:
                                        if not file.endswith(".csv"):
                                            continue
                                        if 'Delete' not in file:
                                            sftp.put(os.path.join(Outputdirectory,file), confirm = False)
                                            # , confirm = False
                                            FTPStats.append(
                                                [file, "FTP Transfer Successfull",str(today) + "_" + str(logtime),
                                                 "No Remarks"])
                                            time.sleep(1)
                                            os.remove(os.path.join(Outputdirectory, file))
                                    except Exception as ex:
                                        logger.error(str(ex))
                                        FTPStats.append(
                                            [file, "FTP Transfer Failed", str(today) + "_" + str(logtime),
                                             str(ex)])
                                        continue

                            except Exception as ex:
                                logger.error(str(ex))
                    except Exception as ex:

                        logger.error(str(ex))
                        FTPStats.append(
                            [file, "FTP Transfer Failed", str(today) + "_" + str(logtime),
                             str(ex)])

            except Exception as ex:
                logger.info("Connection Not established ... ")
                logger.error(str(ex))
                FTPStats.append(
                    [file, "FTP Transfer Failed", str(today) + "_" + str(logtime),
                     str(ex)])
            # Load stats file
            book = load_workbook(OutPutFileNonFinancial["OutPutFileNonFinancial"] + 'AutoNonFinancial_Stats.xlsx')
            writer = pd.ExcelWriter(OutPutFileNonFinancial["OutPutFileNonFinancial"] + 'AutoNonFinancial_Stats.xlsx',
                                    engine='openpyxl')
            writer.book = book
            writer.sheets = {ws.title: ws for ws in book.worksheets}

            DFSharepointFolderStatus = pd.concat([AutoFinancialObj.DFSharepointFolderDetails])

            DFSharepointFolderStatus.columns = ['Folder Name','File Count','Folder Status','ProcessedDateTime','File download Count']
            DFSharepointFolderStatus.to_excel(writer,sheet_name='Folder Stats',
                                              startrow=writer.sheets['Folder Stats'].max_row,
                                              index=False,header=False)
            Stats = Stats.append(pd.DataFrame(StatsList,columns=['DUNS Number','File Name','File Type','Status',
                                                       'Processed Date','Remarks']),ignore_index=True)
            Stats.to_excel(writer,sheet_name='File Stats',
                                              startrow=writer.sheets['File Stats'].max_row,
                                              index=False,header=False)

            FTPStatdf = FTPStatdf.append(pd.DataFrame(FTPStats, columns=['File Name', 'Status',
                                                                  'Processed Date', 'Remarks']), ignore_index=True)

            FTPStatdf.to_excel(writer, sheet_name='FTP Stats',
                           startrow=writer.sheets['FTP Stats'].max_row,
                           index=False, header=False)

            writer.save()
            book.save(OutPutFileNonFinancial["OutPutFileNonFinancial"] + 'AutoNonFinancial_Stats.xlsx')
            MessageUploadOutput = self.SharepointOperation("Upload File",
                                                           OutPutFileNonFinancial["OutPutFileNonFinancial"] + 'AutoNonFinancial_Stats.xlsx',
                                                           logger,"LOGS")
            if (MessageUploadOutput == "File uploaded"):
                logger.info("Output file has been uploaded to sharepoint")

        except Exception as ex:
            logger.error(str(ex))

            book = load_workbook(OutPutFileNonFinancial["OutPutFileNonFinancial"] + 'AutoNonFinancial_Stats.xlsx')
            writer = pd.ExcelWriter(OutPutFileNonFinancial["OutPutFileNonFinancial"] + 'AutoNonFinancial_Stats.xlsx',
                                    engine='openpyxl')
            writer.book = book
            writer.sheets = {ws.title: ws for ws in book.worksheets}

            DFSharepointFolderStatus = pd.concat([AutoFinancialObj.DFSharepointFolderDetails])
            # DFSharepointFolderStatus.to_excel(writer,sheet_name='Folder Stats')
            DFSharepointFolderStatus.columns = ['Folder Name', 'File Count', 'Folder Status', 'ProcessedDateTime',
                                                'File download Count']
            DFSharepointFolderStatus.to_excel(writer, sheet_name='Folder Stats',
                                              startrow=writer.sheets['Folder Stats'].max_row,
                                              index=False, header=False)
            Stats = Stats.append(pd.DataFrame(StatsList, columns=['DUNS Number', 'File Name', 'File Type', 'Status',
                                                                  'Processed Date', 'Remarks']), ignore_index=True)
            Stats.to_excel(writer, sheet_name='File Stats',
                           startrow=writer.sheets['File Stats'].max_row,
                           index=False, header=False)

            FTPStatdf = FTPStatdf.append(pd.DataFrame(FTPStats, columns=['File Name', 'Status',
                                                                         'Processed Date', 'Remarks']),
                                         ignore_index=True)

            FTPStatdf.to_excel(writer, sheet_name='FTP Stats',
                               startrow=writer.sheets['FTP Stats'].max_row,
                               index=False, header=False)

            writer.save()
            book.save(OutPutFileNonFinancial["OutPutFileNonFinancial"] + 'AutoNonFinancial_Stats.xlsx')
            MessageUploadOutput = self.SharepointOperation("Upload File",
                                                           OutPutFileNonFinancial[
                                                               "OutPutFileNonFinancial"] + 'AutoNonFinancial_Stats.xlsx',
                                                           logger, "LOGS")
            if (MessageUploadOutput == "File uploaded"):
                logger.info("Output file has been uploaded to sharepoint")

def main():

    try:
        # Defining Variables
        global logtime,today
        # Dataframe that stored Job running details
        jobhistory = pd.DataFrame()

        # Object creation for Logging module and Email class
        loggerObj = Logs()
        mailobj = mail()

        # Define time to set in the log file name
        logtime = str(datetime.now().strftime('%H_%M_%S'))
        today = date.today().strftime('%d_%m_%Y')

        # define the file name
        logfilename = "NonFinancialUpload.txt"
        logger = loggerObj.setup_logger('NonFinancialUpload_',LogFileNonFinancial["LogFileNonFinancial"] + logfilename)

        Obj1 = AutoNonFinancial()
        # logger.info("Process started = > Insert Query ")
        # OutputPath = ""
        LogStatsPath = settings_FinancialNonFinancial.get('team_site_url') + "/Shared%20Documents//SupremeCourt//AutoFin-NonFinUpload//Logs_Stats/"
        LogPath = settings_FinancialNonFinancial.get('team_site_url') + "/Shared%20Documents//SupremeCourt//AutoFin-NonFinUpload//Logs_Stats/"+ \
                  logfilename
        #
        ProcessStartTime = time.time()
        # data = [
        #     {'RunBy': 'AUTO','OutputFilePath': OutputPath,'LogPath': LogPath,'RunDuration': str(ProcessStartTime),
        #      'JobStatus': str('Running')}]
        # jobhistory = jobhistory.append(data,ignore_index=True)
        # # Obj1.ManageSQLConnection(jobhistory,logger,"Insert")
        Obj1.AutoNonFinancialProcess(logger)
        ProcessEndTime = time.time()
        #
        TotalElapsedTime = time.strftime("%H:%M:%S %Z",time.gmtime(ProcessEndTime - ProcessStartTime))
        #
        if not Stats.empty:

            df = Stats["Status"].value_counts()
            try:
                DataFound = [df.at['File Processed']]
            except Exception as ex:
                if str(ex) == "File Not Processed":
                    DataFound = [0]
            try:
                DataNotFound = [df.at['File Not Processed']]
            except Exception as ex:
                if str(ex.args).strip() == '(\'File Not Processed\',)':
                    DataNotFound = [0]

            try:
                details = {
                    "Total Files Run": [Stats.shape[0]],
                    "Success Files": DataFound,
                    "Failed Files": DataNotFound,
                    "Processed DateTime": [date.today().strftime('%d_%m_%Y')],
                    "Run By": 'Auto Trigger Process',
                    "Total Execution Time": str(TotalElapsedTime)
                }
            except Exception as ex:
                details = {
                    "Total Files Run": [Stats.shape[0]],
                    "Success Files": DataFound,
                    "Failed Files": DataNotFound,
                    "Processed DateTime": [date.today().strftime('%d_%m_%Y')],
                    "Run By": 'Auto Trigger Process',
                    "Total Execution Time": str(TotalElapsedTime)
                }

            # creating a Dataframe object with skipping
            # one column i.e skipping age column.
            df_stats = pd.DataFrame(details)

            output = build_table(df_stats,'orange_light',font_size='15px',text_align='center',width='auto',
                                 font_family='Open Sans,sans-serif')
            # send email only if files have failed in conversion
            if (DataNotFound !=[0]):
                mailobj.SendEmailToStakeHolders("Auto Non Financial Upload Status","DNBSystemMailDoNotReply@dnb.com",
                                                "shethd@dnb.com",output,"Non Financial Upload",LogStatsPath)

            logger.info(f"{TotalElapsedTime} seconds to process and upload all Auto Financial files")

            MessageUploadLog = Obj1.SharepointOperation("Upload File",
                                                        LogFileNonFinancial["LogFileNonFinancial"] + logfilename,
                                                        logger,"LOGS")

            if (MessageUploadLog == "File uploaded"):
                logger.info("log file has been uploaded to sharepoint")

            OutputPath = "No Output Path"
            data = [{'RunBy': 'AUTO','OutputFilePath': OutputPath,'LogPath': LogPath,
                     'RunDuration': str(TotalElapsedTime),'JobStatus': str('Success')}]
            # jobhistory = jobhistory.append(data,ignore_index=True)
            # Obj1.ManageSQLConnection(jobhistory,logger,"Update")
            print(f"{TotalElapsedTime} seconds to process and upload all Auto Financial files")
        else:
            OutputPath = "No Output Path"
            logger.info(f"No Files to Process")
            logger.info(f"{TotalElapsedTime} seconds to process and upload all Auto Financial files")

            MessageUploadLog = Obj1.SharepointOperation("Upload File",
                                                        LogFileNonFinancial["LogFileNonFinancial"] + logfilename,
                                                        logger,"LOGS")

            if (MessageUploadLog == "File uploaded"):
                logger.info("log file has been uploaded to sharepoint")

            OutputPath = "No Data"

            # data = [{'RunBy': 'AUTO','OutputFilePath': OutputPath,'LogPath': LogPath,
            #          'RunDuration': str(TotalElapsedTime),'JobStatus': str('Not Run')}]
            # jobhistory = jobhistory.append(data,ignore_index=True)
            # Obj1.ManageSQLConnection(jobhistory,logger,"Update")

        # Send email if FTP Transfer failes

        if not FTPStatdf.empty:

            df = FTPStatdf["Status"].value_counts()
            try:
                DataFound = [df.at['FTP Transfer Successfull']]
            except Exception as ex:
                if str(ex) == "FTP Transfer Failed":
                    DataFound = [0]
            try:
                DataNotFound = [df.at['FTP Transfer Failed']]
            except Exception as ex:
                if str(ex.args).strip() == '(\'FTP Transfer Failed\',)':
                    DataNotFound = [0]

            try:
                detailsFTP = {
                    "Total Files Run": [FTPStatdf.shape[0]],
                    "Success Files": DataFound,
                    "Failed Files": DataNotFound,
                    "Processed DateTime": [date.today().strftime('%d_%m_%Y')],
                    "Run By": 'Auto Trigger Process',
                    "Total Execution Time": str(TotalElapsedTime)
                }
            except Exception as ex:
                detailsFTP = {
                    "Total Files Run": [FTPStatdf.shape[0]],
                    "Success Files": DataFound,
                    "Failed Files": DataNotFound,
                    "Processed DateTime": [date.today().strftime('%d_%m_%Y')],
                    "Run By": 'Auto Trigger Process',
                    "Total Execution Time": str(TotalElapsedTime)
                }

            # creating a Dataframe object with skipping
            # one column i.e skipping age column.
            df_ftpstats = pd.DataFrame(detailsFTP)

            output = build_table(df_ftpstats, 'orange_light', font_size='15px', text_align='center', width='auto',
                                 font_family='Open Sans,sans-serif')
            # send email only if files have failed in conversion
            if (DataNotFound != [0]):
                mailobj.SendEmailToStakeHolders("Auto Non Financial Upload Status - FTP Transfer", "DNBSystemMailDoNotReply@dnb.com",
                                                "shethd@dnb.com", output, "Non Financial Upload", LogStatsPath)

            logger.info(f"{TotalElapsedTime} seconds to to process and upload all Auto Financial files")
        else:
            OutputPath = "No Data"
            logger.info(f"No Files to Process")

            logger.info(f"{TotalElapsedTime} seconds to process and upload all Auto Financial files")

            MessageUploadLog = Obj1.SharepointOperation("Upload File",
                                                        LogFileNonFinancial["LogFileNonFinancial"] + logfilename,
                                                        logger, "LOGS")

            if (MessageUploadLog == "File uploaded"):
                logger.info("log file has been uploaded to sharepoint")

            OutputPath = "No Data"

    except Exception as ex:
        logger.error(str(ex))
        mailobj.SendEmailToStakeHolders("Auto NonFinancial upload ERROR ","DNBSystemMailDoNotReply@dnb.com",
                                        "shethd@dnb.com",str(ex),"Non Financial Upload",LogPath)

if __name__ == '__main__':
    main()
    quit()