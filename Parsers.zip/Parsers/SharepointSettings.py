settings_dir12parsing = {
    'url': 'https://mydnb.sharepoint.com/',
    'team_site_url': "https://mydnb.sharepoint.com/sites/GDO_BIR_Docs_3/",
    'tenant': 'mydnb',
    # 'redirect_url': 'https://github.com/vgrem/Office365-REST-Python-Client/',
    'client_credentials': {
        'client_id': '6f019e4c-7f56-4e1c-80ab-9fea434def4e',
        'client_secret': 'tkYFp+5f1mjMJ2iZ9zk4DtnUjIlTHNd7LQzLFRjg9Iw='
    }
}

settings_AOC4parsing = {
    'url': 'https://mydnb.sharepoint.com/',
    'team_site_url': "https://mydnb.sharepoint.com/sites/PFM_Databuild_2021/",
    'tenant': 'mydnb',
    # 'redirect_url': 'https://github.com/vgrem/Office365-REST-Python-Client/',
    'client_credentials': {
        'client_id': '01233187-0a00-4770-bf31-2b7e2cb612f6',
        'client_secret': 'iDKM1w/v0aPwcLhOEiQNy3UNgUl/5CAOEAn9EBZ0Fk0='
    }
}

settings_FinancialNonFinancial = {
    'url': 'https://mydnb.sharepoint.com/',
    'team_site_url': "https://mydnb.sharepoint.com/sites/RMSCCAM/",
    'tenant': 'mydnb',
    # 'redirect_url': 'https://github.com/vgrem/Office365-REST-Python-Client/',
    'client_credentials': {
        'client_id': 'c8f85ae9-9394-4088-93b4-d76fb30e0478',
        'client_secret': '17qiDR7LXhJbx+q2S6y0P6aHDrHS+IR41NeUMgh5DvU='
    }
}

settings_ReportToDews = {
    'url': 'https://mydnb.sharepoint.com/',
    'team_site_url': "https://mydnb.sharepoint.com/sites/ReportToDews/",
    'tenant': 'mydnb',
    # 'redirect_url': 'https://github.com/vgrem/Office365-REST-Python-Client/',
    'client_credentials': {
        'client_id': '20f58a87-bd22-4d35-9278-574499d25a96',
        'client_secret': 'aDjm64vxoMCjPk5KbTUP4kHSVCxtjETU7eShZPn1NjI='
    }
}

