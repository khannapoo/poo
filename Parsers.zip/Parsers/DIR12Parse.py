import io
import logging
import os
import shutil
import traceback
import pandas as pd
from lxml import etree
import PyPDF2 as pypdf
from pathlib import Path
from SetLogger import Logs
from openpyxl import load_workbook
from DatabaseConfigFile import  *
from SharepointSettings import settings_dir12parsing
from office365.runtime.auth.client_credential import ClientCredential
from office365.sharepoint.client_context import ClientContext
from datetime import date, datetime,timedelta
import time

class PDFScraping:

    def findInDict(self,needle, haystack):
        for key in haystack.keys():
            try:
                value = haystack[key]
            except:
                continue
            if key == needle:
                return value
            if isinstance(value, dict):
                x =  self.findInDict(needle, value)
                if x is not None:
                    return x
    # Sharepoint Integration
    def SharepointOperation(self,action, file, CompanyName,logger):

        try:

            ctx = ClientContext(settings_dir12parsing.get('team_site_url')).with_credentials(
                ClientCredential(settings_dir12parsing['client_credentials']['client_id'],
                                 settings_dir12parsing['client_credentials']['client_secret']))

            if (action == "read"):
                # Read a file
                file_url = '/sites/BSEDocuments/Shared Documents/InputBSEFile/Input.xlsx'
                file = ctx.web.get_file_by_server_relative_url(file_url).execute_query()
                response = file.open_binary(ctx, file_url)

                bytes_file_obj = io.BytesIO()
                bytes_file_obj.write(response.content)
                bytes_file_obj.seek(0)
                df = pd.read_excel(bytes_file_obj)

                # # Empty Input Excel file
                # path =  DocumentdownloaddirectoryChrome["DownloadPath"]+"Input.xlsx"
                # # path= DocumentdownloaddirectoryChrome["DownloadPath"]+str(file)
                # # path = r"C:\Users\shethd\OneDrive - Dun and Bradstreet\Project\Actual_Work\PycharmProjects\CBIGDataIngestion\Downloads\AnnualReport_20192021-01-10_2.pdf"
                # with open(path, 'rb') as content_file:
                #     file_content = content_file.read()
                #
                # list_title = "InputBSEFile"
                # folder_url = '/Shared Documents/' + list_title
                # target_folder = ctx.web.get_folder_by_server_relative_url(folder_url)
                # name = os.path.basename(path)
                # target_folder.upload_file(name, file_content)
                # ctx.execute_query()

                return df

            elif (action == "create folder"):
                # Create folder
                # list_title = "Documents"
                # target_folder = ctx.web.lists.get_by_title(list_title).root_folder
                # today = date.today().strftime('%d_%m_%Y')
                # folder_name = today
                # target_folder.add(folder_name)
                # ctx.execute_query()
                # return "Folder has been created"
                today = date.today().strftime('%d_%m_%Y')
                Folder_URL = '/Shared Documents/Form Dir-12/Output_2020/'

                ctx.web.get_folder_by_server_relative_url(Folder_URL).add(
                    str(today))

                ctx.execute_query()
                return "Folder has been created"

            elif (action == "create dir12Output folder"):
                # Create folder

                today = date.today().strftime('%d_%m_%Y')
                folder_url = '/Shared Documents/' + str(today)
                ctx.web.get_folder_by_server_relative_url(folder_url).add(str("Dir12Output"))
                ctx.execute_query()
                logger.info("Dir12Output Folder has been created")
                return "Dir12Output Folder has been created"

            elif (action == "Upload File"):
                path = file
                # path= DocumentdownloaddirectoryChrome["DownloadPath"]+str(file)
                # path = r"C:\Users\shethd\OneDrive - Dun and Bradstreet\Project\Actual_Work\PycharmProjects\CBIGDataIngestion\Downloads\AnnualReport_20192021-01-10_2.pdf"
                with open(path, 'rb') as content_file:
                    file_content = content_file.read()
                today = date.today().strftime('%d_%m_%Y')
                list_title = str(today)
                folder_url = '/Shared Documents/Form Dir-12/Output_2020/' + list_title
                target_folder = ctx.web.get_folder_by_server_relative_url(folder_url)
                name = os.path.basename(path)
                target_file = target_folder.upload_file(name, file_content)
                ctx.execute_query()
                print("File url: {0}".format(target_file.serverRelativeUrl))
                return "File uploaded"

            elif (action == "Download File"):

                # folder_url = '/Shared Documents/' + "Form Dir-12/Dipti_Dir-12_Forms/"
                folder_url = '/Shared Documents/' + "Form Dir-12/Anjali_K_docs/Form DIR 12"
                # url = _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getbytitle('DocumentList')/items?$select=customerID&$top=1000";
                folder = ctx.web.get_folder_by_server_relative_url(folder_url)

                files = folder.files
                ctx.load(files)
                ctx.execute_query()
                fileNumber = 0

                # drive_items = remote_folder.children
                # ctx.load(drive_items)
                # ctx.execute_query()
                # for drive_item in drive_items:
                #     if not drive_item.file.is_server_object_null:  # is file?
                #         # download file content
                #         with open(os.path.join(local_path, drive_item.name), 'wb') as local_file:
                #             drive_item.download(local_file)
                #             client.execute_query()
                #         print("File '{0}' has been downloaded".format(local_file.name))



                for cur_file,i in zip(files,range(0,len(files))):
                    # if(i==2):
                    #     break

                    if(fileNumber==10):
                        break
                    download_FileName = os.path.join( InPutFileDIR12[
                                                     "InPutFileDIR12"], os.path.basename(cur_file.properties["Name"]))
                    file_url = "/sites/GDO_BIR_Docs_3/Shared Documents/Form Dir-12/Anjali_K_docs/Form DIR 12/" + str(
                        cur_file.properties["Name"])

                    # file1 = open("C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\PycharmProjects\\PDFParser\\MyFile.txt", "r")

                    # setting flag and index to 0
                    flag = 0
                    index = 0

                    # Loop through the file line by line
                    # for line in file1:
                    #     index  = index + 1
                    #
                    #     # checking string is present in line or not
                    #     if str(cur_file.properties["Name"]) in line:
                    #         flag = 1
                    #         break
                    #
                    #         # checking condition for string found or not
                    # if flag == 0:
                    #     print('String', download_FileName, 'Not Found')
                    # else:
                    #     print('String', download_FileName, 'Found In Line', index)

                    if(flag==0):
                        with open(download_FileName, "wb") as local_file:
                            file = ctx.web.get_file_by_server_relative_url(file_url).download(local_file).execute_query()
                            # file1 = open(
                            #     "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\PycharmProjects\\PDFParser\\MyFile.txt",
                            #     "a")
                            fileNumber = fileNumber+1
                            # stringFile = cur_file.properties["Name"]
                            # file1.write("\n")
                            # file1.writelines(stringFile)
                        # file.delete_object()
                        # ctx.execute_query()
                            print("File name: {0}".format(cur_file.properties["Name"]))

                return "Folder has been downloaded"

        except Exception as ex:
            logger.error(str(ex) + traceback.format_exc())

    def PdfParser(self,logger):

        listerror = []
        try:
            logger.info("\n***********************************************************")
            logger.info("Process Started ")
            directory = InPutFileDIR12["InPutFileDIR12"]
            df3_Brief = pd.DataFrame()
            today = str(
                date.today())

            now = datetime.now()
            # print(now.year, now.month, now.day, now.hour, now.minute, now.second)
            Time = str(str(now.hour)+"_"+str(now.minute))
            book = load_workbook( OutPutFileDIR12["OutPutFileDIR12"] + 'OutPut_DIR_2020.xlsx')
            worksheet = book.active
            writer = pd.ExcelWriter( OutPutFileDIR12["OutPutFileDIR12"] + 'OutPut_DIR_2020.xlsx', engine='openpyxl')
            writer.book = book
            writer.sheets = {ws.title: ws for ws in book.worksheets}

            MessageCreateTodayFolder = self.SharepointOperation("create folder", "", "",logger)
            if (MessageCreateTodayFolder.find('Folder has been created') != -1):
                logger.info("Step 1 : Folder with today's date created in sharepoint")

            MessageDownloadFolder = self.SharepointOperation("Download File", "", "",logger)
            if (MessageDownloadFolder.find('Folder has been downloaded') != -1):
                logger.info("Step 3 : FinishingTool Output Folder has been created")

            path, dirs, files = next(os.walk(directory))
            file_count = len(files)
            if (file_count!=0):

                for file in os.listdir(directory):
                    try:
                        filename = Path(os.path.join(directory, file))
                        filename = filename.name
                        FileWithoutExtn = os.path.splitext(filename)[0]
                        # if not file.endswith(".pdf"):
                        #     continue
                        with open(os.path.join(directory, file), 'rb') as pdfobject:

                            # pdfobject=open(r'C:\Users\shethd\OneDrive - Dun and Bradstreet\Dipti_C\Dipti\PDFParser\3_ELCON SOLAR_DIR-12 _U40108TG2012PTC083962.pdf','rb')

                            logger.info(" File In process : "+ FileWithoutExtn)
                            logger.info(FileWithoutExtn)
                            pdf = pypdf.PdfFileReader(pdfobject)
                            xfa = self.findInDict('/XFA', pdf.resolvedObjects)

                            xml = xfa[7].getObject().getData()
                            f = open(
                                 XMLOutPutFile["XMLOutPutFile"]+'myxmlfile3_' + FileWithoutExtn + '.xml',
                                "wb+")
                            f.write(xml)
                            f.close()

                            xml = xfa[13].getObject().getData()
                            f = open(
                                 XMLOutPutFile["XMLOutPutFile"]+'myxmlfile9_' + FileWithoutExtn + '.xml',
                                "wb+")
                            f.write(xml)
                            f.close()

                            logger.info(" XMLs have been generated ")
                            # =====================================================================================
                            logger.info(" Parsing Started from XML_9 ")
                            OtherList = [[]]
                            commomList = [[]]
                            counter = 0
                            hiAddress = ''
                            hiName = ''
                            LLPIName = ''
                            LLPINAdd = ''
                            ID_number = ''
                            columns = ['PresentAdd1_C', 'Full1_C', 'Birthdated1_D', 'Nationality1_N', 'Gender']
                            columns_commomList = ["hiAddress", "hiName", "LLPIName", "LLPINAdd", "ID_number"]
                            tree1 = etree.parse(( XMLOutPutFile["XMLOutPutFile"]+'myxmlfile9_' + FileWithoutExtn + '.xml'))
                            root1 = tree1.getroot()
                            # print(root1.findall('form', root1.nsmap))
                            for subform1 in root1.findall('subform/subformSet/subform', root1.nsmap):
                                # print(subform1)
                                for subform2 in subform1.findall('subform', root1.nsmap):
                                    # print(subform2)
                                    name = subform2.get('name')
                                    print(
                                        "=======================================================================================")
                                    if name == "Director1":
                                        for field in subform2.findall("field", root1.nsmap):
                                            # print(field)

                                            name = field.get('name')
                                            try:
                                                if name == "PresentAdd1_C":
                                                    for subfields in field.findall("value", root1.nsmap):
                                                        for subsubfield in subfields.findall("text", root1.nsmap):
                                                            PresentAdd1_C = subsubfield.text
                                                elif name == "Full1_C":
                                                    for subfields in field.findall("value", root1.nsmap):
                                                        for subsubfield in subfields.findall("text", root1.nsmap):
                                                            Full1_C = subsubfield.text
                                                elif name == "Birthdated1_D":
                                                    for subfields in field.findall("value", root1.nsmap):
                                                        for subsubfield in subfields.findall("date", root1.nsmap):
                                                            Birthdated1_D = subsubfield.text
                                                elif name == "Nationality1_N":
                                                    for subfields in field.findall("value", root1.nsmap):
                                                        for subsubfield in subfields.findall("date", root1.nsmap):
                                                            Nationality1_N = subsubfield.text
                                                elif name == "TextField1":
                                                    for subfields in field.findall("value", root1.nsmap):
                                                        for subsubfield in subfields.findall("text", root1.nsmap):
                                                            TextField1 = subsubfield.text


                                            except Exception as exmain:
                                                continue

                                        OtherList.append([PresentAdd1_C, Full1_C, Birthdated1_D, Nationality1_N, TextField1])
                                    elif name == "Page1":
                                        for field in subform2.findall("field", root1.nsmap):
                                            # print(field)
                                            name = field.get('name')
                                            try:

                                                if name == "hiAddress":
                                                    for subfields in field.findall("value", root1.nsmap):
                                                        for subsubfield in subfields.findall("text", root1.nsmap):
                                                            hiAddress = subsubfield.text
                                                elif name == "hiName":
                                                    for subfields in field.findall("value", root1.nsmap):
                                                        for subsubfield in subfields.findall("text", root1.nsmap):
                                                            hiName = subsubfield.text
                                                elif name == "LLPIName":
                                                    for subfields in field.findall("value", root1.nsmap):
                                                        for subsubfield in subfields.findall("text", root1.nsmap):
                                                            LLPIName = subsubfield.text
                                                elif name == "LLPINAdd":
                                                    for subfields in field.findall("value", root1.nsmap):
                                                        for subsubfield in subfields.findall("text", root1.nsmap):
                                                            LLPINAdd = subsubfield.text
                                                elif name == "ID_number":
                                                    for subfields in field.findall("value", root1.nsmap):
                                                        for subsubfield in subfields.findall("text", root1.nsmap):
                                                            ID_number = subsubfield.text
                                            except Exception as exmain:
                                                continue
                                        commomList.append([hiAddress, hiName, LLPIName, LLPINAdd, ID_number])

                            df1 = pd.DataFrame(OtherList, columns=columns)
                            # ======================================================================================
                            logger.info(" Parsing Started from XML_3 ")
                            tree = etree.parse(( XMLOutPutFile["XMLOutPutFile"]+'myxmlfile3_' + FileWithoutExtn + '.xml'))
                            root = tree.getroot()
                            root.findall('xfa:data', root.nsmap)
                            # columns = ['2.(a)Corporate Identity Number (CIN) of company','3.(a)Name of the company','(b)Address of the registered office of the company','MANDT',	'PARENT_GUID',	'SERIAL_NUM',	'SRN_NUM',	'i Director Identification Number (DIN)',	'RB_A_C_CD',	'DESIGNATION',	'DATE_APP_CD',	'CATEGORY',	'CB_CHAIRMAN',	'CB_EXEC_DIRECTOR',	'CB_N_EXE_DIR',	'DIN1',	'NAME_COMPANY',	'(c) E-mail ID of the company',	'DATE_CONFIRMATION',	'REASON',	'NUM_SUCH_ENTITIE',	'CIN_LLPIN_FCRN_R',	'C_GUID',	'NAME',	'ADDRESS',	'DESIGNATION1',	'PERCENTAGE_OF_SH',	'AMOUNT',	'OTHER_INTEREST']
                            columns = ['2.(a)Corporate Identity Number (CIN) of company', '3.(a)Name of the company',
                                       '(b)Address of the registered office of the company','(c) E-mail ID of the company',
                                       'i Director Identification Number (DIN)', 'Appointment_Cessation_ChangeInDesignation',
                                       'DESIGNATION', 'DATE_APP_CD',
                                       'CATEGORY', 'Chairman', 'Executive director', 'Non Executive Director',
                                       'xiii DIN of such director to whom appointee is alternate',
                                       'xv Name of the company or institution whose nominee the appointee is',
                                       'xvi E-mail ID of director',
                                       'xviii is not associated with the company with effect from (DD/MM/YYYY)',
                                       'xix due to', 'NUM_SUCH_ENTITIE',
                                       'CIN_LLPIN_FCRN_R', 'NAME', 'ADDRESS', 'DESIGNATION1', 'PERCENTAGE_OF_SH', 'AMOUNT',
                                       'OTHER_INTEREST',
                                       '4. Number of Managing director or director(s) for which the form is being filed']

                            DataList = [[]]
                            for item in root.findall('xfa:data', root.nsmap):
                                for data in item.findall('data'):
                                    for maindata in data.findall('ZNCAADDRESS'):
                                        Address = maindata.text
                                    for maindata in data.findall('ZNCACOMPANYNAME'):
                                        CompanyName = maindata.text
                                        # print(CompanyName)
                                    for maindata in data.findall('ZMCA_NCA_DIR_12'):
                                        for cin in maindata.findall("SRN_2_1_OR_CIN"):
                                            CIN = cin.text
                                        for NUM_MD_DIR in maindata.findall("NUM_MD_DIR"):
                                            NUM_MD_DIR = NUM_MD_DIR.text
                                        for CompanyEMAIL_ID in maindata.findall("EMAIL_ID"):
                                            CompanyEMAIL_ID = CompanyEMAIL_ID.text

                                    for z in data.findall('T_ZMCA_NCA_DIR12_M'):
                                        for DATA in z.findall("DATA"):
                                            print("---------------------------------------------------------------------------")

                                            for DIN in DATA.findall("DIN"):
                                                print(DIN.text)
                                            for RB_A_C_CD in DATA.findall("RB_A_C_CD"):
                                                print(RB_A_C_CD.text)
                                            for DESIGNATION in DATA.findall("DESIGNATION"):
                                                print(DESIGNATION.text)
                                            for DATE_APP_CD in DATA.findall("DATE_APP_CD"):
                                                print(DATE_APP_CD.text)
                                            for CATEGORY in DATA.findall("CATEGORY"):
                                                print(CATEGORY.text)
                                            for CB_CHAIRMAN in DATA.findall("CB_CHAIRMAN"):
                                                print(CB_CHAIRMAN.text)
                                            for CB_EXEC_DIRECTOR in DATA.findall("CB_EXEC_DIRECTOR"):
                                                print(CB_EXEC_DIRECTOR.text)
                                            for CB_N_EXE_DIR in DATA.findall("CB_N_EXE_DIR"):
                                                print(CB_N_EXE_DIR.text)
                                            for DIN1 in DATA.findall("DIN1"):
                                                print(DIN1.text)
                                            for NAME_COMPANY in DATA.findall("NAME_COMPANY"):
                                                print(NAME_COMPANY.text)
                                            for EMAIL_ID_DIR in DATA.findall("EMAIL_ID_DIR"):
                                                print(EMAIL_ID_DIR.text)
                                            for DATE_CONFIRMATN in DATA.findall("DATE_CONFIRMATN"):
                                                print(DATE_CONFIRMATN.text)
                                            for REASON in DATA.findall("REASON"):
                                                print(REASON.text)
                                            for CB_N_EXE_DIR in DATA.findall("CB_N_EXE_DIR"):
                                                print(CB_N_EXE_DIR.text)
                                            for NUM_SUCH_ENTITIE in DATA.findall("NUM_SUCH_ENTITIE"):
                                                print(NUM_SUCH_ENTITIE.text)
                                            for CIN_LLPIN_FCRN_R in DATA.findall("CIN_LLPIN_FCRN_R"):
                                                print(CIN_LLPIN_FCRN_R.text)

                                            for NAME in DATA.findall("NAME"):
                                                print(NAME.text)
                                            for ADDRESS in DATA.findall("ADDRESS"):
                                                print(ADDRESS.text)
                                            for DESIGNATION1 in DATA.findall("DESIGNATION1"):
                                                print(DESIGNATION1.text)
                                            for PERCENTAGE_OF_SH in DATA.findall("PERCENTAGE_OF_SH"):
                                                print(PERCENTAGE_OF_SH.text)
                                            for AMOUNT in DATA.findall("AMOUNT"):
                                                print(AMOUNT.text)
                                            for OTHER_INTEREST in DATA.findall("OTHER_INTEREST"):
                                                print(OTHER_INTEREST.text)
                                            # DataList.append([CIN,CompanyName,Address,MANDT.text,PARENT_GUID.text,SERIAL_NUM.text,SRN_NUM.text,DIN.text,RB_A_C_CD.text,DESIGNATION.text,DATE_APP_CD.text,CATEGORY.text,CB_CHAIRMAN.text,CB_EXEC_DIRECTOR.text,CB_N_EXE_DIR.text,DIN1.text,NAME_COMPANY.text,EMAIL_ID_DIR.text,
                                            #                  DATE_CONFIRMATN.text,REASON.text,NUM_SUCH_ENTITIE.text,CIN_LLPIN_FCRN_R.text,C_GUID.text,NAME.text,ADDRESS.text,DESIGNATION1.text,PERCENTAGE_OF_SH.text,AMOUNT.text,OTHER_INTEREST.text])
                                            DataList.append([CIN, CompanyName, Address,CompanyEMAIL_ID,
                                                             DIN.text,RB_A_C_CD.text, DESIGNATION.text, DATE_APP_CD.text,
                                                             CATEGORY.text,
                                                             CB_CHAIRMAN.text, CB_EXEC_DIRECTOR.text, CB_N_EXE_DIR.text,
                                                             DIN1.text,
                                                             NAME_COMPANY.text, EMAIL_ID_DIR.text,
                                                             DATE_CONFIRMATN.text, REASON.text, NUM_SUCH_ENTITIE.text,
                                                             CIN_LLPIN_FCRN_R.text,
                                                             NAME.text, ADDRESS.text, DESIGNATION1.text, PERCENTAGE_OF_SH.text,
                                                             AMOUNT.text, OTHER_INTEREST.text, NUM_MD_DIR])

                            df2 = pd.DataFrame(DataList, columns=columns)
                            df2["DESIGNATION"].replace({"DIRT": "Director"}, inplace=True)
                            df2["DESIGNATION"].replace({"ADDD": "Additional director"}, inplace=True)
                            df2["DESIGNATION"].replace({"MAND": "Managing director"}, inplace=True)
                            df2["DESIGNATION"].replace({"NOMD": "Nominee director"}, inplace=True)
                            df2["DESIGNATION"].replace({"WHTD": "Whole-time director"}, inplace=True)
                            df2["CATEGORY"].replace({"PMTR": "Promoter"}, inplace=True)
                            df2["CATEGORY"].replace({"INDP": "Independent"}, inplace=True)
                            df2["CATEGORY"].replace({"PROF": "Professional"}, inplace=True)
                            df2["Executive director"].replace({"EXEC": "Executive director"}, inplace=True)
                            df2["Non Executive Director"].replace({"NEXE": "Non Executive Director"}, inplace=True)
                            df2["Appointment_Cessation_ChangeInDesignation"].replace({"APPN": "Appointment"}, inplace=True)
                            df2["Appointment_Cessation_ChangeInDesignation"].replace({"RESG": "Cessation"}, inplace=True)
                            df2["Appointment_Cessation_ChangeInDesignation"].replace({"CHNG": "Change in designation"}, inplace=True)
                            df2["xix due to"].replace({"RESG": "Resignation u/s 168"}, inplace=True)
                            df2["xix due to"].replace({"DETH": "Death"}, inplace=True)

                            df2.replace('NONE', "", inplace=True)

                            df1.drop([0], inplace=True)
                            df2.drop([0], inplace=True)
                            df1.insert(0, 'New_ID', df1.index + 0)
                            df2.insert(0, 'New_ID', df1.index + 0)
                            result = pd.merge(df2, df1, on='New_ID')
                            logger.info(" File Completed : " + FileWithoutExtn)

                            dir_name =  XMLOutPutFile["XMLOutPutFile"]
                            xmlfiles = os.listdir(dir_name)
                            # Remove the XML files from the directory
                            for item in xmlfiles:
                                if item.endswith(".xml"):
                                    os.remove(os.path.join(dir_name, item))
                        logger.info(" Data Frame Filled ")
                        df3_Brief = df3_Brief.append(result)
                        try:
                            # pass
                            # Move the PDF files to success folder
                            # shutil.move( InPutFileDIR["InPutFileDIR"] + filename,  PorcessedPDFS["PorcessedPDFS"] + filename)
                            os.remove( InPutFileDIR12["InPutFileDIR12"] + filename)
                        except Exception as ex:
                            continue

                    except Exception as ex:
                        shutil.move( InPutFileDIR12["InPutFileDIR12"] + filename,
                                      FailedPDFS["FailedPDFS"] + filename)
                        listerror.append(filename)
                        logger.error(filename)
                        logger.error(str(ex))
                        continue
                if not df3_Brief.empty:
                    df_error = pd.DataFrame(listerror, columns=['ErrorFileName'])
                    df3_Brief.to_excel(writer, sheet_name='Success', startrow=writer.sheets['Success'].max_row,
                                 index=False,header=False)
                    df_error.to_excel(writer, sheet_name='Failed', startrow=writer.sheets['Failed'].max_row,
                                       index=False, header=False)
                    writer.save()
                    MessageUploadExcel = self.SharepointOperation("Upload File", OutPutFileDIR12["OutPutFileDIR12"] + 'OutPut_DIR_2020.xlsx', "",logger)
                    #
                    if (MessageUploadExcel == "File uploaded"):
                        logger.info("Success output file has been uploaded to sharepoint")
                    # ====================================================================================================
                    logger.info("******Process Completed" + str(datetime.now().strftime('%d_%m_%Y %H_%M_%S')) + "*******")
                    # ====================================================================================================
                else:
                    logger.info("DataFrame is Empty")
            else:
                logger.info("No files to Process")
        except Exception as ex:
            logger.error(str(ex))

def main():
    try:
        ProcessStartTime = time.time()
        loggerObj = Logs()
        global logtoday, logtime
        logtoday = date.today().strftime('%d-%m-%y')
        logtime = str(datetime.now().strftime('%H_%M_%S'))
        logger = loggerObj.setup_logger('DIR12 Parser',
                                         LogFileDIR12["LogFileDIR12"] + "DIR12 Parser_" + str(logtoday) + "_" + str(
                                            logtime) + ".txt")
        Obj1 = PDFScraping()
        Obj1.PdfParser(logger)
        ProcessEndTime = time.time()

        TotalElapsedTime = time.strftime("%H:%M:%S %Z", time.gmtime(ProcessEndTime - ProcessStartTime))

        #  OutPutFile["OutPutFile"] + 'OutPut_Non_XBRL_AOC_' + today + ".xlsx"

        logger.info(f"{TotalElapsedTime} seconds to scrape all DIR12 PDF Forms data.")
        logfilename = "DIR12 Parser_" + str(logtoday) + "_" + str(logtime) + ".txt"

        MessageUploadLog = Obj1.SharepointOperation("Upload File",
                                                     LogFileDIR12["LogFileDIR12"] + logfilename,
                                                    "", logger)

        if (MessageUploadLog == "File uploaded"):
            logger.info("log file has been uploaded to sharepoint")
            logging.shutdown()
            os.remove(os.path.join( LogFileDIR12["LogFileDIR12"], logfilename))
        print(f"{TotalElapsedTime} seconds to scrape all DIR12 PDF Forms data.")

    except Exception as ex:
        logger.error(str(ex))

if __name__ == '__main__':
    main()
    quit()