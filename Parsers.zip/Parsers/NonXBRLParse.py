import logging
from concurrent import futures
import concurrent
import io
import os
import shutil
import traceback
import pandas as pd
from lxml import etree
import PyPDF2 as pypdf
from pathlib import Path
from SetLogger import Logs
from office365.runtime.auth.client_credential import ClientCredential
from office365.sharepoint.client_context import ClientContext
from datetime import date, datetime,timedelta
import time
from datetime import date
from SendEmail import SendEmail as mail
import numpy as np
from pretty_html_table import build_table
from DatabaseConfigFile import  *
from SharepointSettings import settings_AOC4parsing
import pyodbc
# import sys
# sys.path.insert(0, 'C:\Users\shethd\OneDrive - Dun and Bradstreet\Dipti_C\Dipti\Stash_Code_Repository\DNBDataIngestSite\PyDocParser\ConfigFiles')
# from ConfigFiles import DatabaseConfigFile as dbcfg
# from ConfigFiles.SharepointSettings import settings_AOC4parsing

class PDFScraping:

    def ManageSQLConnection(self, df,logger,Action):
        
        try:

            sql_conn = pyodbc.connect(
                'DRIVER=' + mysql["DRIVER"] + ';SERVER=' + mysql["SERVER"] +
                ';DATABASE=' + mysql["DATABASE"] + ';UID=' + mysql["UID"] + ';PWD=' + mysql[
                    "PWD"] + '')
            cursor = sql_conn.cursor()
            cursor.fast_executemany = True

            sql_query = pd.read_sql_query(
                "SELECT * FROM [fileparser_inhousejobs] WHERE JobName='" + str(
                    AOCJobName["Job"]) + "'",
                sql_conn)

            # sql_query = pd.read_sql_query(
            #     "SELECT ID FROM [InhouseJOBS] WHERE JobName=%(JobName)s",{'JobName':str(AOCJobName["Job"])},
            #     sql_conn)
            JobID = sql_query['id']
            MY_TABLE = 'fileparser_jobhistory'
            df["JobID"] = JobID[0]
            if Action == "Insert":
                insert_to_tbl_stmt = "INSERT INTO [fileparser_jobhistory] (RunBy,OutputFilePath,LogPath,RunDuration,JobID_id,JobStatus) VALUES ('%s', '%s', '%s', '%s', %s, '%s')" %(df["RunBy"][0],df["OutputFilePath"][0], df["LogPath"][0], df["RunDuration"][0], df["JobID"][0],str(df["JobStatus"][0]))
                # insert_to_tbl_stmt='''INSERT INTO {MY_TABLE} ('RunBy','OutputFilePath','LogPath','RunDuration','JobID') VALUES (?,?,?,?,?) '''
                # insert_to_tmp_tbl_stmt = f"INSERT INTO {MY_TABLE} ('RunBy','OutputFilePath','LogPath','RunDuration','JobID') VALUES (?,?,?,?,?)"
                cursor.execute(insert_to_tbl_stmt)
                print(f'{len(df)} rows inserted to the {MY_TABLE} table')
            else:
                sql_query1 = pd.read_sql_query(
                    "SELECT TOP 1 * FROM [fileparser_jobhistory] ORDER BY id DESC",
                    sql_conn)
                JobHistoryID = sql_query1['id']
                # "Update [fileparser_jobhistory] set RunBy = ?,OutputFilePath= ?,LogPath= ?,RunDuration= ?,JobID_id= ?,JobStatus= ? where id = ?" %(df["RunBy"][0],df["OutputFilePath"][0], df["LogPath"][0], df["RunDuration"][0], df["JobID"][0],str(df["JobStatus"][0]))
                update_to_tbl_stmt = "Update [fileparser_jobhistory] set RunBy = '%s'," \
                                     "OutputFilePath= '%s'," \
                                     "LogPath= '%s',RunDuration='%s'," \
                                     "JobID_id= '%s',JobStatus= '%s' where id = '%s'" %(str(df["RunBy"][1]),str(df["OutputFilePath"][1]), str(df["LogPath"][1]), str(df["RunDuration"][1]), str(df["JobID"][1]),str(df["JobStatus"][1]),str(JobHistoryID[0]))
                # insert_to_tbl_stmt='''INSERT INTO {MY_TABLE} ('RunBy','OutputFilePath','LogPath','RunDuration','JobID') VALUES (?,?,?,?,?) '''
                # insert_to_tmp_tbl_stmt = f"INSERT INTO {MY_TABLE} ('RunBy','OutputFilePath','LogPath','RunDuration','JobID') VALUES (?,?,?,?,?)"
                cursor.execute(update_to_tbl_stmt)
                sql_conn.commit()
                print(f'{len(df)} rows updated to the {MY_TABLE} table')
            cursor.commit()
            cursor.close()
            sql_conn.close()

        except Exception as ex:
            logger.error("SQL Error")
            logger.error(str(ex))

    def __init__(self):
        self.DFSharepointFolderDetails = pd.DataFrame(columns=['Vendor Name','Folder Name','File Count','Folder Status'])

    def findInDict(self,needle, haystack):
        for key in haystack.keys():
            try:
                value = haystack[key]
            except:
                continue
            if key == needle:
                return value
            if isinstance(value, dict):
                x =  self.findInDict(needle, value)
                if x is not None:
                    return x

    def SharepointOperation(self,action, file, CompanyName,logger,df):
        global DFInputURLs,Month,datetime_object,month_name,Year,today
        Month = str(date.today().month)
        datetime_object = datetime.strptime(Month, "%m")
        month_name = datetime_object.strftime("%B")
        Year = date.today().year
        today = date.today().strftime('%d_%m_%Y')
        SharepointFolderDetails = []
        PDFScrapingObj = PDFScraping()
        try:

            ctx = ClientContext(settings_AOC4parsing.get('team_site_url')).with_credentials(
                ClientCredential(settings_AOC4parsing['client_credentials']['client_id'],
                                 settings_AOC4parsing['client_credentials']['client_secret']))

            if (action == "read"):
                # Read a file
                file_url = '/sites/PFM_Databuild_2021/Shared Documents/Dipti/In_Out_AOC_2021/Input_Vendor_URLs.xlsx'
                file = ctx.web.get_file_by_server_relative_url(file_url).execute_query()
                response = file.open_binary(ctx, file_url)

                bytes_file_obj = io.BytesIO()
                bytes_file_obj.write(response.content)
                bytes_file_obj.seek(0)
                DFInputURLs = pd.read_excel(bytes_file_obj)

                return DFInputURLs

            elif (action == "create folder"):
                # Create folder

                # Month = str(date.today().month)
                # datetime_object = datetime.strptime(Month, "%m")
                # month_name = datetime_object.strftime("%B")
                # Year = date.today().year
                # today = date.today().strftime('%d_%m_%Y')
                Folder_URL = '/Shared Documents/Dipti/'

                ctx.web.get_folder_by_server_relative_url(Folder_URL).add(
                    str("In_Out_AOC")+"_"+str(Year))

                ctx.execute_query()
                folder_url = '/Shared Documents/Dipti/' + str("In_Out_AOC")+"_"+str(Year)
                ctx.web.get_folder_by_server_relative_url(folder_url).add(month_name)
                ctx.execute_query()
                folder_url = folder_url+'/'+str(month_name)
                ctx.web.get_folder_by_server_relative_url(folder_url).add(today)
                ctx.execute_query()

                return "Folder has been created"

            elif (action == "Upload File"):
                path = file
                

                with open(path, 'rb') as content_file:
                    file_content = content_file.read()

                folder_url = '/Shared Documents/Dipti/' + str("In_Out_AOC")+"_"+str(Year)+'/'+str(month_name)+'/'+str(today)
                target_folder = ctx.web.get_folder_by_server_relative_url(folder_url)
                name = os.path.basename(path)
                target_file = target_folder.upload_file(name, file_content)
                ctx.execute_query()
                print("File url: {0}".format(target_file.serverRelativeUrl))
                return "File uploaded"

            elif (action == "Download File"):
                try:
                    Month = str(date.today().month)
                    datetime_object = datetime.strptime(Month, "%m")
                    month_name = datetime_object.strftime("%B")
                    Year = date.today().year
                    Yesterday = (datetime.now() - timedelta(1)).strftime('%d')
                    Count = 0


                    for row in df.itertuples():
                        try:
                            folder_url = '/Shared Documents/' + "Dipti/" + row[1] + "/" + str(month_name) + "_" + str(
                                Year) + "/" + str(Yesterday)
                            folders = ctx.web.get_folder_by_server_relative_url(folder_url).folders
                            ctx.load(folders)
                            ctx.execute_query()
                            AocFileListCount = []
                            # len(folders)
                            for folder, i in zip(folders, range(0, 3)):
                                try:
                                    # if (i == 20):
                                    #     break
                                    t0 = time.time()
                                    AocFileCoun = 0
                                    FolderName = str(folder.properties["Name"])
                                    files = folder.files
                                    ctx.load(files)
                                    ctx.execute_query()
                                    if (len(files)>0):
                                        List = [str(row[1]),FolderName, len(files), "File Available"]
                                    else:
                                        List = [str(row[1]),FolderName, len(files), "Folder Empty"]
                                    SharepointFolderDetails.append(List)

                                    PDFScrapingObj.DFSharepointFolderDetails.loc[
                                        len(PDFScrapingObj.DFSharepointFolderDetails)] = List
                                    for cur_file, i in zip(files, range(0, len(files))):

                                        if 'Form AOC-4-' in (str(cur_file.properties["Name"])):
                                            AocFileCoun = AocFileCoun+1
                                            # if (Count == 20):
                                            #     break
                                            # Count = Count + 1
                                            # download_FileName = os.path.join( InPutFile[
                                            #                     "InPutFile"],str(Count)+"_"+os.path.basename(cur_file.properties["Name"]))
                                            download_FileName = os.path.join(InPutFileAOCNonXBRL[
                                                                                 "InPutFileAOC4"],
                                                                             str(row[1])+"_"+FolderName + "_" + os.path.basename(
                                                                                 cur_file.properties["Name"]))
                                            file_url = "/sites/PFM_Databuild_2021/Shared Documents/"+ "Dipti/" + row[1] + "/" + str(month_name) + "_" + str(
                                                       Year) + "/" + str(Yesterday) + "/" + str(folder.properties["Name"]) + "/" + str(
                                                       cur_file.properties["Name"])

                                            fileTrackRead = open(
                                                 TrackFileDownload["TrackFileDownload"],
                                                "r")
                                            # setting flag and index to 0
                                            flag = 0
                                            index = 0
                                            # Loop through the file line by line
                                            # for line in fileTrackRead:
                                            #     if str(str(row[1])+"_"+FolderName+"_"+cur_file.properties["Name"]) in line:
                                            #         flag = 1
                                            #         break
                                            #         # checking condition for string found or not
                                            # if flag == 0:
                                            #     print('String', download_FileName, 'Not Found')
                                            # else:
                                            #     print('String', download_FileName, 'Found In Line', index)
                                            if (flag == 0):
                                                with open(download_FileName, "wb") as local_file:
                                                    file = ctx.web.get_file_by_server_relative_url(file_url).download(
                                                        local_file).execute_query()
                                                    fileTrack = open(
                                                         TrackFileDownload["TrackFileDownload"],
                                                        "a")
                                                    stringFile = str(row[1])+"_"+FolderName+"_"+cur_file.properties["Name"]
                                                    # fileTrack.write("\n")
                                                    # fileTrack.writelines(stringFile)
                                                    # file.delete_object()
                                                    # ctx.execute_query()
                                                logger.info("File name: {0}".format(str(row[1])+"_"+FolderName+"_"+cur_file.properties["Name"]))
                                    AocFileListCount.append(AocFileCoun)
                                except Exception as ex:
                                    logger.error(str(ex) + traceback.format_exc())
                                    continue


                        except Exception as ex:
                            logger.error(str(ex) + traceback.format_exc())
                            continue
                    if len(folders)!=0:
                        t1 = time.time()
                        AocSeries = pd.Series(AocFileListCount)
                        PDFScrapingObj.DFSharepointFolderDetails["AocFileCount"]=AocSeries
                        elapsed = time.strftime("%H:%M:%S %Z", time.gmtime(t1 - t0))

                        logger.info("Folder has been downloaded")
                        logger.info("Total time to download the files is " + str(elapsed))
                        return "Folder has been downloaded", PDFScrapingObj
                    else:
                        logger.info("No folders to download")
                        return "Folder has not been downloaded", PDFScrapingObj
                except Exception as ex:
                    logger.error(str(ex) + traceback.format_exc())
                    logger.error(str(folder.properties["Name"]) + "Folder has not been downloaded" )
                    return "Folder has not been downloaded",PDFScrapingObj

        except Exception as ex:
            logger.error(str(ex) + traceback.format_exc())

    def PdfParser(self,logger):

        listerror = []
        loggerObj1 = Logs()
        loggerObj2 = Logs()
        loggerObj3 = Logs()
        global Stats
        Stats = pd.DataFrame(columns=['File Name','Name of the company','Processing Time','Status','Processed Date','Remarks'],)

        try:
            logger.info("Process Started " + str(datetime.now().strftime('%d_%m_%Y %H_%M_%S')))

            logger.info("***********************************************************")
            logger.info("Process Started ")
            directory = InPutFileAOCNonXBRL["InPutFileAOC4"]
            # today = datetime.now().strftime('%d-%m-%Y %H-%M-%S')
            Time=time.time()
            MessageCreateTodayFolder = self.SharepointOperation("create folder", "", "",logger,"")
            if (MessageCreateTodayFolder.find('Folder has been created') != -1):
                logger.info("Step 1 : Folder with today's date created in sharepoint")

            logger.info("Step 2 : Read Input Data From Sharepoint")
            df = self.SharepointOperation("read", "", "",logger,"")
            index = df.index
            number_of_rows = len(index)
            if (number_of_rows==1 or number_of_rows==2 ):
                df_split =np.array_split(df, 1)
                master_list=[]
                logger1 = loggerObj1.setup_logger('SharePointLog1',
                                        LogFileAOC["LogFileAOC"] + "SharePointLog1_" + str(logtoday) + "_" + str(
                                           logtime) + ".txt")
                # loggerObj2.setup_logger('SharePointLog2',
                #                          LogFileAOC["LogFileAOC"] + "SharePointLog2_" + str(logtoday) + "_" + str(
                #                             logtime) + ".txt")
                # loggerObj3.setup_logger('SharePointLog3',
                #                          LogFileAOC["LogFileAOC"] + "SharePointLog3_" + str(logtoday) + "_" + str(
                #                             logtime) + ".txt")
                # logger1 = logging.getLogger('SharePointLog1')
                # logger2 = logging.getLogger('SharePointLog2')
                # logger3 = logging.getLogger('SharePointLog3')

                with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:

                    # futures = [executor.submit(self.SharepointOperation,"Download File", "", "",logger,df_split[i]) for i in range(0,2)]
                    future1 = executor.submit(self.SharepointOperation,"Download File", "", "",logger1,df_split[0])
                    # future2 = executor.submit(self.SharepointOperation, "Download File", "", "", logger2, df_split[1])
                    # future3 = executor.submit(self.SharepointOperation, "Download File", "", "", logger3, df_split[2])

                    MessageDownloadFolder,PDFScrapingObj1 =future1.result()

                    # MessageDownloadFolder, PDFScrapingObj2 =future2.result()
                    #
                    # MessageDownloadFolder, PDFScrapingObj3 = future3.result()
            elif (number_of_rows>2):
                # read vendors
                df_split = np.array_split(df, 3)
                master_list = []
                logger1=loggerObj1.setup_logger('SharePointLog1',
                                         LogFileAOC["LogFileAOC"] + "SharePointLog1_" + str(logtoday) + "_" + str(
                                            logtime) + ".txt")
                logger2=loggerObj2.setup_logger('SharePointLog2',
                                         LogFileAOC["LogFileAOC"] + "SharePointLog2_" + str(logtoday) + "_" + str(
                                            logtime) + ".txt")
                logger3=loggerObj3.setup_logger('SharePointLog3',
                                         LogFileAOC["LogFileAOC"] + "SharePointLog3_" + str(logtoday) + "_" + str(
                                            logtime) + ".txt")
                # logger1 = logging.getLogger('SharePointLog1')
                # logger2 = logging.getLogger('SharePointLog2')
                # logger3 = logging.getLogger('SharePointLog3')

                with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:

                    # futures = [executor.submit(self.SharepointOperation,"Download File", "", "",logger,df_split[i]) for i in range(0,2)]
                    future1 = executor.submit(self.SharepointOperation, "Download File", "", "", logger1, df_split[0])
                    future2 = executor.submit(self.SharepointOperation, "Download File", "", "", logger2, df_split[1])
                    future3 = executor.submit(self.SharepointOperation, "Download File", "", "", logger3, df_split[2])

                    MessageDownloadFolder, PDFScrapingObj1 = future1.result()
                    MessageDownloadFolder, PDFScrapingObj2 =future2.result()
                    MessageDownloadFolder, PDFScrapingObj3 = future3.result()
            count_of_files = os.listdir(directory)
            if len(count_of_files) != 0:
                shutil.copy( AOC4Template["AOC4Template"] +'Non Xbrl Structure.xlsx',
                             OutPutFile["OutPutFile"]+'OutPut_Non_XBRL_AOC_'+today+"_"+logtime+ ".xlsx")
                writer = pd.ExcelWriter( OutPutFile["OutPutFile"]+'OutPut_Non_XBRL_AOC_'+today+"_"+logtime+ ".xlsx",
                    engine='xlsxwriter')

                dfFinancial_BalanceSheet1 = pd.DataFrame()
                dfFinancial_BalanceSheet2 = pd.DataFrame()
                dfGeneral_information_of_the_comp=pd.DataFrame()
                dfHolding_Company = pd.DataFrame()
                dfSubsidiary = pd.DataFrame()
                dfAuditors = pd.DataFrame()
                dfFinancial_PNL1 = pd.DataFrame()
                dfFinancial_PNL2 = pd.DataFrame()
                dfLongTerm_Borrowings_unsecuredCR = pd.DataFrame()
                dfLongTerm_Borrowings_unsecuredPR = pd.DataFrame()
                dfShortTerm_Borrowing_securedCR= pd.DataFrame()
                dfShortTerm_Borrowing_securedPR = pd.DataFrame()
                dfLongterm_loans_unsecured_goodCR= pd.DataFrame()
                dfLongterm_loans_unsecured_goodPR = pd.DataFrame()
                dflongterm_loans_doubtful_CR= pd.DataFrame()
                dflongterm_loans_doubtful_PR = pd.DataFrame()
                dfTradereceivables_CR=pd.DataFrame()
                dfTradereceivables_PR = pd.DataFrame()
                dfFinancial_Parameters_BS = pd.DataFrame()
                dfImport_Export_Data_CR= pd.DataFrame()
                dfImport_Export_Data_PR = pd.DataFrame()
                dfFinancial_Parameters_PNL= pd.DataFrame()
                dfPrincipal_productsor_services= pd.DataFrame()
                dfAuditors_Comment= pd.DataFrame()
                dfOther_Information= pd.DataFrame()
                dfCSR1 = pd.DataFrame()
                dfCSR2 = pd.DataFrame()
                dfCSR3 = pd.DataFrame()

                dfZMCA_NCA_AOC_4=pd.DataFrame()
                dfZMCA_NCA_AOC4_II=pd.DataFrame()
                ZMCA_NCA_AOC_4,ZMCA_NCA_AOC4_II,T_ZNCA_AOC_4_S10,T_ZMCA_NCA_AOC4_S9,\
                T_ZNCA_AOC_4_SII_4,T_ZNCA_AOC_4_SIII = [[]],[[]],[[]],[[]],[[]],[[]]
                CIN,FY_START_DATE,FY_END_DATE,NUM_SUBSIDARY_CM,RB_SUBSIDARY_CMP='','','','',''
                StatsList=[]
                i=0

                for file in os.listdir(directory):
                    try:
                        i=i+1
                        filename = Path(os.path.join(directory, file))
                        filename = filename.name
                        FileWithoutExtn = os.path.splitext(filename)[0]
                        Status = 'No Data Found'
                        # if not (file.endswith(".pdf")):
                        #     Status = 'No Data Found'
                        #     StatsList.append([FileWithoutExtn, "", "", Status, date.today().strftime('%d-%m-%y'),
                        #                  "Extension or file name not correct"])
                        #     continue
                        with open(os.path.join(directory, file), 'rb') as pdfobject:
                            t0 = time.time()
                            # pdfobject=open(r'C:\Users\shethd\OneDrive - Dun and Bradstreet\Dipti_C\Dipti\PDFParser\3_ELCON SOLAR_DIR-12 _U40108TG2012PTC083962.pdf','rb')

                            logger.info(" File In process : "+ FileWithoutExtn)
                            logger.info(FileWithoutExtn)
                            pdf = pypdf.PdfFileReader(pdfobject)
                            xfa = self.findInDict('/XFA', pdf.resolvedObjects)

                            xml = xfa[7].getObject().getData()
                            f = open(XMLOutPutFile["XMLOutPutFile"]+'myxmlfile3_' + FileWithoutExtn + '.xml',
                                "wb+")
                            f.write(xml)
                            f.close()

                            xml = xfa[13].getObject().getData()
                            f = open(
                                 XMLOutPutFile["XMLOutPutFile"]+'myxmlfile9_' + FileWithoutExtn + '.xml',
                                "wb+")
                            f.write(xml)
                            f.close()

                            logger.info(" XMLs have been generated ")

                            logger.info(" Parsing Started from XML_3 ")
                            tree = etree.parse(( XMLOutPutFile["XMLOutPutFile"]+'myxmlfile3_' + FileWithoutExtn + '.xml'))
                            root = tree.getroot()


                            list_of_rows=[[]]
                            for item in root.findall('xfa:data', root.nsmap):
                                for data in item.findall('data'):
                                    try:
                                        Company_Name=''
                                        for maindata in data.findall('ZNCA_AOC_4_CFS'):
                                            try:
                                                for NATURE_OF_FS in maindata.findall("NATURE_OF_FS"):
                                                    NATURE_OF_FS = 'Adopted consolidated financial statements'
                                            except Exception as ex:
                                                logger.error(str(ex) + str('ZNCA_AOC_4_CFS'))
                                                continue
                                        for maindata in data.findall('ZMCA_NCA_AOC_4'):
                                            try:
                                                for NATURE_OF_FS in maindata.findall("NATURE_OF_FS"):
                                                    NATURE_OF_FS=  'Adopted financial statements'
                                            except Exception as ex:
                                                logger.error(str(ex) + str(ZMCA_NCA_AOC_4))
                                                continue
                                        if (NATURE_OF_FS=='Adopted financial statements'):
                                            for maindata in data.findall('HI_COMP_NAME'):
                                                Company_Name = maindata.text
                                            for maindata in data.findall('HI_COMPANYNAME'):
                                                Company_Name = maindata.text
                                        # ====================================================
                                        # Company Details, I. Balance Sheet, Debantures
                                        # ====================================================
                                        # for maindata in data.findall('ZMCA_NCA_AOC_4'):
                                        #     try:
                                        #         Additional_Columns1 = ["File Name","DUNS","Company_Name"]
                                        #         # Columns_ZMCA_NCA_AOC_4 = [c.tag for c in maindata]
                                        #         # print(Columns_ZMCA_NCA_AOC_4)
                                        #         if(Company_Name=='AARLIP DECOR AND FURNISHING PRIVATE LIMITED'):
                                        #             pass
                                        #         # if (len(Columns_ZMCA_NCA_AOC_4) == 326):
                                        #         Columns_ZMCA_NCA_AOC_4=Additional_Columns1+Columns_ZMCA_NCA_AOC_4
                                        #         # else:
                                        #         #     break
                                        #         Additional_Values = [FileWithoutExtn,"", Company_Name]
                                        #         List = [maindata.attrib.get()]
                                        #         # List = [c.text for c in maindata]
                                        #         # if (len(List) == 326):
                                        #         List = Additional_Values + List
                                        #         ZMCA_NCA_AOC_4.append(List)
                                        #         for  DATE_CURR_REP in maindata.findall("DATE_CURR_REP"):
                                        #             DATE_CURR_REP=  DATE_CURR_REP.text
                                        #         for RB_SUBSIDARY_CMP in maindata.findall("RB_SUBSIDARY_CMP"):
                                        #             RB_SUBSIDARY_CMP = RB_SUBSIDARY_CMP.text
                                        #         for NUM_SUBSIDARY_CM in maindata.findall("NUM_SUBSIDARY_CM"):
                                        #             NUM_SUBSIDARY_CM = NUM_SUBSIDARY_CM.text
                                        #         for CIN in maindata.findall("CIN"):
                                        #             CIN = CIN.text
                                        #         for FY_START_DATE in maindata.findall("FY_START_DATE"):
                                        #             FY_START_DATE=FY_START_DATE.text
                                        #         for DATE_BOD_MEETING in maindata.findall('DATE_BOD_MEETING'):
                                        #             DATE_BOD_MEETING=DATE_BOD_MEETING.text
                                        #         for DATE_AGM in maindata.findall('DATE_AGM'):
                                        #             DATE_AGM = DATE_AGM.text
                                        #         break
                                        #     except Exception as ex:
                                        #         logger.error(str(ex)+str(ZMCA_NCA_AOC_4))
                                        #         continue
                                            for maindata in data.findall('ZMCA_NCA_AOC_4'):
                                                try:
                                                    Columns_T_ZNCA_AOC_4_SII_4, \
                                                    Columns_T_ZNCA_AOC_4_S10, Columns_T_ZMCA_NCA_AOC4_S9, \
                                                    Columns_ZMCA_NCA_AOC4_II, Columns_T_ZNCA_AOC_4_SIII = [], [], [], [], []
                                                    Status="Data Found"

                                                    Additional_Columns1 = ["File Name","DUNS","Company_Name"]
                                                    Columns_ZMCA_NCA_AOC_4 = [c.tag for c in maindata]
                                                    Columns_ZMCA_NCA_AOC_4 = Additional_Columns1 + Columns_ZMCA_NCA_AOC_4
                                                    # if (Company_Name == 'AARLIP DECOR AND FURNISHING PRIVATE LIMITED' or Company_Name=='ARREMM HOLDINGS PRIVATE LIMITED'):
                                                    Additional_Values = [FileWithoutExtn, "", Company_Name]
                                                    List = [c.text for c in maindata]
                                                    List = Additional_Values + List
                                                    ZMCA_NCA_AOC_4=[List]
                                                    df = pd.DataFrame(ZMCA_NCA_AOC_4, columns=Columns_ZMCA_NCA_AOC_4)
                                                    df = df.loc[:, ~df.columns.duplicated()]
                                                    dfZMCA_NCA_AOC_4 = dfZMCA_NCA_AOC_4.append(df)
                                                    # for NATURE_OF_FS in maindata.findall("DATE_CURR_REP"):
                                                    #     NATURE_OF_FS=  NATURE_OF_FS.text
                                                    for  DATE_CURR_REP in maindata.findall("DATE_CURR_REP"):
                                                        DATE_CURR_REP=  DATE_CURR_REP.text
                                                    for  DATE_PREV_REP in maindata.findall("DATE_PREV_REP"):
                                                        DATE_PREV_REP=  DATE_PREV_REP.text
                                                    for RB_SUBSIDARY_CMP in maindata.findall("RB_SUBSIDARY_CMP"):
                                                        RB_SUBSIDARY_CMP = RB_SUBSIDARY_CMP.text
                                                    for NUM_SUBSIDARY_CM in maindata.findall("NUM_SUBSIDARY_CM"):
                                                        NUM_SUBSIDARY_CM = NUM_SUBSIDARY_CM.text
                                                    for CIN in maindata.findall("CIN"):
                                                        CIN = CIN.text
                                                    for FY_START_DATE in maindata.findall("FY_START_DATE"):
                                                        FY_START_DATE=FY_START_DATE.text
                                                    for FY_END_DATE in maindata.findall("FY_END_DATE"):
                                                        FY_END_DATE = FY_END_DATE.text
                                                    for DATE_BOD_MEETING in maindata.findall('DATE_BOD_MEETING'):
                                                        DATE_BOD_MEETING=DATE_BOD_MEETING.text
                                                    for DATE_AGM in maindata.findall('DATE_AGM'):
                                                        DATE_AGM = DATE_AGM.text
                                                        break
                                                except Exception as ex:
                                                    logger.error(str(ex) + str(ZMCA_NCA_AOC_4))
                                                    continue


                                            # ====================================================
                                            # Whether the company has a subsidiary company as defined under clause (87) of section 2
                                            # ====================================================
                                            for maindata in data.findall('T_ZMCA_NCA_AOC4_S9'):
                                                try:
                                                    Additional_Columns = ["File Name","DUNS","Company_Name","CIN",
                                                                          'Whether the company has a subsidiary company as defined under clause (87) of section 2',
                                                                          'If yes, then indicate number of subsidiary company(ies)'
                                                                          ]
                                                    for subdata in maindata.findall('DATA'):
                                                        Columns_T_ZMCA_NCA_AOC4_S9 = [c.tag for c in subdata]
                                                        Columns_T_ZMCA_NCA_AOC4_S9=Additional_Columns+Columns_T_ZMCA_NCA_AOC4_S9+\
                                                                               ["FY_END_DATE","DATE_AGM"]
                                                        break


                                                    Additional_Values = [FileWithoutExtn,"",Company_Name,CIN,RB_SUBSIDARY_CMP,NUM_SUBSIDARY_CM]
                                                    for subdata in maindata.findall('DATA'):
                                                        List = [c.text for c in subdata]
                                                        List = Additional_Values + List + [FY_END_DATE] + [DATE_AGM]
                                                        T_ZMCA_NCA_AOC4_S9.append(List)
                                                except Exception as ex:
                                                    logger.error(str(ex)+str(T_ZMCA_NCA_AOC4_S9))
                                                    continue
                                            # ====================================================
                                            # SEGMENT II: INFORMATION AND PARTICULARS IN RESPECT OF PROFIT AND LOSS ACCOUNT
                                            # ====================================================
                                            for maindata in data.findall('ZMCA_NCA_AOC4_II'):
                                                try:
                                                    Additional_Columns = ["File Name", "DUNS", "Company_Name","CIN","DATE_CURR_REP","DATE_PREV_REP"]
                                                    Columns_ZMCA_NCA_AOC4_II = [c.tag for c in maindata]
                                                    Columns_ZMCA_NCA_AOC4_II = Additional_Columns + Columns_ZMCA_NCA_AOC4_II+\
                                                                               ["FY_END_DATE"]\
                                                                               +["DATE_AGM"]

                                                    Additional_Values = [FileWithoutExtn, "", Company_Name,CIN, DATE_CURR_REP,DATE_PREV_REP]
                                                    List = [c.text for c in maindata]
                                                    List = Additional_Values + List + [FY_END_DATE] + [DATE_AGM]
                                                    ZMCA_NCA_AOC4_II = [List]
                                                    df = pd.DataFrame(ZMCA_NCA_AOC4_II, columns=Columns_ZMCA_NCA_AOC4_II)
                                                    df = df.loc[:, ~df.columns.duplicated()]
                                                    dfZMCA_NCA_AOC4_II = dfZMCA_NCA_AOC4_II.append(df)
                                                    # Additional_Columns = ["File Name", "DUNS", "Company_Name","CIN","DATE_CURR_REP"]
                                                    # Columns_ZMCA_NCA_AOC4_II = [c.tag for c in maindata]
                                                    # if (len(Columns_ZMCA_NCA_AOC4_II) == 201):
                                                    #     Columns_ZMCA_NCA_AOC4_II = Additional_Columns + Columns_ZMCA_NCA_AOC4_II
                                                    # Additional_Values = [FileWithoutExtn, "", Company_Name,CIN, DATE_CURR_REP]
                                                    # List = [c.text for c in maindata]
                                                    # if (len(List) == 201):
                                                    #     List = Additional_Values + List
                                                    #     ZMCA_NCA_AOC4_II.append(List)

                                                    break
                                                except Exception as ex:
                                                    logger.error(str(ex)+str(ZMCA_NCA_AOC4_II))
                                                    continue
                                            # ====================================================
                                            # Auditors Details
                                            # ====================================================
                                            for maindata in data.findall('T_ZNCA_AOC_4_S10'):
                                                try:
                                                    Additional_Columns = ["File Name","DUNS","Company_Name","CIN",'FY_END_DATE', 'DATE_AGM']
                                                    for subdata in maindata.findall('DATA'):
                                                        Columns_T_ZNCA_AOC_4_S10 = [c.tag for c in subdata]
                                                        Columns_T_ZNCA_AOC_4_S10=Additional_Columns+Columns_T_ZNCA_AOC_4_S10
                                                        break
                                                    Additional_Values = [FileWithoutExtn,"", Company_Name,CIN,FY_END_DATE,DATE_AGM]
                                                    for subdata in maindata.findall('DATA'):
                                                        List = [c.text for c in subdata]
                                                        List = Additional_Values + List
                                                        T_ZNCA_AOC_4_S10.append(List)
                                                except Exception as ex:
                                                    logger.error(str(ex)+str(T_ZNCA_AOC_4_S10))
                                                    continue
                                            # ====================================================
                                            # Principal products or services
                                            # ====================================================
                                            for maindata in data.findall('T_ZNCA_AOC_4_SII_4'):
                                                try:
                                                    Additional_Columns = ["File Name","DUNS","Company_Name","CIN","FY_END_DATE","DATE_AGM"]
                                                    for subdata in maindata.findall('DATA'):
                                                        Columns_T_ZNCA_AOC_4_SII_4 = [c.tag for c in subdata]
                                                        Columns_T_ZNCA_AOC_4_SII_4=Additional_Columns+Columns_T_ZNCA_AOC_4_SII_4
                                                        break
                                                    Additional_Values = [FileWithoutExtn,"", Company_Name,CIN,FY_END_DATE,DATE_AGM]
                                                    for subdata in maindata.findall('DATA'):
                                                        List = [c.text for c in subdata]
                                                        List = Additional_Values + List
                                                        T_ZNCA_AOC_4_SII_4.append(List)
                                                except Exception as ex:
                                                    logger.error(str(ex)+str(T_ZNCA_AOC_4_SII_4))
                                                    continue

                                            for maindata in data.findall('T_ZNCA_AOC_4_SIII'):
                                                try:
                                                    Additional_Columns = ["File Name","DUNS","Company_Name","CIN"]
                                                    for subdata in maindata.findall('DATA'):
                                                        Columns_T_ZNCA_AOC_4_SIII = [c.tag for c in subdata]
                                                        Columns_T_ZNCA_AOC_4_SIII=Additional_Columns+Columns_T_ZNCA_AOC_4_SIII
                                                        break
                                                    Additional_Values = [FileWithoutExtn,"", Company_Name,CIN]
                                                    for subdata in maindata.findall('DATA'):
                                                        List = [c.text for c in subdata]
                                                        List = Additional_Values + List
                                                        T_ZNCA_AOC_4_SIII.append(List)
                                                except Exception as ex:
                                                    logger.error(str(ex)+str(T_ZNCA_AOC_4_SIII))
                                                    continue
                                        elif (NATURE_OF_FS == 'Adopted consolidated financial statements'):
                                            Status = "CFS File - different file type"
                                            Company_Name=""
                                    except Exception as ex:
                                        logger.error(str(ex))
                                        continue

                        t1 = time.time()
                        elapsed = time.strftime("%H:%M:%S %Z", time.gmtime(t1 - t0))
                        StatsList.append([FileWithoutExtn,Company_Name,elapsed,Status,date.today().strftime('%d-%m-%y'),"No Remarks"])

                        try:
                            # shutil.move( InPutFile["InPutFile"] + filename,  PorcessedPDFS["PorcessedPDFS"] + filename)
                            os.remove( InPutFileAOCNonXBRL["InPutFileAOC4"] + filename)
                        except Exception as ex:
                            continue

                    except Exception as ex:
                        shutil.move( InPutFileAOCNonXBRL["InPutFileAOC4"] + filename,
                                      FailedPDFS["FailedPDFS"] + filename)
                        Status = 'No Data Found'
                        StatsList.append([FileWithoutExtn, "", "", Status, date.today().strftime('%d-%m-%y'),
                                     str(ex)])
                        logger.error(filename)
                        # os.remove( InPutFile["InPutFile"] + filename)
                        logger.error(str(ex))
                        continue

                logger.info(" Data Frame Filled ")
                # for listofdata in DataList:
                #     list_of_rows.append(listofdata)
                # Stats.append(StatsList, ignore_index=False, verify_integrity=False, sort=None)
                Stats = Stats.append(pd.DataFrame(StatsList, columns=['File Name','Name of the company','Processing Time','Status','Processed Date','Remarks']),
                                             ignore_index=True)

                # Stats = pd.DataFrame(StatsList,columns=['File Name','Name of the company','Processing Time','Status','Processed Date','Remarks'])
                # StatsDescribe=pd.DataFrame({"Total Files Run":Stats["Status"].count(),
                #                             "Success Files":Stats["Status"].value_counts().index.tolist()[0],
                #                             "Failed Files":Stats["Status"].value_counts().index.tolist()[1]})

                # StatsDescribe=[[Stats["Status"].count()],[Stats["Status"].value_counts()]]
                # StatsDescribe.transpose()
                # print(StatsDescribe)

                # Stats.loc[len(Stats)] = StatsList
                # dfZMCA_NCA_AOC_4 = pd.DataFrame(ZMCA_NCA_AOC_4,columns=Columns_ZMCA_NCA_AOC_4)
                dfT_ZMCA_NCA_AOC4_S9 = pd.DataFrame(T_ZMCA_NCA_AOC4_S9,columns=Columns_T_ZMCA_NCA_AOC4_S9)
                # dfZMCA_NCA_AOC4_II = pd.DataFrame(ZMCA_NCA_AOC4_II,columns=Columns_ZMCA_NCA_AOC4_II)
                dfT_ZNCA_AOC_4_SII_4 = pd.DataFrame(T_ZNCA_AOC_4_SII_4,columns=Columns_T_ZNCA_AOC_4_SII_4)
                dfT_ZNCA_AOC_4_S10 = pd.DataFrame(T_ZNCA_AOC_4_S10, columns=Columns_T_ZNCA_AOC_4_S10)
                dfT_ZNCA_AOC_4_SIII = pd.DataFrame(T_ZNCA_AOC_4_SIII, columns=Columns_T_ZNCA_AOC_4_SIII)

                # ==========================================================================================================
                # Company Information
                # ==========================================================================================================
                dfGeneral_information_of_the_comp[['File Name','Duns','Name of the company',
                                                 'Corporate Identity Number_CIN_of Company',
                                                 'Global location number_GLN_of_company',
                                                 'Address of the registered office of the company',
                                                 'e-mail ID of the company',
                                                 'Financial year to which financial statements relates_From',
                                                 'Financial year to which financial statements relates_To',
                                                 'Date of Board of directors meeting in which financial statements are approved','Date of signing of reports on the financial statements by the auditors',
                                                 'Whether annual general meeting_AGM_held',
                                                 'If yes-date of AGM','Due date of AGM','Whether any extension for financial year or AGM granted',
                                                 'If yes-due date of AGM after grant of extension']] = \
                                                dfZMCA_NCA_AOC_4[['File Name','DUNS','Company_Name','CIN','GLN',
                                                   'REG_OFFICE_ADDR','EMAIL_ID_COMPANY','FY_START_DATE',
                                                   'FY_END_DATE','DATE_BOD_MEETING','DATE_SIGNING_RFS',
                                                   'RB_AGM_HELD','DATE_AGM','DUE_DATE_AGM','RB_EXTN_FY_AGM',
                                                   'DDA_AFTER_EXTNSN']]
                logger.info("Data Extracted for Company Information")
                # ==========================================================================================================
                # Holding Company
                # ==========================================================================================================

                dfHolding_Company[['File Name','Duns','Name of the company','Corporate Identity Number (CIN) of Company',
                                 'Whether the company is a subsidiary company as defined under clause (87) of section 2',
                                 'CIN of the holding company, if applicable','Name of the holding company',
                                 'Provision pursuant to which the company has become a subsidiary',
                                 'Financial year to which balance sheet relates - To','If yes - Date of AGM']] = \
                    dfZMCA_NCA_AOC_4[['File Name','DUNS','Company_Name','CIN','RB_COMP_SUBSIDRY','CIN_HOLDING_COMP'
                                         ,'NAME_HOLDING_CMP','PROVISION_PURSUA','FY_END_DATE','DATE_AGM']]
                logger.info("Data Extracted for Holding Information")
                # ==========================================================================================================
                # Subsidiary
                # ==========================================================================================================
                dfSubsidiary[['File Name','Duns','Name of the company',
                                           'Corporate Identity Number (CIN) of Company',
                                           'Whether the company has a subsidiary company as defined under clause (87) of section 2',
                                           'If yes, then indicate number of subsidiary company(ies)',
                                           'CIN of subsidiary company',
                                            'Name of the subsidiary company',
                                            'Provisions pursuant to which the company has become a subsidiary',
                                            'Financial year to which balance sheet relates - To',
                                            'If yes - Date of AGM']] = dfT_ZMCA_NCA_AOC4_S9[["File Name","DUNS","Company_Name","CIN",
                                                'Whether the company has a subsidiary company as defined under clause (87) of section 2',
                                                'If yes, then indicate number of subsidiary company(ies)',
                                                'CIN_SUBSIDARY_CM','NAME_SUBSDRY_CMP',
                                                'PROVISION_PUR_C','FY_END_DATE', 'DATE_AGM']]
                logger.info("Data Extracted for Subsidiary Company")
                # ==========================================================================================================
                # Auditors
                # ==========================================================================================================
                dfAuditors[['File Name', 'DUNS', 'Company_Name', 'CIN', 'Income-tax PAN of auditor or auditors firm',
                            'Category of auditor','Membership number of auditor or auditors firms registration number',
                            'SRN of Form ADT-1','Name of the auditor or auditors firm',
                            'Address of the auditor or auditors firm_Line 1',
                            'Address of the auditor or auditors firm_Line 2',
                            'Address of the auditor or auditors firm_City ',
                            'Address of the auditor or auditors firm_State',
                            'Address of the auditor or auditors firm_Country',
                            'Address of the auditor or auditors firm_Pin Code',
                            'Financial year to which balance sheet relates - To', 'If yes - Date of AGM']] = \
                    dfT_ZNCA_AOC_4_S10[['File Name', 'DUNS', 'Company_Name', 'CIN', 'IT_PAN',
                                        'RB_CATEGORY_AUDT', 'MEMBERSHIP_NUM_A',
                                        'SRN_ADT_1', 'NAME_AUDT_AUDTRF', 'ADDRESS_LINE_I', 'ADDRESS_LINE_II', 'CITY',
                                        'STATE', 'COUNTRY', 'PIN_CODE', 'FY_END_DATE', 'DATE_AGM']]
                logger.info("Data Extracted for Auditors")
                # ==========================================================================================================
                # Finance
                # ==========================================================================================================
                dfFinancial_BalanceSheet1[['File Name','Duns','Name of the company','Corporate Identity Number (CIN) of Company',
                                         'Figures as at the end of (Currentreporting period) (in Rs.)',
                                       'Share capital - Shareholders Funds (SF)',
                                       'SF - Reserves - Surplus',
                                       'SF - Money received against Share Warrants',
                                       'Share Application Money pending Allotment',
                                       'NCL - Long Term Borrowings',
                                       'NCL - Deferred Tax Liabilities Net',
                                       'NCL - Other Long Term Liabilities',
                                       'NCL - Long Term Provisions',
                                       'CL - Short Term Borrowings',
                                       'CL - Trade Payables',
                                       'CL - Other Current Liabilities',
                                       'CL - Short Term Provisions',
                                       'Total Liablities',
                                       'NCA - FA Tangible Assets',
                                       'NCA - FA Intangible Assets',
                                       'NCA - FA Capital Work in Progress',
                                       'NCA - FA Intangible Assets under Development',
                                       'NCA - Noncurrent investments',
                                       'NCA - Deferred Tax Assets Net',
                                       'NCA - Long Term Loans and Advances',
                                       'NCA - Other Non-Current Assets',
                                       'CA - Current Investments',
                                       'CA - Inventories',
                                       'CA - Trade Receivables',
                                       'CA - Cash and Cash Equivalents',
                                       'CA - Short Term Loans and Advances',
                                       'CA - Other Current Assets',
                                       'Total Assets']]=dfZMCA_NCA_AOC_4[['File Name','DUNS','Company_Name','CIN',
                                               'DATE_CURR_REP', 'SHARE_CAPITAL_CR', 'RESERVE_SURPLUS1',
                                               'MONEY_RECEIVD_CR','SHARE_APP_MON_CR','LONG_TERM_BORR_C',
                                               'DEFERRED_TL_CR','OTHER_LNG_TRM_CR','LONG_TERM_PROV_C',
                                               'SHORT_TERM_BOR_C','TRADE_PAYABLES_C','OTHER_CURR_LIA_C',
                                               'SHORT_TERM_PRO_C','TOTAL_CURR_REP','TANGIBLE_ASSET_C',
                                               'INTANGIBLE_AST_C','CAPITAL_WIP_CR','INTANGIBLE_AUD_C',
                                               'NON_CURR_INV_CR','DEFERRED_TA_CR','LT_LOANS_ADV_CR',
                                               'OTHER_NON_CA_CR','CURRENT_INV_CR','INVENTORIES_CR',
                                               'TRADE_RECEIV_CR','CASH_AND_EQU_CR','SHORT_TRM_LOA_CR',
                                               'OTHER_CURR_CA_CR','TOTAL_CURR_REP1']]
                logger.info("Data Extracted for Finance 1")

                dfFinancial_BalanceSheet2[['File Name','Duns','Name of the company','Corporate Identity Number (CIN) of Company',
                                         'Figures as at the end of (Currentreporting period) (in Rs.)',
                                           'Share capital - Shareholders Funds (SF)',
                                           'SF - Reserves - Surplus',
                                           'SF - Money received against Share Warrants',
                                           'Share Application Money pending Allotment',
                                           'NCL - Long Term Borrowings',
                                           'NCL - Deferred Tax Liabilities Net',
                                           'NCL - Other Long Term Liabilities',
                                           'NCL - Long Term Provisions',
                                           'CL - Short Term Borrowings',
                                           'CL - Trade Payables',
                                           'CL - Other Current Liabilities',
                                           'CL - Short Term Provisions',
                                           'Total Liablities',
                                           'NCA - FA Tangible Assets',
                                           'NCA - FA Intangible Assets',
                                           'NCA - FA Capital Work in Progress',
                                           'NCA - FA Intangible Assets under Development',
                                           'NCA - Noncurrent investments',
                                           'NCA - Deferred Tax Assets Net',
                                           'NCA - Long Term Loans and Advances',
                                           'NCA - Other Non-Current Assets',
                                           'CA - Current Investments',
                                           'CA - Inventories',
                                           'CA - Trade Receivables',
                                           'CA - Cash and Cash Equivalents',
                                           'CA - Short Term Loans and Advances',
                                           'CA - Other Current Assets',
                                           'Total Assets']]=\
                                    dfZMCA_NCA_AOC_4[['File Name','DUNS','Company_Name','CIN',
                                            'DATE_PREV_REP','SHARE_CAPITAL_PR','RESERVE_SURPLUS2',
                                            'MONEY_RECEIVD_PR',	'SHARE_APP_MON_PR','LONG_TERM_BORR_P',
                                            'DEFERRED_TL_PR','OTHER_LNG_TRM_PR','LONG_TERM_PROV_P',
                                            'SHORT_TERM_BOR_P','TRADE_PAYABLES_P','OTHER_CURR_LIA_P',
                                            'SHORT_TERM_PRO_P','TOTAL_PREV_REP','TANGIBLE_ASSET_P',
                                            'INTANGIBLE_AST_P',	'CAPITAL_WIP_PR', 'INTANGIBLE_AUD_P',
                                            'NON_CURR_INV_PR','DEFERRED_TA_PR','LT_LOANS_ADV_PR',
                                            'OTHER_NON_CA_PR','CURRENT_INV_PR','INVENTORIES_PR',
                                            'TRADE_RECEIV_PR','CASH_AND_EQU_PR','SHORT_TRM_LOA_PR',
                                            'OTHER_CURR_CA_PR','TOTAL_PREV_REP1']]

                logger.info("Data Extracted for Finance 2")
                dfFinancial_PNL1[[
                              'Figures for the period (Current reporting period) (in `) From',
                              'Figures for the period (Current reporting period) (in `) To',
                              'Sale of goods manufactured - Domestic turnover - Revenue from operations',
                              'Sale of goods traded - Domestic turnover - Revenue from operations',
                              'Sale or supply of services - Domestic turnover - Revenue from operations',
                              'Sale of goods manufactured - Export turnover - Revenue from operations',
                              'Sale of goods traded - Export turnover - Revenue from operations',
                              'Sale or supply of services - Export turnover - Revenue from operations',
                              'Other Income','Total Revenue','Cost of materials consumed - Expenses',
                              'Purchases of stock in trade - Expenses',
                              'Changes in inventories of-Finished goods',
                              'Changes in inventories of-Work-in-progress',
                              'Changes in inventories of finished stock in trade',
                              'Employee benefit expense - Expenses','Managerial remuneration - Expenses',
                              'Payment to Auditors - Expenses',	'Insurance expenses - Expenses','Power and fuel - Expenses',
                              'Finance cost - Expenses','Depreciation and amortization expense - Expenses',
                              'Other expenses - Expenses','Total expenses',
                              'Profit before exceptional and extraordinary items and tax','Exceptional items',
                              'Profit before extraordinary items and tax',	'Extraordinary items','Profit before tax',
                              'Current tax - Tax Expense','Deferred Tax - Tax Expenses',
                              'Profit/(Loss) for the period from continuing operations',
                              'Profit/(Loss) from discontinuing operations','Tax expense of discontinuing operations',
                              'Profit/(Loss) from discontinuing operations (after tax)','Profit/(Loss)']] =\
                    dfZMCA_NCA_AOC4_II[[
                              'FROM_DATE_CR','TO_DATE_CR','SALES_GOODS_CR','SALES_GOODS_T_CR',
                              'SALES_SUPPLY_CR','SALES_GOODS1_CR','SALE_GOODS_T1_CR',
                              'SALES_SUPPLY1_CR','OTHER_INCOME_CR','TOTAL_REVENUE_CR','COST_MATERIAL_CR',
                              'PURCHASE_STOCK_C','FINISHED_GOODS_C','WORK_IN_PROG_CR',
                              'STOCK_IN_TRADE_C','EMP_BENEFIT_EX_C','MANGERIAL_REM_CR','PAYMENT_AUDTRS_C',
                              'INSURANCE_EXP_CR','POWER_FUEL_CR','FINANCE_COST_CR','DEPRECTN_AMORT_C',
                              'OTHER_EXPENSES_C','TOTAL_EXPENSES_C','PROFIT_BEFORE_CR',
                              'EXCEPTIONL_ITM_C','PROFIT_BEF_TAX_C','EXTRAORDINARY_CR', 'PROF_B_TAX_7_8_C', 'CURRENT_TAX_CR',
                              'DEFERRED_TAX_CR', 'PROF_LOSS_OPER_C','PROF_LOSS_DO_CR', 'TAX_EXPNS_DIS_CR','PROF_LOS_12_13_C',
                              'PROF_LOS_11_14_C']]
                logger.info("Data Extracted for PNL1")
                dfFinancial_PNL2[[
                                  'Figures for the period (Current reporting period) (in `) From',
                                  'Figures for the period (Current reporting period) (in `) To',
                                  'Sale of goods manufactured - Domestic turnover - Revenue from operations',
                                  'Sale of goods traded - Domestic turnover - Revenue from operations',
                                  'Sale or supply of services - Domestic turnover - Revenue from operations',
                                  'Sale of goods manufactured - Export turnover - Revenue from operations',
                                  'Sale of goods traded - Export turnover - Revenue from operations',
                                  'Sale or supply of services - Export turnover - Revenue from operations',
                                  'Other Income', 'Total Revenue', 'Cost of materials consumed - Expenses',
                                  'Purchases of stock in trade - Expenses',
                                  'Changes in inventories of-Finished goods',
                                  'Changes in inventories of-Work-in-progress',
                                  'Changes in inventories of finished stock in trade',
                                  'Employee benefit expense - Expenses', 'Managerial remuneration - Expenses',
                                  'Payment to Auditors - Expenses', 'Insurance expenses - Expenses',
                                  'Power and fuel - Expenses',
                                  'Finance cost - Expenses', 'Depreciation and amortization expense - Expenses',
                                  'Other expenses - Expenses', 'Total expenses',
                                  'Profit before exceptional and extraordinary items and tax', 'Exceptional items',
                                  'Profit before extraordinary items and tax', 'Extraordinary items', 'Profit before tax',
                                  'Current tax - Tax Expense', 'Deferred Tax - Tax Expenses',
                                  'Profit/(Loss) for the period from continuing operations',
                                  'Profit/(Loss) from discontinuing operations', 'Tax expense of discontinuing operations',
                                  'Profit/(Loss) from discontinuing operations (after tax)', 'Profit/(Loss)']] = \
                                dfZMCA_NCA_AOC4_II[[
                                    'FROM_DATE_PR',
                     'TO_DATE_PR','SALES_GOODS_PR','SALES_GOODS_T_PR','SALES_SUPPLY_PR','SALES_GOODS1_PR',
                     'SALE_GOODS_T1_PR','SALES_SUPPLY1_PR','OTHER_INCOME_PR','TOTAL_REVENUE_PR',
                     'COST_MATERIAL_PR','PURCHASE_STOCK_P','FINISHED_GOODS_P','WORK_IN_PROG_PR','STOCK_IN_TRADE_P',
                     'EMP_BENEFIT_EX_P','MANGERIAL_REM_PR','PAYMENT_AUDTRS_P',
                     'INSURANCE_EXP_PR','POWER_FUEL_PR','FINANCE_COST_PR','DEPRECTN_AMORT_P',
                     'OTHER_EXPENSES_P','TOTAL_EXPENSES_P','PROFIT_BEFORE_PR','EXCEPTIONL_ITM_P','PROFIT_BEF_TAX_P',
                     'EXTRAORDINARY_PR','PROF_B_TAX_7_8_P','CURRENT_TAX_PR','DEFERRED_TAX_PR','PROF_LOSS_OPER_P',
                     'PROF_LOSS_DO_PR','TAX_EXPNS_DIS_PR','PROF_LOS_12_13_P','PROF_LOS_11_14_P'
                    ]]
                logger.info("Data Extracted for PNL2")
                # ==========================================================================================================
                # Long Term Borrowings  unsecured
                # ==========================================================================================================

                dfLongTerm_Borrowings_unsecuredCR[['File Name','Duns','Name of the company','Corporate Identity Number (CIN) of Company',
                               'Figures as at the end of (Currentreporting period) (in Rs.)',
                               'Bonds/ debentures - long term borrowings (unsecured)',
                               'Term Loans - From Banks - long term borrowings (unsecured)',
                               'Term Loans - From Other Parties - long term borrowings (unsecured)',
                               'Deferred payment liabilities - long term borrowings (unsecured)',
                               'Deposits - long term borrowings (unsecured)',
                               'Loans and advances from related parties - long term borrowings (unsecured)',
                               'Long term maturities of finance lease obligations - long term borrowings (unsecured)',
                               'Other loans & advances - long term borrowings (unsecured)',
                               'Total long term borrowings (unsecured) - long term borrowings (unsecured)',
                               'Out of above total, aggregate amount guaranteed by directors - long term borrowings (unsecured)',
                                                   'Financial year to which balance sheet relates - To',
                                                   'If yes - Date of AGM'
                                        ]]=dfZMCA_NCA_AOC_4[['File Name','DUNS','Company_Name','CIN',
                                                             'DATE_CURR_REP','BONDS_DEBS_CR','TERM_LOANS_FB_CR',
                                                             'TERM_LOANS_FO_CR','DEFERRED_PL_CR','DEPOSITS_CR',
                                                             'LOANS_ADV_RP_CR','LONG_TERM_MAT_CR','OTHER_LOA_CR','TOTAL_LT_BORR_CR',
                                                             'TOT_AGGREGATE_CR',
                                                             'FY_END_DATE', 'DATE_AGM']]
                logger.info("Data Extracted for Long Term Borrowings  unsecured CR")
                dfLongTerm_Borrowings_unsecuredPR[['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                                         'Figures as at the end of (Currentreporting period) (in Rs.)',
                                         'Bonds/ debentures - long term borrowings (unsecured)',
                                         'Term Loans - From Banks - long term borrowings (unsecured)',
                                         'Term Loans - From Other Parties - long term borrowings (unsecured)',
                                         'Deferred payment liabilities - long term borrowings (unsecured)',
                                         'Deposits - long term borrowings (unsecured)',
                                         'Loans and advances from related parties - long term borrowings (unsecured)',
                                         'Long term maturities of finance lease obligations - long term borrowings (unsecured)',
                                         'Other loans & advances - long term borrowings (unsecured)',
                                         'Total long term borrowings (unsecured) - long term borrowings (unsecured)',
                                         'Out of above total, aggregate amount guaranteed by directors - long term borrowings (unsecured)',
                                         'Financial year to which balance sheet relates - To',
                                         'If yes - Date of AGM'
                                                   ]] \
                        = dfZMCA_NCA_AOC_4[['File Name', 'DUNS', 'Company_Name', 'CIN',
                                            'DATE_PREV_REP','BONDS_DEBS_PR', 'TERM_LOANS_FB_PR','TERM_LOANS_FO_PR','DEFERRED_PL_PR','DEPOSITS_PR',
                                            'LOANS_ADV_RP_PR','LONG_TERM_MAT_PR','OTHER_LOA_PR', 'TOTAL_LT_BORR_PR','TOT_AGGREGATE_PR',
                                            'FY_END_DATE', 'DATE_AGM']]
                logger.info("Data Extracted for Long Term Borrowings  unsecured PR")
                # ==========================================================================================================
                # Short Term Borrowings unsecured
                # ==========================================================================================================

                dfShortTerm_Borrowing_securedCR[['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                                                'Figures as at the end of (Currentreporting period) (in Rs.)',
                                                'Loans repayable on demand - From Banks - short term borrowings (unsecured)',
                                                'Loans repayable on demand - From other parties - short term borrowings (unsecured)',
                                                'Loans and advances from related parties - short term borrowings (unsecured)',
                                                'Deposits - short term borrowings (unsecured)',
                                                'Other loans and advances - short term borrowings (unsecured)',
                                                'Total short term borrowings (unsecured) - short term borrowings (unsecured)',
                                                'Out of above total, aggregate amount guaranteed by directors - short term borrowings (unsecured)',
                                                 'Financial year to which balance sheet relates - To',
                                                 'If yes - Date of AGM']]= \
                                                dfZMCA_NCA_AOC_4[[ 'File Name', 'DUNS', 'Company_Name', 'CIN',
                                                                   'DATE_CURR_REP','LOAN_REPAY_B_CR',
                                                                   'LOAN_REPAY_OP_CR',
                                                                   'LOANS_A_RP_ST_CR',
                                                                   'DEPOSITS_ST_CR',
                                                                   'OTH_LOANS_ADV_CR',
                                                                   'TOTAL_ST_BORR_CR',
                                                                   'TOT_AGGREG_ST_CR',
                                                                   'FY_END_DATE', 'DATE_AGM']]
                logger.info("Data Extracted for Short Term Borrowings unsecured CR")
                dfShortTerm_Borrowing_securedPR[['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                                                    'Figures as at the end of (Currentreporting period) (in Rs.)',
                                                    'Loans repayable on demand - From Banks - short term borrowings (unsecured)',
                                                    'Loans repayable on demand - From other parties - short term borrowings (unsecured)',
                                                    'Loans and advances from related parties - short term borrowings (unsecured)',
                                                    'Deposits - short term borrowings (unsecured)',
                                                    'Other loans and advances - short term borrowings (unsecured)',
                                                    'Total short term borrowings (unsecured) - short term borrowings (unsecured)',
                                                    'Out of above total, aggregate amount guaranteed by directors - short term borrowings (unsecured)',
                                                 'Financial year to which balance sheet relates - To',
                                                 'If yes - Date of AGM'
                                                 ]] \
                                                    = dfZMCA_NCA_AOC_4[[ 'File Name', 'DUNS', 'Company_Name', 'CIN',
                                                     'DATE_PREV_REP',
                                                     'LOAN_REPAY_B_PR',
                                                     'LOAN_REPAY_OP_PR',
                                                     'LOANS_A_RP_ST_PR',
                                                     'DEPOSITS_ST_PR',
                                                     'OTH_LOANS_ADV_PR',
                                                     'TOTAL_ST_BORR_PR',
                                                     'TOT_AGGREG_ST_PR','FY_END_DATE', 'DATE_AGM']]
                logger.info("Data Extracted for Short Term Borrowings unsecured PR")
                # ==========================================================================================================
                # Long term loans unsecured, good
                # ==========================================================================================================
                dfLongterm_loans_unsecured_goodCR[['File Name', 'Duns', 'Name of the company',
                                'Corporate Identity Number (CIN) of Company',
                                'Figures as at the end of (Currentreporting period) (in Rs.)',
                                'Capital advances - long term loans and advances (unsecured, considered good)',
                                'Security deposits - long term loans and advances (unsecured, considered good)',
                                'Loans and advances to other related parties - long term loans and advances (unsecured, considered good)',
                                'Other loans and advances - long term loans and advances (unsecured, considered good)',
                                'Total long term loan and advances - long term loans and advances (unsecured, considered good)',
                                'Provision/ allowance for bad and doubtful loans and advances - From related parties - long term loans and advances (unsecured, considered good)',
                                'Provision/ allowance for bad and doubtful loans and advances - From others - long term loans and advances (unsecured, considered good)',
                                'Net long term loan and advances (unsecured, considered good)',
                                'Loans and advances due by directors/ other officers of the company - long term loans and advances (unsecured, considered good)',
                                                   'Financial year to which balance sheet relates - To',
                                                   'If yes - Date of AGM'
    ]] \
                                = dfZMCA_NCA_AOC_4[[ 'File Name', 'DUNS', 'Company_Name', 'CIN',
                                                    'DATE_CURR_REP','CAPT_ADVANCES_CR',
                                                    'SECURITY_DEP_CR',
                                                    'LOANS_ADV_ORP_CR',
                                                    'OTHER_LOANS_A_CR',
                                                    'TOT_LT_LOAN_A_CR',
                                                    'PROV_ALLOW_RP_CR',
                                                    'PROV_ALLOW_OT_CR',
                                                    'NET_LT_LOA_CR',
                                                    'LOANS_ADV_DUE_CR','FY_END_DATE', 'DATE_AGM'
                                                    ]]
                logger.info("Data Extracted for Long term loans unsecured, good CR")
                dfLongterm_loans_unsecured_goodPR[['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                                                    'Figures as at the end of (Currentreporting period) (in Rs.)','Capital advances - long term loans and advances (unsecured, considered good)',
                                                    'Security deposits - long term loans and advances (unsecured, considered good)',
                                                    'Loans and advances to other related parties - long term loans and advances (unsecured, considered good)',
                                                    'Other loans and advances - long term loans and advances (unsecured, considered good)',
                                                    'Total long term loan and advances - long term loans and advances (unsecured, considered good)',
                                                    'Provision/ allowance for bad and doubtful loans and advances - From related parties - long term loans and advances (unsecured, considered good)',
                                                    'Provision/ allowance for bad and doubtful loans and advances - From others - long term loans and advances (unsecured, considered good)',
                                                    'Net long term loan and advances (unsecured, considered good)',
                                                    'Loans and advances due by directors/ other officers of the company - long term loans and advances (unsecured, considered good)',
                                                   'Financial year to which balance sheet relates - To',
                                                   'If yes - Date of AGM'
                                                    ]] \
                    = dfZMCA_NCA_AOC_4[['File Name', 'DUNS', 'Company_Name', 'CIN',
                                        'DATE_PREV_REP','CAPT_ADVANCES_PR',
                                        'SECURITY_DEP_PR',
                                        'LOANS_ADV_ORP_PR',
                                        'OTHER_LOANS_A_PR',
                                        'TOT_LT_LOAN_A_PR',
                                        'PROV_ALLOW_RP_PR',
                                        'PROV_ALLOW_OT_PR',
                                        'NET_LT_LOA_PR',
                                        'LOANS_ADV_DUE_PR','FY_END_DATE', 'DATE_AGM']]
                logger.info("Data Extracted for Long term loans unsecured, good PR")
                # ==========================================================================================================
                # longterm_loans_doubtful
                # ==========================================================================================================

                dflongterm_loans_doubtful_CR[['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                                                    'Figures as at the end of (Currentreporting period) (in Rs.)',
                                              'Capital advances - long term loans and advances (doubtful)',
                                              'Security deposits - long term loans and advances (doubtful)',
                                              'Loans and advances to other related parties - long term loans and advances (doubtful)',
                                              'Other loans and advances - long term loans and advances (doubtful)',
                                              'Total long term loan and advances - long term loans and advances (doubtful)',
                                              'Provision/ allowance for bad and doubtful loans and advances - From related parties - long term loans and advances (doubtful)',
                                              'Provision/ allowance for bad and doubtful loans and advances - From others - long term loans and advances (doubtful)',
                                              'Net long term loan and advances (doubtful)',
                                              'Loans and advances due by directors/ other officers of the company - long term loans and advances (doubtful)',
                                              'Financial year to which balance sheet relates - To',
                                              'If yes - Date of AGM']]\
                    =dfZMCA_NCA_AOC_4[[ 'File Name', 'DUNS', 'Company_Name', 'CIN',
                                        'DATE_CURR_REP','CAPT_ADVANC_CR1','SECURITY_DEP_CR1','LOANS_ADV_OR_CR1',
                                         'OTHER_LOANS_CR1','TOT_LT_LOAN_CR1','PROV_ALLW_RP_CR1',
                                          'PROV_ALLW_OT_CR1','NET_LT_LOA_CR1','LOAN_ADV_DUE_CR1',
                                        'FY_END_DATE', 'DATE_AGM']]

                dflongterm_loans_doubtful_PR[['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                                                'Figures as at the end of (Currentreporting period) (in Rs.)',
                                                'Capital advances - long term loans and advances (doubtful)',
                                                'Security deposits - long term loans and advances (doubtful)',
                                                'Loans and advances to other related parties - long term loans and advances (doubtful)',
                                                'Other loans and advances - long term loans and advances (doubtful)',
                                                'Total long term loan and advances - long term loans and advances (doubtful)',
                                                'Provision/ allowance for bad and doubtful loans and advances - From related parties - long term loans and advances (doubtful)',
                                                'Provision/ allowance for bad and doubtful loans and advances - From others - long term loans and advances (doubtful)',
                                                'Net long term loan and advances (doubtful)',
                                                'Loans and advances due by directors/ other officers of the company - long term loans and advances (doubtful)',
                                                'Financial year to which balance sheet relates - To',
                                                'If yes - Date of AGM']] \
                    = dfZMCA_NCA_AOC_4[['File Name', 'DUNS', 'Company_Name', 'CIN',
                                        'DATE_PREV_REP','CAPT_ADVANC_PR1',
                                                                    'SECURITY_DEP_PR1',
                                                                    'LOANS_ADV_OR_PR1',
                                                                    'OTHER_LOANS_PR1',
                                                                    'TOT_LT_LOAN_PR1',
                                                                    'PROV_ALLW_RP_PR1',
                                                                    'PROV_ALLW_OT_PR1',
                                                                    'NET_LT_LOA_PR1',
                                                                    'LOAN_ADV_DUE_PR1',
                                                                    'FY_END_DATE', 'DATE_AGM']]

                # ==========================================================================================================
                # Tradereceivables
                # ==========================================================================================================

                dfTradereceivables_CR[['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                                                'Figures as at the end of (Currentreporting period) (in Rs.)',
                                        'Secured, considered good - Exceeding six months - trade receivables',
                                        'Secured, considered good - Within six months - trade receivables',
                                        'Unsecured, considered good - Exceeding six months - trade receivables',
                                        'Unsecured, considered good - Within six months - trade receivables',
                                        'Doubtful - Exceeding six months - trade receivables',
                                        'Doubtful - Within six months - trade receivables',
                                        'Total trade receivables - Exceeding six months - trade receivables',
                                        'Total trade receivables - Within six months - trade receivables',
                                        'Provision/ allowance for bad and doubtful debts - Exceeding six months - trade receivables',
                                        'Provision/ allowance for bad and doubtful debts - Within six months - trade receivables',
                                        'Net trade receivables - Exceeding six months - trade receivables',
                                        'Net trade receivables - Within six months - trade receivables',
                                        'Debt due by directors/ others officers of the company - Exceeding six months',
                                        'Debt due by directors/ others officers of the company - Within six months',
                                       'Financial year to which balance sheet relates - To',
                                       'If yes - Date of AGM']]=\
                    dfZMCA_NCA_AOC_4[['File Name', 'DUNS', 'Company_Name', 'CIN',
                                  'DATE_CURR_REP','SECURED_CG_ES_CR',
                                  'SECURED_CG_WS_CR','UNSECURD_CG_ES_C','UNSECURD_CG_WS_C','DOUBTFUL_ES_CR','DOUBTFUL_WS_CR',
                                  'TOTAL_TR_ES_CR','TOTAL_TR_WS_CR','LESS_PA_BAD_ES_C','LESS_PA_BAD_WS_C',
                                  'NET_TRADE_R_ES_C','NET_TRADE_R_WS_C','DEBTS_DUE_ES_CR','DEBTS_DUE_WS_CR',
                                  'FY_END_DATE', 'DATE_AGM']]

                dfTradereceivables_PR[
                    ['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                     'Figures as at the end of (Currentreporting period) (in Rs.)',
                     'Secured, considered good - Exceeding six months - trade receivables',
                     'Secured, considered good - Within six months - trade receivables',
                     'Unsecured, considered good - Exceeding six months - trade receivables',
                     'Unsecured, considered good - Within six months - trade receivables',
                     'Doubtful - Exceeding six months - trade receivables',
                     'Doubtful - Within six months - trade receivables',
                     'Total trade receivables - Exceeding six months - trade receivables',
                     'Total trade receivables - Within six months - trade receivables',
                     'Provision/ allowance for bad and doubtful debts - Exceeding six months - trade receivables',
                     'Provision/ allowance for bad and doubtful debts - Within six months - trade receivables',
                     'Net trade receivables - Exceeding six months - trade receivables',
                     'Net trade receivables - Within six months - trade receivables',
                     'Debt due by directors/ others officers of the company - Exceeding six months',
                     'Debt due by directors/ others officers of the company - Within six months',
                     'Financial year to which balance sheet relates - To',
                     'If yes - Date of AGM']] =\
                    dfZMCA_NCA_AOC_4[['File Name', 'DUNS', 'Company_Name', 'CIN',
                                  'DATE_PREV_REP','SECURED_CG_ES_PR',
                                    'SECURED_CG_WS_PR','UNSECURD_CG_ES_P','UNSECURD_CG_WS_P',
                                    'DOUBTFUL_ES_PR','DOUBTFUL_WS_PR',
                                    'TOTAL_TR_ES_PR','TOTAL_TR_WS_PR','LESS_PA_BAD_ES_P',
                                    'LESS_PA_BAD_WS_P','NET_TRADE_R_ES_P','NET_TRADE_R_WS_P',
                                    'DEBTS_DUE_ES_PR','DEBTS_DUE_WS_PR',
                                      'FY_END_DATE', 'DATE_AGM']]
                # ==========================================================================================================
                # Financial_Parameters_BS
                # ==========================================================================================================
                dfFinancial_Parameters_BS[['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                                           'Amount of issue allotted for contracts without payment received in cash during reporting periods',
                                            'Share application money given',
                                           'Share application money given during the reporting period','Share application money received during the reporting period',
                                           'Share application money received and due for refund',
                                           'Paid – up capital held by foreign company',
                                           'Paid-up capital held by foreign holding company and/ or through its subsidiaries',
                                           'Number of shares bought back during the reporting period',
                                           'Deposits accepted or renewed during the reporting period',
                                           'Deposits matured and claimed but not paid during the reporting period',
                                           'Deposits matured and claimed but not paid',
                                           'Deposits matured, but not claimed',
                                           'Unclaimed matured debentures',
                                           'Debentures claimed but not paid',
                                           'Interest on deposits accrued and due but not paid',
                                           'Unpaid dividend',
                                           'Investment in subsidiary companies',
                                           'Investment in government companies',
                                           'Capital Reserves',
                                           'Amount due for transfer to Investor Education and Protection Fund(IEPF)',
                                           'Inter- corporate deposits',
                                           'Gross value of transaction as per AS18 (If applicable',
                                           'Capital subsidies/ grants received from government authority(ies',
                                           'Calls unpaid by directors',
                                           'Calls unpaid by others',
                                           'Forfeited shares (amount originally paid-up)',
                                           'Forfeited shares reissued',
                                           'Borrowing from foreign institutional agencies',
                                           'Borrowing from foreign companies',
                                           'Inter-corporate borrowings - secured',
                                           'Inter-corporate borrowings - unsecured',
                                           'Commercial Paper',
                                           'Conversion of warrants into equity shares during the reporting period',
                                           'Conversion of warrants into preference shares during the reporting period',
                                           'Conversion of warrants into debentures during the reporting period',
                                           'Warrants issued during the reporting period (In foreign currency)',
                                           'Warrants issued during the reporting period (In Rupees)',
                                           'Default in payment of short term borrowings and interest thereon',
                                           'Default in payment of long term borrowings and interest thereon',
                                           'Whether any operating lease has been converted to financial lease or vice - versa',
                                            'Provide details of such conversion',
                                           'Net worth of company',
                                           'Number of shareholders to whom shares allotted under private placement during the reporting period',
                                            'Secured Loan',
                                           'Gross fixed assets (including intangible assets)',
                                           'Depreciation and amortization',
                                           'Miscellaneous expenditure to the extent not written off or adjusted',
                                           'Financial year to which balance sheet relates - To', 'If yes - Date of AGM'
                                           ]]=\
                    dfZMCA_NCA_AOC_4[['File Name', 'DUNS', 'Company_Name', 'CIN','AMOUNT_ISSUE_ALL',
                                                                'SHARE_APP_MONEY','SHARE_APP_MONEY1','SHARE_APP_MONEY2',
                                                                'SHARE_APP_MONEY3',
                                                                'PAID_UP_CAPT_FC','PAID_UP_CAPT_PER','NUM_SHARES_BB',
                                                                'DEP_ACCEPTED_REN','DEP_MATURED_CLAI','DEP_MATURED_CLA1',
                                                                'DEP_MATURED_CLA2','UNCLAIMED_M_DEB','DEBENTURES_CLAIM',
                                                                'INTEREST_DEPOSIT','UNPAID_DIVIDEND','INVESTMENT_SUBSD',
                                                                'INVESTMENT_GOVT','CAPITAL_RESERVES', 'AMT_DUE_TRANSFER',
                                                                'INTER_CORPORATE','GROSS_VALUE',
                                                                'CAPITAL_SUBSDIES','CALLS_UNPAID_DIR','CALLS_UNPAID_OTH',
                                                                'FORFEITED_SHARES','FORFEITED_SHAR_R','BORROWING_FIA','BORROWING_FC',
                                                                'INTER_CORP_BORR','INTER_CORP_BORR1','COMMERCIAL_PAPER',
                                                                'CONVERSION_WR_ES','CONVERSION_WR_PS','CONVERSION_WR_DE',
                                                                'WARRANTS_ISSUED','WARRANTS_ISSUED1','DEFAULT_PAYMENT',
                                                                'DEFAULT_PAYMENT1','RB_OPERATING_LEA','DETAILS_CONVERSN',
                                                                'NET_WORTH_COMPAN','NUM_SHARE_HOLDRS','SECURED_LOAN',
                                                                'GROSS_FIXD_ASSET','DEPRECIATN_AMORT','MISC_EXPENDITURE',
                                                                'FY_END_DATE', 'DATE_AGM']]

                # res1 = pd.merge(dfFinancial_BalanceSheet, dfFinancial_PNL, on=['FileName','Duns','Name of the company','Corporate Identity Number (CIN) of Company',
                #               'Figures for the period (Current reporting period) (in `) To'])
                # ==========================================================================================================
                # Import_Export
                # ==========================================================================================================
                dfImport_Export_Data_CR[['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                                     'Figures as at the end of (Currentreporting period) (in Rs.)',
                                     'Export of goods calculated on FOB basis - earning in foreign exchange',
                                     'Interest and dividend - earning in foreign exchange',
                                     'Royalty - earning in foreign exchange',
                                     'Know-how - earning in foreign exchange',
                                     'Professional & consultation fees - earning in foreign exchange',
                                     'Other income - earning in foreign exchange',
                                     'Total Earning in Foreign Exchange - earning in foreign exchange',
                                     'Import of goods calculated on CIF basis - raw material - expenditure in foreign exchange',
                                     'Import of goods calculated on CIF basis - component and spare parts - expenditure in foreign exchange',
                                     'Import of goods calculated on CIF basis - capital goods - expenditure in foreign exchange',
                                     'Royalty - expenditure in foreign exchange',
                                     'Know-how - raw material - expenditure in foreign exchange',
                                     'Professional & consultation fees - expenditure in foreign exchange',
                                     'Interest  - expenditure in foreign exchange',
                                     'Other matters - expenditure in foreign exchange',
                                     'Dividend paid - expenditure in foreign exchange',
                                     'Total Expenditure in foreign exchange - expenditure in foreign exchange',
                                     'Financial year to which balance sheet relates - To', 'If yes - Date of AGM']]=\
                    dfZMCA_NCA_AOC4_II[['File Name', 'DUNS', 'Company_Name', 'CIN', 'DATE_CURR_REP','EXP_GOODS_FOB_CR',
                                         'INTEREST_DIVD_CR','ROYALTY_CR','KNOW_HOW_CR',
                                         'PROF_CONS_FEE_CR','OTHR_INCOME_E_CR',
                                         'TOTAL_EARNG_FE_C','RAW_MATERIAL_CR',
                                         'COMPONENT_SP_CR','CAPITAL_GOODS_CR','ROYALTY_EXP_CR',
                                         'KNOW_HOW_EXP_CR','PROF_CON_FEE_E_C','INTEREST_EXP_CR','OTHER_MATTERS_CR',
                                         'DIVIDEND_PAID_CR','TOT_EXP_FE_CR','FY_END_DATE','DATE_AGM'
                                        ]]
                dfImport_Export_Data_PR[
                    ['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                     'Figures as at the end of (Currentreporting period) (in Rs.)',
                     'Export of goods calculated on FOB basis - earning in foreign exchange',
                     'Interest and dividend - earning in foreign exchange',
                     'Royalty - earning in foreign exchange',
                     'Know-how - earning in foreign exchange',
                     'Professional & consultation fees - earning in foreign exchange',
                     'Other income - earning in foreign exchange',
                     'Total Earning in Foreign Exchange - earning in foreign exchange',
                     'Import of goods calculated on CIF basis - raw material - expenditure in foreign exchange',
                     'Import of goods calculated on CIF basis - component and spare parts - expenditure in foreign exchange',
                     'Import of goods calculated on CIF basis - capital goods - expenditure in foreign exchange',
                     'Royalty - expenditure in foreign exchange',
                     'Know-how - raw material - expenditure in foreign exchange',
                     'Professional & consultation fees - expenditure in foreign exchange',
                     'Interest  - expenditure in foreign exchange',
                     'Other matters - expenditure in foreign exchange',
                     'Dividend paid - expenditure in foreign exchange',
                     'Total Expenditure in foreign exchange - expenditure in foreign exchange',
                     'Financial year to which balance sheet relates - To', 'If yes - Date of AGM']] = \
                    dfZMCA_NCA_AOC4_II[['File Name', 'DUNS', 'Company_Name', 'CIN', 'DATE_PREV_REP', 'EXP_GOODS_FOB_PR',
                                         'INTEREST_DIVD_PR','ROYALTY_PR','KNOW_HOW_PR','PROF_CONS_FEE_PR','OTHR_INCOME_E_PR',
                                         'TOTAL_EARNG_FE_P','RAW_MATERIAL_PR','COMPONENT_SP_PR','CAPITAL_GOODS_PR','ROYALTY_EXP_PR',
                                         'KNOW_HOW_EXP_PR','PROF_CON_FEE_E_P','INTEREST_EXP_PR', 'OTHER_MATTERS_PR','DIVIDEND_PAID_PR',
                                         'TOT_EXP_FE_PR','FY_END_DATE','DATE_AGM']]
                # ==========================================================================================================
                # Financial_Parameters_PNL
                # ==========================================================================================================
                dfFinancial_Parameters_PNL[['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                                            'Proposed Dividend','Earnings per share (in Rupees) - Basic','Earnings per share (in Rupees) - Diluted',
                                            'Income in foreign currency',
                                            'Expenditure in foreign currency',
                                            'Revenue subsidies or grants received from government authority(ies)',
                                            'Rent paid',
                                            'Consumption of stores and spare parts',
                                            'Gross value of transaction with related parties as per AS-18 (If applicable',
                                            'Bad debts of related parties as per AS-18 (If applicable)',
                                            'Financial year to which balance sheet relates - To', 'If yes - Date of AGM']]=\
                    dfZMCA_NCA_AOC4_II[[ 'File Name', 'DUNS', 'Company_Name', 'CIN', 'PROPOSED_DIVIDND',
                                         'BASIC_EARNING_PS','DILUTED_EARN_PS','INCOME_FOREIGN','EXPENDIT_FOREIGN','REVENUE_SUBSIDIE',
                                         'RENT_PAID','CONSUMPTION_STOR','GROSS_VALUE_TRAN','BAD_DEBTS_RP','FY_END_DATE','DATE_AGM']]
                # ==========================================================================================================
                # Principal_productsor_services
                # ==========================================================================================================
                dfPrincipal_productsor_services [['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                                                  'Product or service category code (ITC/ NPCS 4 digit code',
                                                  'Description of the product or service category',
                                                  'Turnover of the product or service category',
                                                  'Highest turnover contributing product or service code',
                                                  'Description of the product or service',
                                                  'Turnover of highest contributing product or service',
                                                  'Financial year to which balance sheet relates - To',
                                                  'If yes - Date of AGM'
                                                  ]] =\
                    dfT_ZNCA_AOC_4_SII_4[['File Name','DUNS','Company_Name','CIN','PRODUCT_SERV_CC',
                                        'DESC_PRODUCT_SER','TURNOVR_PROD_SER', 'HIGHEST_TO_PRD_S', 'DESC_HIGH_TO_PRD',
                                        'TURNOVER_HIGHEST', 'FY_END_DATE','DATE_AGM']]

                # ==========================================================================================================
                # Auditors_Comment
                # ==========================================================================================================
                dfAuditors_Comment[['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                                    'Whether auditors report has been qualified or has any reservations or contains adverse remarks',
                                    'Whether Companies (Auditors Report) Order (CARO) applicable',
                                    'FIXED_ASSETS','INVENTORIES','LOANS_GIVEN_COMP','ACCEPTANCE_PUB_D',
                                    'MAINTENANCE_CR','STATUTORY_DUES','TERM_LOANS',
                                    'FRAUD_NOTICED','OTHER_COMMENTS','Financial year to which balance sheet relates - To',
                                    'If yes - Date of AGM']]=\
                                    dfZMCA_NCA_AOC_4[['File Name','DUNS','Company_Name','CIN',
                                    'RB_AUDTR_REPORT','RB_COMP_AUDT_REP','FIXED_ASSETS','INVENTORIES',
                                    'LOANS_GIVEN_COMP','ACCEPTANCE_PUB_D','MAINTENANCE_CR','STATUTORY_DUES','TERM_LOANS',
                                     'FRAUD_NOTICED','OTHER_COMMENTS','FY_END_DATE','DATE_AGM']]
                # ==========================================================================================================
                # Other Information
                # ==========================================================================================================
                dfOther_Information[['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                                     'Type of Industry','Whether consolidated financial statements required or not',
                                     'Financial year to which balance sheet relates - To',
                                    'If yes - Date of AGM']]\
                    =dfZMCA_NCA_AOC_4[['File Name','DUNS','Company_Name','CIN', 'TYPE_OF_INDUSTRY','RB_CONSOLIDATED',
                                       'FY_END_DATE','DATE_AGM']]
                # ==========================================================================================================
                # CSR Information
                # ==========================================================================================================
                dfCSR1[
                    ['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                     'Give details (name, address and email address) of implementing agency',
                     'Whether a responsibility statement of the CSR Committee on the implementation and monitoring of CSR Policy is enclosed to the Boards Report',
                     'Whether CSR is applicable as per section 135','Turnover','Net worth','Number of CSR activities']] \
                    = dfZMCA_NCA_AOC4_II[['File Name', 'DUNS', 'Company_Name', 'CIN',
                                          'COMPLETE_P_ADDR','RB_RESP_CSR_COMM','RB_CSR_APPLICABL',
                                          'TURNOVER','NET_WORTH','NUM_CSR_ACTIVITY']]

                dfCSR2[
                    ['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                     'Average net profit of the company for last three financial years',
                    'Prescribed CSR Expenditure',
                    'Total amount spent on CSR for the financial year',
                    'Amount spent in local area', 'Financial year to which balance sheet relates - To',
                     'If yes - Date of AGM']] \
                    = dfZMCA_NCA_AOC_4[['File Name', 'DUNS', 'Company_Name', 'CIN',
                                        'AVG_NET_PROFIT', 'PRESCRIBED_CSR_E','TOTAL_AMT_SPENT',
                                        'AMOUNT_SPENT_LA','FY_END_DATE', 'DATE_AGM']]

                dfCSR3[
                    ['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company',
                     'CSR Project/Activity identified',
                     'Sector in which the Project is covered',
                     'Projects or Programs- state where the project was undertaken',
                     'District',
                     'Amoutn Outlay',
                     'Amount Spent on the projects',
                     'Expenditure on Administrative Overheads',
                     'Mode of Amount Spent'
                     ]] \
                    = dfT_ZNCA_AOC_4_SIII[['File Name', 'DUNS', 'Company_Name', 'CIN', 'CSR_PROJECT_ACTV',
                                           'SECTOR_PROJ_COVR','STATE_UT','DISTRICT','AMOUNT_OUTLAY','AMOUNT_SPENT_PRJ',
                                           'EXPENDITURE_ADM','MODE_AMOUNT_SPNT']]
                dfCSR1.set_index(['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company'])
                dfCSR2.set_index(['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company'])
                dfCSR3.set_index(['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company'])

                dfCSR = pd.merge(dfCSR1,dfCSR3, on=['File Name', 'Duns', 'Name of the company', 'Corporate Identity Number (CIN) of Company'])
                dfCSR = pd.merge(dfCSR, dfCSR2, on=['File Name', 'Duns', 'Name of the company',
                                                     'Corporate Identity Number (CIN) of Company'])
                logger.info("Data operations completed")
                result1 = pd.concat([dfFinancial_BalanceSheet1, dfFinancial_PNL1], axis=1)
                result2 = pd.concat([dfFinancial_BalanceSheet2, dfFinancial_PNL2], axis=1)
                # dfFinance1 = dfFinancial_BalanceSheet1.join(dfFinancial_PNL1)
                # dfFinance2 = dfFinancial_BalanceSheet2.join(dfFinancial_PNL2)
                dfFinancial = [result1,result2]
                dfFinancial = pd.concat(dfFinancial)

                dfLongTerm_Borrowings_unsecured=pd.concat([dfLongTerm_Borrowings_unsecuredCR,dfLongTerm_Borrowings_unsecuredPR])
                dfShortTerm_Borrowing_secured = pd.concat([dfShortTerm_Borrowing_securedCR, dfShortTerm_Borrowing_securedPR])
                dfLongterm_loans_unsecured_good=pd.concat([dfLongterm_loans_unsecured_goodCR,dfLongterm_loans_unsecured_goodPR])
                dflongterm_loans_doubtful=pd.concat([dflongterm_loans_doubtful_CR,dflongterm_loans_doubtful_PR])
                dfTradereceivables=pd.concat([dfTradereceivables_CR,dfTradereceivables_PR])
                dfImport_Export_Data = pd.concat([dfImport_Export_Data_CR, dfImport_Export_Data_PR])
                logger.info("Data concatenation completed")
                # dfGeneral_information_of_the_comp.drop([0], inplace=True)
                dfSubsidiary.drop([0],inplace=True)
                # dfHolding_Company.drop([0], inplace=True)
                # dfFinancial.drop([0], inplace=True)
                # dfLongTerm_Borrowings_unsecured.drop([0],inplace=True)
                # dfShortTerm_Borrowing_secured.drop([0],inplace=True)
                # dfLongterm_loans_unsecured_good.drop([0],inplace=True)
                # dflongterm_loans_doubtful.drop([0],inplace=True)
                # dfTradereceivables.drop([0],inplace=True)
                # dfFinancial_Parameters_BS.drop([0],inplace=True)
                # dfImport_Export_Data.drop([0],inplace=True)
                # dfFinancial_Parameters_PNL.drop([0],inplace=True)
                dfAuditors.drop([0],inplace=True)

                replace_values = {'AP': 'Andhra Pradesh', 'AR': 'Arunachal Pradesh', 'AS': 'Assam', 'BR': 'Bihar',
                                  'CT': 'Chhattisgarh', 'GA': 'Goa', 'GJ': 'Gujarat', 'HR': 'Haryana',
                                  'HP': 'Himachal Pradesh',
                                  'JK': 'Jammu and Kashmir', 'JH': 'Jharkhand', 'KA': 'Karnataka', 'KL': 'Kerala',
                                  'MP': 'Madhya Pradesh', 'MH': 'Maharashtra', 'MN': 'Manipur', 'ML': 'Meghalaya',
                                  'MZ': 'Mizoram', 'NL': 'Nagaland', 'OR': 'Orissa', 'PB': 'Punjab', 'RJ': 'Rajasthan',
                                  'SK': 'Sikkim', 'TN': 'Tamil Nadu', 'TR': 'Tripura', 'UR': 'Uttarakhand',
                                  'UP': 'Uttar Pradesh',
                                  'WB': 'West Bengal', 'TN': 'Tamil Nadu', 'TR': 'Tripura',
                                  'AN': 'Andaman and Nicobar Islands',
                                  'CH': 'Chandigarh', 'DH': 'Dadra and Nagar Haveli', 'DD': 'Daman and Diu', 'DL': 'Delhi',
                                  'LD': 'Lakshadweep', 'PY': 'Pondicherry', }
                dfAuditors = dfAuditors.replace({"Address of the auditor or auditors firm_State": replace_values})


                dfPrincipal_productsor_services.drop([0],inplace=True)
                logger.info("first row dropped")
                # dfAuditors_Comment.drop([0],inplace=True)
                # dfOther_Information.drop([0],inplace=True)
                # dfCSR.drop([0],inplace=True)
                # ==========================================================================================================
                # EXPORT TO EXCEL SHEET
                # ==========================================================================================================
                if (number_of_rows == 1 or number_of_rows == 2):
                    DFSharepointFolderStatus = pd.concat(
                        [PDFScrapingObj1.DFSharepointFolderDetails])
                elif (number_of_rows>2):
                    DFSharepointFolderStatus = pd.concat([PDFScrapingObj1.DFSharepointFolderDetails,PDFScrapingObj2.DFSharepointFolderDetails,PDFScrapingObj3.DFSharepointFolderDetails])
                DFSharepointFolderStatus.to_excel(writer, sheet_name='Folder Stats')
                # PDFScrapingObj2.DFSharepointFolderDetails.to_excel(writer, sheet_name='Folder Stats2')
                Stats.to_excel(writer, sheet_name='Stats')
                dfGeneral_information_of_the_comp.to_excel(writer, sheet_name='General information of the comp')
                dfHolding_Company.to_excel(writer, sheet_name='Holding Company')
                dfSubsidiary.to_excel(writer,sheet_name='Subsidiary')
                dfAuditors.to_excel(writer, sheet_name='Auditor Name')
                dfFinancial.to_excel(writer, sheet_name='Financials')
                dfLongTerm_Borrowings_unsecured.to_excel(writer, sheet_name='Long Term Borrowings  unsecured')
                dfShortTerm_Borrowing_secured.to_excel(writer, sheet_name='Short Term Borrowings unsecured')
                dfLongterm_loans_unsecured_good.to_excel(writer, sheet_name='Long term loans unsecured, good')
                dflongterm_loans_doubtful.to_excel(writer, sheet_name='long term loans (doubtful)')
                dfTradereceivables.to_excel(writer, sheet_name='Trade receivables')
                dfFinancial_Parameters_BS.to_excel(writer, sheet_name='Financial Parameters - BS')
                dfImport_Export_Data.to_excel(writer, sheet_name='Import Export Data')
                dfFinancial_Parameters_PNL.to_excel(writer, sheet_name='Financial Parameters - P&L')
                dfPrincipal_productsor_services.to_excel(writer, sheet_name='Principal products or services')
                dfAuditors_Comment.to_excel(writer, sheet_name='Auditors Comment')
                dfOther_Information.to_excel(writer, sheet_name='Other Information')
                dfCSR.to_excel(writer, sheet_name='CSR')

                # Close the Pandas Excel writer and output the Excel file.
                writer.save()
                logger.info("excel export completed")
                MessageUploadOutput = self.SharepointOperation("Upload File",
                                                             OutPutFile["OutPutFile"]+'OutPut_Non_XBRL_AOC_'+today+"_"+logtime+ ".xlsx",
                                                            "", logger, "")
                if (MessageUploadOutput == "File uploaded"):
                    logger.info("Output file has been uploaded to sharepoint")

                logger.info("Process Completed " + str(datetime.now().strftime('%d_%m_%Y %H_%M_%S')))
                dir_name =  XMLOutPutFile["XMLOutPutFile"]
                xmlfiles = os.listdir(dir_name)
                # Remove the XML files from the directory
                for item in xmlfiles:
                    if item.endswith(".xml"):
                        os.remove(os.path.join(dir_name, item))
            else:
                logger.info("No files to process, please check if folder exists on the sharepoint")

        except Exception as ex:
            logger.error(str(ex))

def main():
    try:
        ProcessStartTime = time.time()
        global logtoday ,logtime, data,jobhistory
        jobhistory = pd.DataFrame()
        loggerObj = Logs()
        mailobj = mail()        
        logtoday = date.today().strftime('%d-%m-%y')
        logtime= str(datetime.now().strftime('%H_%M_%S'))
        Month = str(date.today().month)
        datetime_object = datetime.strptime(Month, "%m")
        month_name = datetime_object.strftime("%B")
        Year = date.today().year
        today = date.today().strftime('%d_%m_%Y')

        logfilename = "AOC Parser_" + str(logtoday) + "_" + str(logtime) + ".txt"
        logger = loggerObj.setup_logger('AOC Parser',  LogFileAOC["LogFileAOC"]+logfilename)
        # logger = loggerObj.getLogger('AOC Parser')

        Obj1 = PDFScraping()
        logger.info("Process started = > Insert Query ")
        OutputPath = ""
        LogPath = settings_AOC4parsing.get('team_site_url')+'/Shared Documents/Dipti/' + str("In_Out_AOC")+"_"+str(Year)+'/'+str(month_name)+'/'+str(today)+'/'+logfilename
        data = [
            {'RunBy': 'AUTO', 'OutputFilePath': OutputPath, 'LogPath': LogPath, 'RunDuration': str(ProcessStartTime),
             'JobStatus': str('Running')}]
        jobhistory = jobhistory.append(data, ignore_index=True)
        Obj1.ManageSQLConnection(jobhistory, logger, "Insert")

        Obj1.PdfParser(logger)
        ProcessEndTime = time.time()

        TotalElapsedTime = time.strftime("%H:%M:%S %Z", time.gmtime(ProcessEndTime - ProcessStartTime))
        # dictionary with list object in values
        
        if not Stats.empty:
        
            df = Stats["Status"].value_counts()
            try:
                DataFound = [df.at['Data Found']]
            except Exception as ex:
                if str(ex) == "No Data Found":
                    DataFound=[0]
            try:
                DataNotFound =  [df.at['No Data Found']]
            except Exception as ex:
                if str(ex.args).strip() == '(\'No Data Found\',)':
                    DataNotFound = [0]

            try:
                details = {
                    "Total Files Run": [Stats.shape[0]],
                    "Success Files": DataFound,
                    "Failed Files": DataNotFound,
                    "Processed DateTime": [date.today().strftime('%d_%m_%Y')],
                    "Run By": 'Auto Trigger Process',
                    "Total Execution Time" : str(TotalElapsedTime)
                }
            except Exception as ex:
                details = {
                    "Total Files Run": [Stats.shape[0]],
                    "Success Files": DataFound,
                    "Failed Files": DataNotFound,
                    "Processed DateTime": [date.today().strftime('%d_%m_%Y')],
                    "Run By": 'Auto Trigger Process',
                    "Total Execution Time": str(TotalElapsedTime)
                }

            # creating a Dataframe object with skipping
            # one column i.e skipping age column.
            df_stats = pd.DataFrame(details)

            output = build_table(df_stats, 'orange_light', font_size='15px', text_align='center', width='auto',
                                 font_family='Open Sans,sans-serif')
            #
            mailobj.SendEmailToStakeHolders("AOC PDF Parser Status", "DNBSystemMailDoNotReply@dnb.com",
                                            "shethd@dnb.com", output,"AOC",LogPath)
        
        #  OutPutFile["OutPutFile"] + 'OutPut_Non_XBRL_AOC_' + today + ".xlsx"

            logger.info(f"{TotalElapsedTime} seconds to scrape all AOC PDF Forms data.")


            MessageUploadLog = Obj1.SharepointOperation("Upload File",
                                                        LogFileAOC["LogFileAOC"] + logfilename,
                                                        "", logger,"")

            if (MessageUploadLog == "File uploaded"):
                logger.info("log file has been uploaded to sharepoint")
                logging.shutdown()
                os.remove(os.path.join( LogFileAOC["LogFileAOC"], logfilename))
                # for item in os.listdir( LogFileAOC["LogFileAOC"]):
                #     if item.startswith("SharePointLog"):
                #         os.remove(os.path.join( LogFileAOC["LogFileAOC"], item))
            
            OutputPath = settings_AOC4parsing.get('team_site_url')+'/Shared Documents/Dipti/' + str("In_Out_AOC")+"_"+str(Year)+'/'+str(month_name)+'/'+str(today)+'/'+'OutPut_Non_XBRL_AOC_'+today+"_"+logtime+ ".xlsx"
            LogPath = settings_AOC4parsing.get('team_site_url')+'/Shared Documents/Dipti/' + str("In_Out_AOC")+"_"+str(Year)+'/'+str(month_name)+'/'+str(today)+'/'+logfilename
            data = [{'RunBy': 'AUTO', 'OutputFilePath': OutputPath, 'LogPath':LogPath,'RunDuration':str(TotalElapsedTime),'JobStatus':str('Success')}]
            jobhistory = jobhistory.append(data, ignore_index=True)
            Obj1.ManageSQLConnection(jobhistory,logger,"Update")
            print(f"{TotalElapsedTime} seconds to scrape all AOC PDF Forms data.")
        else:
            output = ""
            mailobj.SendEmailToStakeHolders("No Files to Process", "DNBSystemMailDoNotReply@dnb.com",
                                            "shethd@dnb.com", output,"AOC",LogPath)
            logger.info(f"{TotalElapsedTime} seconds to scrape all AOC PDF Forms data.")


            MessageUploadLog = Obj1.SharepointOperation("Upload File",
                                                        LogFileAOC["LogFileAOC"] + logfilename,
                                                        "", logger,"")

            if (MessageUploadLog == "File uploaded"):
                logger.info("log file has been uploaded to sharepoint")
                logging.shutdown()
                os.remove(os.path.join( LogFileAOC["LogFileAOC"], logfilename))
                # for item in os.listdir( LogFileAOC["LogFileAOC"]):
                #     if item.startswith("SharePointLog"):
                #         os.remove(os.path.join( LogFileAOC["LogFileAOC"], item))
            
            OutputPath = "No Data"
            LogPath = settings_AOC4parsing.get('team_site_url')+'/Shared Documents/Dipti/' + str("In_Out_AOC")+"_"+str(Year)+'/'+str(month_name)+'/'+str(today)+'/'+logfilename
            data = [{'RunBy': 'AUTO', 'OutputFilePath': OutputPath, 'LogPath':LogPath,'RunDuration':str(TotalElapsedTime),'JobStatus':str('Not Run')}]
            jobhistory = jobhistory.append(data, ignore_index=True)
            Obj1.ManageSQLConnection(jobhistory,logger,"Update")
            print(f"{TotalElapsedTime} seconds to scrape all AOC PDF Forms data.")

    except Exception as ex:
        logger.error(str(ex))
        mailobj.SendEmailToStakeHolders("AOC PDF Parser ERROR ", "DNBSystemMailDoNotReply@dnb.com",
                                        "shethd@dnb.com", str(ex),"AOC",LogPath)

if __name__ == '__main__':
    main()
    quit()