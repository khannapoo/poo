from datetime import datetime, tzinfo, timedelta

# ==============================================COMMON SETTINGS===========================================================================================================
chromedriver = {
    "Chrome": r"C:\Users\shethd\OneDrive - Dun and Bradstreet\Dipti_C\Dipti\Stash_Code_Repository\DNBDataIngestSQL\PyDocParser\chromedriver\chromedriver_win32/chromedriver"
}
browser = {
    "BROWSER": "Chrome"
}
DocumentdownloaddirectoryChrome = {
    "DownloadPath": r"C:\Users\shethd\OneDrive - Dun and Bradstreet\Dipti_C\Dipti\Stash_Code_Repository\PycharmProjects\pythonProject\DownloadFiles\\"
}
SMTPServer = {
    "External_SMTP": "smtp-gw.us.dnb.com",
    "Port": "25"
}

mysql = {
    "DRIVER": "{ODBC Driver 17 for SQL Server}",
    "SERVER": "10.252.5.10",
    "DATABASE": "InHouseData",
    "UID": "shethd",
    "PWD": "Password@123"
}

iAccess = {
    "DRIVER": "{ODBC Driver 17 for SQL Server}",
    "SERVER": "10.252.4.85",
    "DATABASE": "CompanySearch",
    "UID": "reporttodews",
    "PWD": "pass@1234"
}

FailedPDFS = {
    "FailedPDFS": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\OutputFiles\\FailedPDFs\\"
}

XMLOutPutFile = {
    "XMLOutPutFile": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\InputFiles\\XMLs\\"
}

AOCJobName = {
    "Job": "NonXBRLAOC4"
}

DIRJobName = {
    "Job": "DIR12"
}
# ==============================================AOC SETTINGS===========================================================================================================
InPutFileAOCNonXBRL = {
    "InPutFileAOC4": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\InputFiles\\AOC4\\"
}
LogFileAOC = {
    "LogFileAOC": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\LogFiles\\AOC4\\"
}
TrackFileDownload = {
    "TrackFileDownload": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\AdditionalFiles\\TrackAOCFileDownload.txt"
}
AOC4Template = {
    "AOC4Template": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\AdditionalFiles\\AOC4\\"
}
OutPutFile = {
    "OutPutFile": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\OutputFiles\\PDFs\\AOC4\\"
}
# ======================================================================================================

LogFileDIR12 = {
    "LogFileDIR12": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\LogFiles\\DIR12\\"
}
InPutFileDIR12 = {
    "InPutFileDIR12": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\InputFiles\\DIR12\\"
}
OutPutFileDIR12 = {
    "OutPutFileDIR12": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\OutputFiles\\PDFs\\DIR12\\"
}

# ===========================================================================================================================================
InPutFileForm8 = {
    "InPutFileForm8": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\PycharmProjects\\PyDocParser\\form8\\"
}
PorcessedPDFS = {
    "PorcessedPDFS": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\PycharmProjects\\PyDocParser\\ProcessedPDFs\\"
}
ImagePath = {
    "ImagePath": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\PycharmProjects\\PyDocParser\\img\\"
}

# ======================================Financial Upload======================================

InPutFilesFinancial = {
    "InPutFilesFinancial": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\InputFiles\\FinancialFiles\\"
}
LogFileFinancial = {
    "LogFileFinancial": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\LogFiles\\FinancialFiles\\"
}

OutPutFileFinancial = {
    "OutPutFileFinancial": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\OutputFiles\\Financial\\"
}

AutoFinUploadJob = {
    "Job": "AutoFinUploadJob"
}

Yesterday = {
    "Yesterday": (datetime.now() - timedelta(1)).strftime('%Y-%m-%d')

}

SevenDaysOldFile = {
    "SevenDaysOldFile": (datetime.now() - timedelta(1)).strftime('%Y-%m-%d')

}
Today = {
    "Today": (datetime.now()).strftime('%Y-%m-%d')

}
ccamfin_env={"Env":"sand".lower()}

if ccamfin_env["Env"]=="sand":

    ftp = {"hostName":"mftweb.dnb.com","userName":"BLT356_test","pswd":"DUNS@1b2c3z4"}
    TokenDictCCAMFinUpload = {"FinsUpload_Fiscal":"1af3acf73c194eceb2d11bb962fc2a2e",
                                "FinsUpload_PLTMPL":"e16ca3de6ab4462eb35530aa3f93f58e",
                                "FinsUpload_Cashflow":"b2706409a8424f2ab8d6988db8bbf8a2",
                                "FinsUpload_BSTMPL_Section":"b81e9f40d95341f2a7678be8cb71b3c7"
                                }
elif ccamfin_env["Env"]=="prod":
    # ftp = {"hostName":"mft.dnb.com","userName":"UBLT356IT","pswd":"P@ssW0rd@1234"}
    ftp = {"hostName": "mft.dnb.com", "userName": "UBLT356IT", "pswd": "P@ssW0rd@1234"}
    TokenDictCCAMFinUpload = {"general_non_loop_All":"be95a6d41e014029a914bde160b6970",
                                "General_EXIM_Loop_All":"838a19168cb14032bb3bcddcca136d4",
                                "CMPL2_MCA_Looping_All":"d3a964c2b3ff460ea78864053950b12",
                                "Relcon_SUBS_Looping_All":"f46d96dc12524d29b2c85df05350d39"
                                }
# ======================================Non Financial Upload======================================
InPutFilesNonFinancial = {
    "InPutFilesNonFinancial": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\InputFiles\\NonFinancialFiles\\"
}
LogFileNonFinancial = {
    "LogFileNonFinancial": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\LogFiles\\NonFinancialFiles\\"
}

OutPutFileNonFinancial = {
    "OutPutFileNonFinancial": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\OutputFiles\\NonFinancial\\"
}

AutoNonFinUploadJob = {
    "Job": "AutoNonFinUploadJob"
}
# FTP Details


# ======================================Report to DEWS Config details======================================

InPutFilesReportToDews = {
    "InPutFilesReportToDews": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\InputFiles\\ReportToDews\\"
}
LogFileReportToDews = {
    "LogFileReportToDews": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\LogFiles\\ReportToDews\\"
}

OutPutFilesReportToDews = {
    "OutPutFilesReportToDews": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\OutputFiles\\ReportToDews\\"
}

ReportToDewsJob = {
    "Job": "AutoFinUploadJob"
}

# Yesterday ={
#     "Yesterday" :(datetime.now() - timedelta(1)).strftime('%Y-%m-%d')
#
# }

ThreeMonthsOldFile = {
    "ThreeMonthsOldFile": (datetime.now() - timedelta(1)).strftime('%Y-%m-%d')

}
# Today ={
#     "Today" :(datetime.now()).strftime('%Y-%m-%d')
#
# }


TokenDict = {"General_non_loop_Insert": "dfd10fdcfa884e04bcab904a84520cc4",
             "Gen_Insurance_Insert": "12cf896831614e568700748f1d8fa36a",
             "Gen_Insurance_Delete": "bf517cc3d8ac43d6ac18aa9013e21c34",
             "Gen_Award_Insert": "375d745ff54b479db47d31cfca1745d7",
             "Gen_Award_Delete": "2b982b7f68654c2788e1701fb3b327ee",
             "Gen_Membership_Insert": "377c0e3ba5ff4d7ca599c80b0f0eb3b7",
             "Gen_Membership_Delete": "5058399aefd74859a035eebf2a7e3abc",
             "Gen_Registration_Insert": "87111720c8fd40e4ac5dad2c25a996f8",
             "Gen_Registration_Delete": "d66fc662eb044278b478d57f35c53d8a",
             "Gen_TradeStyle_Insert": "54bb87019c314e118bfad2c569f4acdd",
             "Gen_TradeStyle_Delete": "54c32b56933e434aa017582a735d4dd4",
             "Gen_ProvFins_Insert": "9046e1fdcf4249abad753c7c3762cb39",
             "Gen_ProvFins_Delete": "b7e38e16116440fd82db6c6984157356",
             "Gen_ISOCert_Insert": "e5fbcc6454bd4ef2954c624fa4b5c674",
             "Gen_ISOCert_Delete": "0c6670d3c2be4f769ee93ecb73531c65",
             "Gen_Product_Insert": "33c59515c1b84e3da45993901094229f",
             "Gen_Product_Delete": "3be59a755e154cc0b1d7a9f39f06995e",
             "Gen_CustomerTable_Insert": "e99634191553436eb802e742ffa87e80",
             "Gen_CustomerTable_Delete": "9e2ba920f17d4ae28788a2463a863822",
             "Gen_ExportTerms_Insert": "897410aa758442239ec0cf45e2b5acc0",
             "Gen_ExportTerms_Delete": "55f99977f78f4166a661f317a89895be",
             "Gen_LocalSalesTerms_Insert": "4f92d0cbc4da4dcb85e489b07be470a8",
             "Gen_LocalSalesTerms_Delete": "ac374b359e6c4788859fd78690a38050",
             "Gen_CountrywiseExport_Insert": "9ec448f1d8624e579db5b14452d99b24",
             "Gen_CountrywiseExport_Delete": "46aeb53082e5420bbc14866b6254aa43",
             "Gen_localPurchTerms_Insert": "dfee9ca9e3844f838ccc2c40fb7b0b2d",
             "Gen_localPurchTerms_Delete": "13dd086db9984793ad3a77653fd74858",
             "gen_ImportTerms_Insert": "a48399bcd54e42ecbd0018517534b0a6",
             "gen_ImportTerms_Delete": "e97e3986523d493d897ea24699e425c0",
             "Gen_Countrywise_Purchase_Insert": "60caa5f20c5a465d9e67611ce39a7172",
             "Gen_Countrywise_Purchase_Delete": "ac98cd048ea148e284f376968614e412",
             "General_Source_Insert": "039e21ed3ec34cfdbfabf9a62510074d",
             "General_Telephone_Insert": "900f51c9a3374221b2b2b39cb22897ce",
             "General_Telephone_Delete": "b2a687f904ad449db129fc9761b215e6",
             "Gen_SIC_Insert": "70f6bca2940b49bd877596abb3f00a0b",
             "Gen_SIC_Delete": "f86b2cd699364ad9a3b75e17e3de2b09",
             "History_Non_loop_Insert": "7da868ad6939416cb1051744152b2742",
             "History_Address_Insert": "c4e9bf52975a44d184bb55c6f1e27b11",
             "History_Address_Delete": "97533f6d98be4484b4fc2d4aff4dbc40",
             "History_Background_Insert": "1195063c0cda4836ac0dd4caa93a215c",
             "History_Background_Delete": "c22e4e85c52845d28c208acfbc10412b",
             "History_auditor_Insert": "c1b59a6e26ee40e3ac9aaac05e38ee0a",
             "History_auditor_Delete": "dddc16a85a514898b592c8d910d32776",
             "History_StockExchange_Insert": "244b45d5afa049119cafeb182054f8f2",
             "History_StockExchange_Delete": "f2369a4a7e51496091ed59eb3d11eec3",
             "History_Authorize_Insert": "28714faf06444eba933204ff7ad6e8f4",
             "History_Authorize_Delete": "542a1dd98edd414bbe78226c68a525bb",
             "History_Issued_Insert": "d816454ddc884d21ade4190947dc7f55",
             "History_Issued_Delete": "5058d103ad9647d6aadd145f3b803553",
             "History_Paidup_Insert": "670b40777dc84b9e96a4f11626c7eb90",
             "History_Paidup_Delete": "729d8230d421437bb3576d497e8aa741",
             "History_Sharehold_Insert": "0b2cc405148e46eeaca6910942faf139",
             "History_Sharehold_Delete": "f71402a92b2f4f64aaeed2a6175f6ead",
             "Mgmt_Loop_Non_Loop_Insert": "5d82870dbecf4d3594b49f477c313639",
             "Mgmt_Loop_Non_Loop_Delete": "4d0edabaa6fb4414a80b52de4db2fe56",
             "Relcn_Non_loop_Insert": "4746fa0afb6845739494b18470a93b7c",
             "Rel_Subsidiary_Insert": "fe7543eca60f453d899051cff816ff90",
             "Rel_Subsidiary_Delete": "71329e4fb69244f8b33672f3dcb20b37",
             "Rel_Affiliate_Insert": "225c6579c25746209ddeb00152c45810",
             "Rel_Affiliate_Delete": "909be02acbdd45ec8eaeb55f96ec186a",
             "Rel_Branch_Insert": "cc6da759fa2747819f548cd1c62026ce",
             "Rel_Branch_Delete": "20f941f82ae8480bab4b5802f582e7f0",
             "Cinvest_Loop_Insert": "bee858bd2e824386bcc0c9ee4e9cf10c",
             "Cinvest_Loop_Delete": "2fa5a62160e644e19fcc00988915ee0e",
             "Bank_Loop_Non_Loop_Insert": "28372712f89d4146b6285a4bc17f1e87",
             "Bank_Loop_Non_Loop_Delete": "a652430d4e9b4c9ba73617bf360865bc",
             "Supplier_looping_Insert": "ec8bec21cebe4c10b7cac0a95adaf58b",
             "Supplier_looping_Delete": "1196db14c7b24774b2f679d451674950"
             }

# ==========================GDO NON FINANCIAL AUTO UPLOAD================================

sftpauth = {
    "sftphostkey" : r'C:\Users\shethd\.ssh\known_hosts'
}

emailreceipient = {
    "emailreceipient" : 'shethd@dnb.com'
}

InPutFilesGDONonFinUpload = {
    "InPutFilesGDONonFinUpload": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\InputFiles\\GDONonFinFiles\\"
}
LogFileGDONonFinUpload = {
    "LogFileGDONonFinUpload": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\LogFiles\\GDONonFinFiles\\"
}

OutPutFilesGDONonFinUpload = {
    "OutPutFilesGDONonFinUpload": "C:\\Users\\shethd\\OneDrive - Dun and Bradstreet\\Dipti_C\\Dipti\\Stash_Code_Repository\\DataOperations\\PyDocParser\\OutputFiles\\GDONonFinFiles\\"
}

gdononfin_env={"Env":"sand".lower()}

if gdononfin_env["Env"]=="sand":

    ftp = {"hostName":"mftweb.dnb.com","userName":"BLT356_test","pswd":"DUNS@1b2c3z4"}
    TokenDictGDONonFinUpload = {"general_non_loop_All":"ea69b08b6d414c769e0b24e54f574545",
                                "General_EXIM_Loop_All":"77853ff0f471452d8aed47ad95302075",
                                "CMPL2_MCA_Looping_All":"435613efabb84d9f940fb3a91ba3ae9e",
                                "Relcon_SUBS_Looping_All":"58e8b0338e714c3d88e00163385063ae",
                                "Relcon_AFFiliate_Looping_All":"dc2922641ea247b5bd077f52b6030421",
                                "Relcon_Parent_Non_Looping_All":"293787ad940e45b096db790187e9254a",
                                "History_Auditor_Loop_All":"8eafd7284e514f45838df2d9197a967f",
                                "History_Charge_details_Loop_All":"f5f7b40bd0c644e8a66ba7ff186886c1",
                                "History_MCA_Non_Loop_All":"d81a4bb182954968966e7e1b13002125",
                                "History_ROC_Add_Looping_All":"3f37f50d276042f7a4fd40d168a07d90",
                                "History_other_than_ROC_Add_Loop_All":"835a1e83863547a5b033c1af5f5ba04c",
                                "History_Non_Looping_All":"f88b8dc413294ef4a3a5bb2e8de6fce0",
                                "History_Looping_All":"ceeed618806e4768a7b6059c9b2853d4",
                                "History_Sh_Holding_Looping_All":"99790001940042b78f89df48c05c15b1",
                                "MGMT_Director_Sec_Loop_All":"f50d134fb95348dfb1567440b2166ee5",
                                "MGMT_Other_Dir_Details_Loop_All":"1a3dcf0d81ca4e43a444830fe461cca3",

                                "General_EXIM_Loop_All_Delete": "78dad21a36444033894ac1ac40e168fb",
                                "Relcon_SUBS_Looping_All_Delete": "1bacddda940e460385c88a4c58ee3252",
                                "Relcon_AFFiliate_Looping_All_Delete": "1e84097fcb7d4c579aba3bd6d0b17c87",
                                "History_Auditor_Loop_All_Delete": "98039fb44bab4c239d8efc7b5f51bc4a",
                                "History_Charge_details_Loop_All_Delete": "6c1e96bbbc47403c8e2fd4c8161364ef",
                                "History_ROC_Add_Looping_All_Delete": "dd9d80d503d742429f5f7f1d9298f0c6",
                                "History_other_than_ROC_Add_Loop_All_Delete": "b69306018b124e45a4cef885c12e5732",
                                "History_Looping_All_Delete": "15b86fa6d306499799d06266b48f365e",
                                "History_Sh_Holding_Looping_All_Delete": "e99c44d209a044e9a3b1926ad7ede9a5",
                                "MGMT_Director_Sec_Loop_All_Delete": "896237b5f7954ad28b968b812ae5e012"
                                }
elif gdononfin_env["Env"]=="prod":
    # ftp = {"hostName":"mft.dnb.com","userName":"UBLT356IT","pswd":"P@ssW0rd@1234"}
    ftp = {"hostName": "mft.dnb.com", "userName": "UBLT356IT", "pswd": "P@ssW0rd@1234"}
    TokenDictGDONonFinUpload = {"general_non_loop_All":"be95a6d41e014029a914bde160b69701",
                                "General_EXIM_Loop_All":"838a19168cb14032bb3bcddcca136d4b",
                                "CMPL2_MCA_Looping_All":"d3a964c2b3ff460ea78864053950b125",
                                "Relcon_SUBS_Looping_All":"f46d96dc12524d29b2c85df05350d39d",
                                "Relcon_AFFiliate_Looping_All":"08cf00ed4d6146e0bc514eb9882b8ea3",
                                "Relcon_Parent_Non_Looping_All":"f9da5f75d91f412282664f7610cecf84",
                                "History_Auditor_Loop_All":"6d8812f8eb6f410a9c0f204ea831b7b6",
                                "History_Charge_details_Loop_All":"1e3dcfb3f01642bfa97193c60d8bdf12",
                                "History_MCA_Non_Loop_All":"5c09eb758a814a9db01f3d13644334c2",
                                "History_ROC_Add_Looping_All":"e5ad5c5620454ba3b2c2eeed6d472644",
                                "History_other_than_ROC_Add_Loop_All":"fa77a6a8714745f8996e49291171a532",
                                "History_Non_Looping_All":"421c06aca5ba463eb34efcfd10310f5a",
                                "History_Looping_All":"d5880902cec14130b9c9cfcb1cb49be8",
                                "History_Sh_Holding_Looping_All":"2ce91b670a0b405b91af5a8222f9b3e0",
                                "MGMT_Director_Sec_Loop_All":"f01ceacbd2ad4e128b00e5b35c87a483",
                                "MGMT_Other_Dir_Details_Loop_All":"c92066a38c1242248a3090126482fb73",

                                "General_EXIM_Loop_All_Delete":"3ea64947013241f59786be4e6e9ee8e0",
                                "Relcon_SUBS_Looping_All_Delete":"19c83b5d6b044930b1f7c73c92c17814",
                                "Relcon_AFFiliate_Looping_All_Delete":"703a4ccc276a48878bde9b765387bdb4",
                                "History_Auditor_Loop_All_Delete": "6436b6ffeb0740cc9a5891182dc2ad17",
                                "History_Charge_details_Loop_All_Delete": "0f5c0a5387ec457594573f45328a41ce",
                                "History_ROC_Add_Looping_All_Delete": "aa88cf8adc8b4280990980e266cf45d6",
                                "History_other_than_ROC_Add_Loop_All_Delete": "b3f842e7a98c4a2eb7dda7499bd2e336",
                                "History_Looping_All_Delete": "d3fa3e74a7ee498da4aaf2b80e40bde2",
                                "History_Sh_Holding_Looping_All_Delete": "217c345a038246248a6d6cb2fbd90dca",
                                "MGMT_Director_Sec_Loop_All_Delete": "3dc26e4f072441cd8b075c127ada92a6",

                                }

