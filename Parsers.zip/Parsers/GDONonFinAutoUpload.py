import os
import traceback
import numpy as np
import openpyxl
import pandas as pd
import paramiko
from pretty_html_table import build_table
import pysftp as pysftp
from SetLogger import Logs
from office365.runtime.auth.client_credential import ClientCredential
from office365.sharepoint.client_context import ClientContext
import time
from datetime import date
from SendEmail import SendEmail as mail
from DatabaseConfigFile import *
from SharepointSettings import settings_ReportToDews
import pyodbc
from pathlib import Path
from openpyxl import load_workbook
import functools

class NonFinAutoUpload:

    def managesqlconnection(self,  duns,  companyname,  logger):

        try:
            # CompanyName=regex.escape(CompanyName, special_only=False)
            sql_conn = pyodbc.connect(
                'DRIVER=' + iAccess["DRIVER"] + ';SERVER=' + iAccess["SERVER"] +
                ';DATABASE=' + iAccess["DATABASE"] + ';UID=' + iAccess["UID"] + ';PWD=' + iAccess[
                    "PWD"] + '')
            cursor = sql_conn.cursor()

            sql2 = """\
            EXEC VerifyDUNSLegalName   @DUNS = ?, @CompanyName = ?;"""

            values2 = (str(duns),  companyname)

            cursor.execute(sql2,  values2)
            rc = cursor.fetchval()
            print(rc)
            sql_conn.commit()
            cursor.close()
            sql_conn.close()
            logger.info("Data Stored : Process Completed")
            return rc
        except Exception as ex:
            logger.error("SQL Error")
            logger.error(str(ex))
            return 0

    def __init__(self):
        self.DFSharepointFolderDetails = pd.DataFrame(
            columns=['Folder Name',  'File Count',  'Folder Status',  'ProcessedDateTime'])

    def sharepointoperation(self,  action,  file,  logger,  fileType):

        SharepointFolderDetails = []
        NonFinAutoUploadObj = NonFinAutoUpload()
        try:
            ctx = ClientContext(settings_ReportToDews.get('team_site_url')).with_credentials(
                ClientCredential(settings_ReportToDews['client_credentials']['client_id'],
                                 settings_ReportToDews['client_credentials']['client_secret']))

            if (action == "Upload File"):
                if (fileType == "LOGS"):
                    path = file
                    folder_url = '/Shared Documents/GDO/Logs_Stats/NonFinancialUploadLogs/'
                    with open(path,  'rb') as content_file:
                        file_content = content_file.read()
                    target_folder = ctx.web.get_folder_by_server_relative_url(folder_url)
                    name = os.path.basename(path)
                    target_folder.upload_file(name,  file_content)
                    ctx.execute_query()
                elif (fileType == "CSV"):
                    folder_url = '/Shared Documents/GDO/ProcessedNonFinCSVFiles/'
                    for file in os.listdir(Outputdirectory):
                        try:
                            if not file.endswith(".csv"):
                                continue
                            target_folder = ctx.web.get_folder_by_server_relative_url(folder_url)
                            path = os.path.join(Outputdirectory,  file)
                            name = os.path.basename(
                                os.path.join(Outputdirectory,  file))
                            with open(path,  'rb') as content_file:
                                file_content = content_file.read()

                            target_folder.upload_file(name,  file_content)
                            ctx.execute_query()
                        except Exception as ex:
                            logger.error("Could not upload the file to csv")

                return "File uploaded"

            elif (action == "Download File"):
                try:
                    folder_url = '/Shared Documents/GDO/VendorList/'
                    folders = ctx.web.get_folder_by_server_relative_url(folder_url).folders
                    ctx.load(folders)
                    ctx.execute_query()
                    FileListCount = []
                    t0 = time.time()
                    try:
                        # len(folders)
                        for folder,  i in zip(folders,  range(0,  len(folders))):
                            FileCoun = 0
                            try:
                                FolderName = str(folder.properties["Name"])
                                IgnoreFolderNames = ['Vendor2', 'Vendor3']
                                files = ctx.web.get_folder_by_server_relative_url(
                                    folder_url + FolderName).files
                                if FolderName in IgnoreFolderNames:
                                    continue
                                # files = folder.files
                                ctx.load(files)
                                ctx.execute_query()
                                if (len(files) > 0):
                                    List = [FolderName,  len(files),  "File Available",  str(today) + "_" + str(logtime)]
                                else:
                                    List = [FolderName,  len(files),  "Folder Empty",  str(today) + "_" + str(logtime)]
                                SharepointFolderDetails.append(List)

                                NonFinAutoUploadObj.DFSharepointFolderDetails.loc[
                                    len(NonFinAutoUploadObj.DFSharepointFolderDetails)] = List
                                for cur_file,  i in zip(files,  range(0,  len(files))):
                                    if 'Non Financial' in (str(cur_file.properties["Name"])):
                                        FileCoun = FileCoun + 1

                                        download_FileName = os.path.join(InPutFilesGDONonFinUpload[
                                                                             "InPutFilesGDONonFinUpload"],
                                                                         FolderName + "_" + os.path.basename(
                                                                             cur_file.properties["Name"]))
                                        file_url = '/sites/ReportToDews/Shared Documents/GDO/VendorList/' + FolderName+"/" + os.path.basename(
                                            cur_file.properties["Name"])

                                        with open(download_FileName,  "wb") as local_file:
                                            file = ctx.web.get_file_by_server_relative_url(file_url).download(
                                                local_file).execute_query()

                                        logger.info("File name: {0}".format(
                                            str(FolderName + "_" + cur_file.properties["Name"])))
                                    # delete the file from sharepoint
                                    # file.delete_object()
                                    # ctx.execute_query()
                                FileListCount.append(FileCoun)
                            except Exception as ex:
                                logger.error(str(ex) + traceback.format_exc())
                                continue

                    except Exception as ex:
                        logger.error(str(ex) + traceback.format_exc())

                    if len(folders) != 0:
                        t1 = time.time()
                        Series = pd.Series(FileListCount)
                        NonFinAutoUploadObj.DFSharepointFolderDetails["FileCount"] = Series
                        elapsed = time.strftime("%H:%M:%S %Z",  time.gmtime(t1 - t0))

                        logger.info("Folder has been downloaded")
                        logger.info("Total time to download the files is " + str(elapsed))
                        return "Folder has been downloaded",  NonFinAutoUploadObj
                    else:
                        logger.info("No folders to download")
                        return "Folder has not been downloaded",  NonFinAutoUploadObj

                except Exception as ex:
                    logger.error(str(ex) + traceback.format_exc())
                    logger.error("SharePoint Folder has not been downloaded")
                    return "Folder has not been downloaded",  NonFinAutoUploadObj

            elif (action == "Delete File"):
                try:
                    folder_url = '/Shared Documents/GDO/ProcessedFinCSVFiles/'
                    files = ctx.web.get_folder_by_server_relative_url(folder_url).files

                    ctx.load(files)
                    ctx.execute_query()
                    FileListCount = []
                    # len(folders)
                    for file,  i in zip(files,  range(0,  len(files))):
                        try:
                            TimeCreated = (str(file.properties['TimeCreated']).split('T')[0])
                            TimeCreated = datetime.strptime(TimeCreated,  '%Y-%m-%d')
                            YesterdayDate = datetime.strptime(Yesterday["Yesterday"],  '%Y-%m-%d')
                            todaydate = datetime.strptime(Today["Today"],  '%Y-%m-%d')

                            duration = (todaydate - TimeCreated).days

                            if duration>7:
                                file.delete_object()
                                ctx.execute_query()
                                logger.info("CSV File was deleted")
                            else:
                                logger.info("No Files found older than 7 days")
                            # FileListCount.append(FileCoun)
                        except Exception as ex:
                            logger.error(str(ex) + traceback.format_exc())
                            continue

                    return "CSV Files have been deleted",  NonFinAutoUploadObj

                except Exception as ex:
                    logger.error(str(ex) + traceback.format_exc())

            elif (action == "Delete Log File"):
                try:
                    folder_url = '/Shared Documents/GDO/Logs_Stats/NonFinancialUploadLogs/'
                    files = ctx.web.get_folder_by_server_relative_url(folder_url).files

                    ctx.load(files)
                    ctx.execute_query()

                    # len(folders)
                    for file,  i in zip(files,  range(0,  len(files))):
                        try:
                            timecreated = (str(file.properties['TimeCreated']).split('T')[0])
                            timecreated = datetime.strptime(timecreated,  '%Y-%m-%d')
                            sevendaysold = datetime.strptime(SevenDaysOldFile["SevenDaysOldFile"],  '%Y-%m-%d')
                            todaydate = datetime.strptime(Today["Today"],  '%Y-%m-%d')
                            if timecreated < sevendaysold:
                                file.delete_object()
                                ctx.execute_query()
                                logger.info("Log files older than 7 days were deleted")
                            # FileListCount.append(FileCoun)
                        except Exception as ex:
                            logger.error(str(ex) + traceback.format_exc())
                            continue

                    return "Log Files have been deleted",  NonFinAutoUploadObj

                except Exception as ex:
                    logger.error(str(ex) + traceback.format_exc())

        except Exception as ex:
            logger.error(str(ex) + traceback.format_exc())

    def UpdateFieldIDDataframes(self,  df,  logger):
        try:
            lastcolindex= df.columns.get_loc("SheetName")
            sheetname = str((df.iat[0,lastcolindex]))
            if "MGMT_Director_Sec_Loop" in sheetname:
                df['sid'] = df.groupby('duns_no').cumcount() + 1
                df['sid'] = -df['sid'].astype(int)
                df.applymap(lambda x: x.strip() if type(x) == str else x)
                # length of the below fields is 8 digits and hence below code
                df['DIN_Number_IT'] = df['DIN_Number_IT'].astype('Int64').apply(lambda x: '{0:0>8}'.format(x))
                df['DIN_EL'] = df['DIN_EL'].astype('Int64').apply(lambda x: '{0:0>8}'.format(x))
                cols=df.columns
                # mask = (df['DIN_Number_IT'].str.contains("NA")
                # replacing 0000<NA> with space
                for col in cols:
                    if (col=="DIN_Number_IT" or col=="DIN_EL"):
                        if df[col].astype('str').str.contains("NA").any():
                            df[col] = df[col].str.replace(r'0000<NA>', '')
                # df.apply(lambda y: y.str.replace('c', case=False), 1).any(1)
                # df.mask(df.columns.values.contains("NA"), "")
                # df['Identity Number_Mgmtbac:EL'] = df['Identity Number_Mgmtbac:EL'].apply(lambda x: '{0:0>8}'.format(x))
            elif "MGMT_Other_Dir_Details_Loop" in sheetname:
                df['id'] = df.groupby('duns_no').cumcount() + 1
                df['id'] = df['id'].astype(int)
                df.applymap(lambda x: x.strip() if type(x) == str else x)
                df['DIN_Number_IT'] = df['DIN_Number_IT'].astype('Int64').apply(lambda x: '{0:0>8}'.format(x))
            else:
                df['id'] = df.groupby('duns_no').cumcount() + 1
                df['id'] = -df['id'].astype(int)
                df.applymap(lambda x: x.strip() if type(x) == str else x)

        except Exception as ex:
            logger.error(str(ex))

    def validatedunsnumber(self,  df,  logger):
        try:
            # df.iloc[:,  0]
            # covert the column into string
            df.iloc[:,  0] = df.iloc[:,  0].astype('str')
            # Mask the Dataframe
            mask = (df.iloc[:,  0].str.len() == 9)
            df = df.loc[mask]
            df.reset_index(inplace=True,  drop=True)
            return df
        except Exception as ex:
            logger.error(str(ex))

    def validatefields(self,  df,  logger):
        try:
            # sheetname = str(df["SheetName"])
            if "History_Sh Holding_Looping" in df.loc[0,"SheetName"]:
                cin_or_pan_available = False
                # II Column contains CIN, PAN and DIN, DIN has seperate logic of 8 numbers
                cin_or_pan_available= (df["Identity Type_History_II"]=='CIN').any() or (df["Identity Type_History_II"]=='PAN').any()
                if (~cin_or_pan_available):
                    df = df.astype({'Identity Number_History_IK': 'Int64'})
                    # 'Identity Number_History_IK': 'Int64'
                    df['Identity Number_History_IK'] = df['Identity Number_History_IK'].astype('Int64').apply(lambda x:'{0:0>8}'.format(x))
                    df['Identity Number_History_IK'] = df['Identity Number_History_IK'].str.replace(r'0000<NA>', '')

                return df

        except Exception as ex:
            logger.error(str(ex))

    def autofinnonfin(self,  logger):
        '''This function will scrap the annual statements data, it takes logger objec to
        log the error in the error log file'''
        global StatsList, ValidationStatsList,Outputdirectory
        FTPStats = []
        StatsList, ValidationStatsList = [], []
        Inputdirectory = InPutFilesGDONonFinUpload["InPutFilesGDONonFinUpload"]
        Outputdirectory = OutPutFilesGDONonFinUpload['OutPutFilesGDONonFinUpload']
        dataAll = [
            ['general_non loop', 'general_non loop', 'NL', 'N', 'A:G',["duns_no", "Report Base Date_zd", "email-ID_general_ax", "general_et", "general_ev", "general_du","general_dw", "SheetName"]],
            ['MGMT_Director_Sec_Loop', 'MGMT_Director_Sec_Loop', 'L', 'Y', 'A,C:N',["duns_no", "Update Date_EB", "FULL NAME_AG", "First Name_EE", "Middle Name_EF", "Surname_EG","DIN_Number_IT", "Identity Type_EK", "DIN_EL", "DESIGNATION_FP", "DATE_JOIN_FT", "RETIRE/RESGNED_GL","DATE_RESIGN_GM", "SheetName"]],
            ['MGMT_Other_Dir_Details_Loop', 'MGMT_Other_Dir_Details_Loop', 'L', 'N', 'A,D:G',["duns_no", "Duns_GW", "COMPANY_NAME_GX", "DIN_Number_IT", "DESIGNATION_GZ", "SheetName"]],
            ['General_EXIM_Loop', 'General_EXIM_Loop', 'L', 'Y', 'A,D,I:K,O:Q',["duns_no", "Year_hk", "Import(CIF Value)(in '000)_hl", "Units in Size_hm", "Currency_hn","Export(FOB Value)(in '000)_ho", "Units in Size_hp", "Currency_hq", "SheetName"]],
            ['History_Auditor_Loop', 'History_Auditor_Loop', 'L', 'Y', 'A:C',["duns_no", "Auditor Name__Hist__jx", "Country__Hist__aj", "SheetName"]],
            ['History_Charge_details_Loop', 'History_Charge_details_Loop', 'NL', 'Y', 'A,C:P',["duns_no", "CHARGE_ID_ob", "SRN_OB", "CHARGE_HOLDER_oi", "DATE_CREATE_oc", "DATE_MODIFIED_OC","DATE_SATISFIED_OD", "Charge Status_OK", "AMOUNT_oe", "FULL ADDRESS_OE", "Street 1_OF", "Street 2_OG","City_OH", "State_OI", "Pincode_OJ", "SheetName"]],
            ['History_Non Looping', 'History_Non Looping', 'L', 'N', 'A:J',["duns_no","Total amount of equity shares (in rupees) Subscribed capital rupees)_History_gt","PAR value _History_gu","Currency_History_gv","Total amount of preference shares (in rupees) Subscribed capital_History_gx","PAR value_History_gy","Currency_History_gz","Last AGM Date_History_ju","Last Financial Date_History_jw","SheetName"]],
            ['History_MCA_Non Loop', 'History_MCA_Non Loop', 'L', 'N', 'A:C,E:J',["duns_no", "Update_Date_fb", "CIN_fi", "DATE_OF_REGISTRATION_ff", "ROC_AA", "Category_FB", "Class_FD","SubCategory_FC", "No.of Members_FE", "SheetName"]],
            ['History_ROC_Add_Looping', 'History_ROC_Add_Looping', 'L', 'Y', 'A:G',["duns_no", "Registered_Address_AB", "Street1_jj", "Street2_jk", "City_tb", "State_jq", "Pincode_jr","SheetName"]],
            ['History_other than_ROC_Add_Loop', 'History_other than_ROC_Add_Loop', 'NL', 'Y', 'A:G',["duns_no", "ADDRESS_OTHER_THAN_RO_AC", "Street1_AD", "Street2_AE", "City_AF", "State_AG", "Pincode_AH","SheetName"]],
            ['History_Looping', 'History_Looping', 'L', 'Y', 'A:I', ["duns_no", "Total Authorised Capital_History_gj","Currency_History_gk","Issued Capital_History_gm","Currency_History_gn","Paid up TYPE _history_hi","PAID Up capital Amount_history_hj","Currency_History_hk","Capital As at_History_na", "SheetName"]],
            ['History_Sh Holding_Looping', 'History_Sh Holding_Looping', 'NL', 'Y', 'A:K',["duns_no", "Corporate S-Holder/Proprietor/Partner_History_ib", "Family Surname__History_ie","Public/Others_History_hv", "Country_history_ig", "No of Shares Held_history_ik","Shareholder Type_history_IG", "Shareholder Duns_history_IH", "Identity Type_History_II","Identity Number_History_IK", "Shareholding as at (date)_History_pc", "SheetName"]],
            ['Relcon_SUBS_Looping', 'Relcon_SUBS_Looping', 'L', 'Y', 'A:L',["duns_no", "Update Date_Relcon_CB", "DUNS_Relcon_CF", "CIN_Relcon_AA", "Name of Subs_Relcon_CG","Address 1_Subs_Relcon_CJ", "Address 2_Subs_Relcon_CK", "City_Subs_Relcon_CO", "State_Subs_Relcon_CQ","Pincode_Subs_Relcon_CR", "Country of Subs_Relcon_CS", "% of Subs_Relcon_CW", "SheetName"]],
            ['Relcon_AFFiliate_Looping', 'Relcon_AFFiliate_Looping', 'L', 'Y', 'A:P',["duns_no", "Update Date_Relcon_CB", "Joint Venture (Tick)__Relcon_BF", "Affiliate Duns__Relcon_BG","CIN_Relcon_AB", "Name of the company_Relcon_BH", "Address 1_Aff_Relcon_BK", "Address 2_Aff_Relcon_BL","City_Aff_Relcon_BP", "State_Aff_Relcon_BR", "Pincode_Aff_Relcon_BS", "Country_Relcon_BT","Subject holds Shares in Affiliate (Tick Box)_Relcon_BW", " % of Share held_Relcon_FA","Affiliate holds Shares in Subject (Tick Box)_Relcon_BX", " % of Share held_Relcon_FC", "SheetName"]],
            ['Relcon_Parent_Non Looping', 'Relcon_Parent_Non Looping', 'L', 'N', 'A:N',["duns_no", "Update Date_Relcon_CB", "Holding_Relcon_DC", "Parent DUNS_Relcon_DE","Parent CIN_Relcon_AC", "Name of the company_Relcon_DF", "Address 1_Relcon_DI", "Address 1_Relcon_DJ","City_Relcon_DN", "State_Relcon_DP", "Postal Code_Relcon_DQ", "Country_Relcon_DR","% of Share held_Relcon_DS", "Manager Override_Relcon_DA", "SheetName"]],
            ['CMPL2_MCA_Looping', 'CMPL2_MCA_Looping', 'L', 'N', 'A:G',["duns_no", "Keyword_Entity_EG", "Update_Date_Extract Date_EJ", "ACTIVE_COMPLIANCE_EM","COMPANY_FILING_STATUS_16_17_18_JA", "Last AGM Date_CMPL 2_EL", "Balance Sheet_CMPL2_EK", "SheetName"]]
        ]
        df_NonFin = pd.DataFrame(dataAll,  columns=['Sheets', 'SheetName',  'Looping/NonLooping',  'Deletion',  'CellRange', 'ColumnList'])
        df_NonFin.set_index('Sheets',  inplace=True)

        # No Deletion or Non Looping
        general_non_loop_All = pd.DataFrame()
        Relcon_Parent_Non_Looping_All = pd.DataFrame()
        History_MCA_Non_Loop_All=pd.DataFrame()
        History_Non_Looping_All = pd.DataFrame()

        # Looping
        General_EXIM_Loop_All = pd.DataFrame()
        CMPL2_MCA_Looping_All = pd.DataFrame()
        Relcon_SUBS_Looping_All = pd.DataFrame()
        Relcon_AFFiliate_Looping_All = pd.DataFrame()
        History_Auditor_Loop_All = pd.DataFrame()
        History_Charge_details_Loop_All = pd.DataFrame()
        History_ROC_Add_Looping_All = pd.DataFrame()
        History_other_than_ROC_Add_Loop_All = pd.DataFrame()
        History_Looping_All = pd.DataFrame()
        History_Sh_Holding_Looping_All = pd.DataFrame()
        MGMT_Director_Sec_Loop_All = pd.DataFrame()
        MGMT_Other_Dir_Details_Loop_All = pd.DataFrame()
        # ==========================================================
        # Looping - Delete DataFrames
        General_EXIM_Loop_All_Delete = pd.DataFrame()
        # CMPL2_MCA_Looping_All_Delete = pd.DataFrame()
        Relcon_SUBS_Looping_All_Delete = pd.DataFrame()
        Relcon_AFFiliate_Looping_All_Delete = pd.DataFrame()
        History_Auditor_Loop_All_Delete = pd.DataFrame()
        History_Charge_details_Loop_All_Delete = pd.DataFrame()
        History_ROC_Add_Looping_All_Delete = pd.DataFrame()
        History_other_than_ROC_Add_Loop_All_Delete = pd.DataFrame()
        History_Looping_All_Delete = pd.DataFrame()
        History_Sh_Holding_Looping_All_Delete = pd.DataFrame()
        MGMT_Director_Sec_Loop_All_Delete = pd.DataFrame()
        # MGMT_Other_Dir_Details_loop_All_Delete = pd.DataFrame()

        try:
            logger.info("Process Started " + str(datetime.now().strftime('%d_%m_%Y %H_%M_%S')))

            Message,  AutoFinancialObj = self.sharepointoperation("Delete File",  "",  logger,  "")
            if (Message.find('CSV Files have been deleted') != -1):
                logger.info("Step 1 : CSV Files older than 7 days have been deleted")
            Message,  AutoFinancialObj = self.sharepointoperation("Download File",  "",  logger,  "")
            if (Message.find('Folder has been downloaded') != -1):
                logger.info("Step 1 : Folder has been downloaded from sharepoint")

            # Creating Dynamic Dictionay of dataframe
            for file in os.listdir(Inputdirectory):
                filename = Path(os.path.join(Inputdirectory,  file))
                filename1 = filename.name
                FileWithoutExtn = os.path.splitext(filename1)[0]
                try:
                    if not file.endswith(".xlsx"):
                        continue
                    logger.info("File In Process : " + filename1)

                    file_dict = {}
                    try:
                        # Creating dictionary of DataFrames Dynamically and key is the sheet name and value is dataframe
                        for (index,  colname) in df_NonFin.iterrows():
                            try:
                                key = colname['SheetName']
                                df = pd.read_excel(filename,  sheet_name=df_NonFin.at[index,  "SheetName"],
                                                   index_col=None,
                                                   na_values=['NA'],
                                                   usecols=df_NonFin.at[index,  "CellRange"])
                                                   # Added on 4th Oct 2022
                                                   # convert_float=False
                                if not df.empty:
                                    df['SheetName'] = colname['SheetName']
                                    file_dict[key] = df
                                else:
                                    Status = "File Not Processed"
                                    StatsList.append(
                                        ["", FileWithoutExtn, str(key), Status,
                                         str(today) + "_" + str(logtime),
                                         "Worksheet is Empty"])

                            except Exception as ex:
                                Status = 'File Not Processed'
                                StatsList.append(
                                    ["",  FileWithoutExtn,  str(colname['SheetName']),  Status,
                                     str(today) + "_" + str(logtime),
                                     str(ex)])
                                logger.error(filename)
                                # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                                logger.error(str(ex))
                                continue

                    except Exception as ex:
                        logger.error(str(ex))

                    # Key is the Sheet Name in the dictionary
                    for key in file_dict:
                        try:
                            # Check if Dataframe is empty
                            if not file_dict[key].empty:
                                SheetDataFrame = file_dict[key]
                                # df = self.ValidateDUNSNumber(SheetDataFrame,  logger)
                                name = SheetDataFrame
                                # SheetDataFrame.columns=[c.replace(':',  '_') for c in name.columns]
                                # SheetDataFrame.rename(columns={'DUNS_General:aa': 'duns_no'}, inplace=True)

                                if not name.empty:
                                    # name.replace({np.nan: None,'NaT':None,pd.NaT:None}, inplace=True)
                                    # name.columns = df_NonFin.at[name.at[0,  "SheetName"],  "ColumnList"]
                                    # =============================INSERT=========================================
                                    # GENERAL
                                    if (name.at[0,  "SheetName"] == 'general_non loop'):

                                        general_non_loop_All = pd.concat([general_non_loop_All, name], axis=0)
                                    elif (name.at[0,  "SheetName"] == 'General_EXIM_Loop'):
                                        General_EXIM_Loop_All = pd.concat([General_EXIM_Loop_All, name], axis=0)

                                    # CMPL2
                                    elif (name.at[0,  "SheetName"] == 'CMPL2_MCA_Looping'):
                                        CMPL2_MCA_Looping_All = pd.concat([CMPL2_MCA_Looping_All, name], axis=0)

                                    # RELCON
                                    elif (name.at[0,  "SheetName"] == 'Relcon_SUBS_Looping'):
                                        Relcon_SUBS_Looping_All = pd.concat([Relcon_SUBS_Looping_All, name], axis=0)
                                    elif (name.at[0,  "SheetName"] == 'Relcon_AFFiliate_Looping'):
                                        Relcon_AFFiliate_Looping_All = pd.concat([Relcon_AFFiliate_Looping_All, name], axis=0)
                                    elif (name.at[0,  "SheetName"] == 'Relcon_Parent_Non Looping'):
                                        Relcon_Parent_Non_Looping_All = pd.concat([Relcon_Parent_Non_Looping_All, name], axis=0)

                                    # HISTORY
                                    elif (name.at[0,  "SheetName"] == 'History_Auditor_Loop'):
                                        History_Auditor_Loop_All = pd.concat([History_Auditor_Loop_All, name], axis=0)
                                    elif (name.at[0,  "SheetName"] == 'History_Charge_details_Loop'):
                                        History_Charge_details_Loop_All =pd.concat([History_Charge_details_Loop_All, name], axis=0)
                                    elif (name.at[0,  "SheetName"] == 'History_MCA_Non Loop'):
                                        History_MCA_Non_Loop_All = pd.concat([History_MCA_Non_Loop_All, name], axis=0)
                                    elif (name.at[0,  "SheetName"] == 'History_ROC_Add_Looping'):
                                        History_ROC_Add_Looping_All = pd.concat([History_ROC_Add_Looping_All, name], axis=0)
                                    elif (name.at[0,  "SheetName"] == 'History_other than_ROC_Add_Loop'):
                                        History_other_than_ROC_Add_Loop_All = pd.concat([History_other_than_ROC_Add_Loop_All, name], axis=0)
                                    elif (name.at[0,  "SheetName"] == 'History_Non Looping'):
                                        History_Non_Looping_All = pd.concat([History_Non_Looping_All, name], axis=0)
                                    elif (name.at[0,  "SheetName"] == 'History_Looping'):
                                        History_Looping_All =pd.concat([History_Looping_All, name], axis=0)
                                    elif (name.at[0,  "SheetName"] == 'History_Sh Holding_Looping'):
                                        History_Sh_Holding_Looping_All = pd.concat([History_Sh_Holding_Looping_All, name], axis=0)

                                    # Management Section
                                    elif (name.at[0,  "SheetName"] == 'MGMT_Director_Sec_Loop'):
                                        MGMT_Director_Sec_Loop_All=pd.concat([MGMT_Director_Sec_Loop_All, name], axis=0)
                                    elif (name.at[0,  "SheetName"] == 'MGMT_Other_Dir_Details_Loop'):
                                        MGMT_Other_Dir_Details_Loop_All = pd.concat([MGMT_Other_Dir_Details_Loop_All, name], axis=0)

                                    Status = "File Processed"
                                    # StatsList.append(
                                    #     [name.at[0,  'DUNS_General_aa'],  FileWithoutExtn,  name.at[0,  "SheetName"],  Status,
                                    #      str(today) + "_" + str(logtime),
                                    #      "Data Available - Insert Data"])
                                    StatsList.append(
                                        [name.at[0, 'duns_no'], FileWithoutExtn, name.at[0, "SheetName"],
                                         Status,str(today) + "_" + str(logtime),"Data Available - Insert Data"])

                                    # ====================================DELETION LOGIC===============================================

                                    if (df_NonFin.at[name.at[0,  "SheetName"],  "Deletion"] == "Y"):
                                        # df_NonFin.at[name.at[0,  "SheetName"],  "Looping/NonLooping"] == "L" and
                                        # s = pd.DataFrame(name.DUNS_General_aa.unique(), columns=['DUNS_General_aa'])
                                        s = pd.DataFrame(name.duns_no.unique(), columns=['duns_no'])

                                        # GENERAL
                                        if (name.at[0,  "SheetName"] == 'General_EXIM_Loop'):
                                            General_EXIM_Loop_All_Delete = General_EXIM_Loop_All_Delete.append(s)

                                        # CMPL2
                                        # elif (name.at[0,  "SheetName"] == 'CMPL2_MCA_Looping'):
                                        #     CMPL2_MCA_Looping_All_Delete = CMPL2_MCA_Looping_All_Delete.append(s)

                                        # RELCON
                                        elif (name.at[0,  "SheetName"] == 'Relcon_SUBS_Looping'):
                                            Relcon_SUBS_Looping_All_Delete = Relcon_SUBS_Looping_All_Delete.append(s)
                                        elif (name.at[0,  "SheetName"] == 'Relcon_AFFiliate_Looping'):
                                            Relcon_AFFiliate_Looping_All_Delete = Relcon_AFFiliate_Looping_All_Delete.append(s)

                                        # HISTORY
                                        elif (name.at[0,  "SheetName"] == 'History_Auditor_Loop'):
                                            History_Auditor_Loop_All_Delete = History_Auditor_Loop_All_Delete.append(s)
                                        elif (name.at[0,  "SheetName"] == 'History_Charge_details_Loop'):
                                            History_Charge_details_Loop_All_Delete = History_Charge_details_Loop_All_Delete.append(s)
                                        elif (name.at[0,  "SheetName"] == 'History_ROC_Add_Looping'):
                                            History_ROC_Add_Looping_All_Delete = History_ROC_Add_Looping_All_Delete.append(s)
                                        elif (name.at[0,  "SheetName"] == 'History_other than_ROC_Add_Loop'):
                                            History_other_than_ROC_Add_Loop_All_Delete = History_other_than_ROC_Add_Loop_All_Delete.append(s)
                                        elif (name.at[0,  "SheetName"] == 'History_Looping'):
                                            History_Looping_All_Delete = History_Looping_All_Delete.append(s)
                                        elif (name.at[0,  "SheetName"] == 'History_Sh Holding_Looping'):
                                            History_Sh_Holding_Looping_All_Delete = History_Sh_Holding_Looping_All_Delete.append(s)

                                        # MANAGEMENT
                                        elif (name.at[0, "SheetName"] == 'MGMT_Director_Sec_Loop'):
                                            MGMT_Director_Sec_Loop_All_Delete = pd.concat([MGMT_Director_Sec_Loop_All_Delete, name],axis=0)
                                        # elif (name.at[0, "SheetName"] == 'MGMT_Other_Dir_Details_loop'):
                                        #     MGMT_Other_Dir_Details_loop_All_Delete = pd.concat([MGMT_Other_Dir_Details_loop_All_Delete, name], axis=0)

                                        Status = "File Processed"

                                        # StatsList.append(
                                        #     [name.at[0,  'DUNS_General_aa'],  FileWithoutExtn,
                                        #      name.at[0,  "SheetName"],
                                        #      Status,
                                        #      str(today) + "_" + str(logtime),
                                        #      "Data Available - Delete Data"])
                                        StatsList.append(
                                            [name.at[0, 'duns_no'], FileWithoutExtn,name.at[0, "SheetName"],
                                             Status,str(today) + "_" + str(logtime),"Data Available - Delete Data"])

                                # else:
                                #     Status = "File Processed"
                                #     StatsList.append(
                                #         ["",  FileWithoutExtn,  str(key),  Status,
                                #          str(today) + "_" + str(logtime),
                                #          "DUNS Number validation failed"])
                            else:
                                logger.info("{} worksheet is empty".format(str(key)))
                                Status = "File Processed"
                                StatsList.append(
                                    ["",  FileWithoutExtn,  str(key),  Status,
                                     str(today) + "_" + str(logtime),
                                     "No Data Found"])

                        except Exception as ex:
                            Status = 'File Not Processed'
                            StatsList.append(
                                ["",  FileWithoutExtn,  str(key),  Status,  str(today) + "_" + str(logtime),
                                 str(ex)])
                            logger.error(filename)
                            # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                            logger.error(str(ex))
                            continue

                    # Remove the Input file once processing is over
                    os.remove(os.path.join(Inputdirectory, file))
                except Exception as ex:
                    Status = 'File Not Processed'
                    StatsList.append(["",  FileWithoutExtn,  "",  Status,  str(today) + "_" + str(logtime),
                                      str(ex)])
                    logger.error(filename)
                    logger.error(str(ex))
                    continue
            # CSV Generation and Fields ID Insertion

            # -----------------------------------------------------------------------------------------------------------
            '''NON LOOPING CSV FILE GENERATION = 4 '''
            # -----------------------------------------------------------------------------------------------------------
            # Non Looping
            # ==========================================================

            if not general_non_loop_All.empty:
                # general_non_loop_All['general_et'] = general_non_loop_All['general_et'].fillna(0).astype(int)
                general_non_loop_All=general_non_loop_All.astype({'general_et': 'Int64', 'general_ev': 'Int64',
                                             'general_du':'Int64','general_dw':'Int64'},copy=False,errors='ignore')

                general_non_loop_All.to_csv(Outputdirectory + "general_non_loop_All_"+TokenDictGDONonFinUpload["general_non_loop_All"]+".csv",
                                    index=False)
            if not Relcon_Parent_Non_Looping_All.empty:
                Relcon_Parent_Non_Looping_All = Relcon_Parent_Non_Looping_All.\
                    astype({'Parent DUNS_Relcon_DE': 'Int64', 'Manager Override_Relcon_DA':'Int64','Postal Code_Relcon_DQ':'Int64'},errors='ignore')

                Relcon_Parent_Non_Looping_All.to_csv(Outputdirectory + "Relcon_Parent_Non_Looping_All_"+TokenDictGDONonFinUpload["Relcon_Parent_Non_Looping_All"]+".csv",
                                   index=False)
            if not History_MCA_Non_Loop_All.empty:
                History_MCA_Non_Loop_All.to_csv(Outputdirectory + "History_MCA_Non_Loop_All_"+TokenDictGDONonFinUpload["History_MCA_Non_Loop_All"]+".csv",
                                      index=False)
            if not History_Non_Looping_All.empty:

                History_Non_Looping_All.to_csv(Outputdirectory + "History_Non_Looping_All_"+TokenDictGDONonFinUpload["History_Non_Looping_All"]+".csv",
                                      index=False)

            # -----------------------------------------------------------------------------------------------------------
            '''LOOPING CSV FILE GENERATION INSERT = 12'''
            # -----------------------------------------------------------------------------------------------------------
            # # Looping
            if not General_EXIM_Loop_All.empty:

                self.UpdateFieldIDDataframes(General_EXIM_Loop_All,  logger)
                General_EXIM_Loop_All = General_EXIM_Loop_All.astype \
                    ({"Import(CIF Value)(in '000)_hl": 'Int64',
                      "Export(FOB Value)(in '000)_ho": 'Int64'},
                     errors='ignore')
                General_EXIM_Loop_All.to_csv(Outputdirectory + "General_EXIM_Loop_All_"+TokenDictGDONonFinUpload["General_EXIM_Loop_All"]+".csv",
                                         index=False)
            if not CMPL2_MCA_Looping_All.empty:
                self.UpdateFieldIDDataframes(CMPL2_MCA_Looping_All,  logger)
                CMPL2_MCA_Looping_All.to_csv(Outputdirectory + "CMPL2_MCA_Looping_All_"+TokenDictGDONonFinUpload["CMPL2_MCA_Looping_All"]+".csv",
                                         index=False)
            if not Relcon_SUBS_Looping_All.empty:
                self.UpdateFieldIDDataframes(Relcon_SUBS_Looping_All,  logger)
                Relcon_SUBS_Looping_All = Relcon_SUBS_Looping_All.astype({'DUNS_Relcon_CF': 'Int64',
                                                                          'Pincode_Subs_Relcon_CR':'Int64'},copy=False, errors='ignore')

                Relcon_SUBS_Looping_All.to_csv(
                    Outputdirectory + "Relcon_SUBS_Looping_All_"+TokenDictGDONonFinUpload["Relcon_SUBS_Looping_All"]+".csv",
                    index=False)
            if not Relcon_AFFiliate_Looping_All.empty:
                self.UpdateFieldIDDataframes(Relcon_AFFiliate_Looping_All,  logger)

                Relcon_AFFiliate_Looping_All = Relcon_AFFiliate_Looping_All.astype\
                    ({'Subject holds Shares in Affiliate (Tick Box)_Relcon_BW': 'Int64',
                      'Affiliate Duns__Relcon_BG':'Int64',
                      'Affiliate holds Shares in Subject (Tick Box)_Relcon_BX': 'Int64',
                      'Joint Venture (Tick)__Relcon_BF':'Int64',
                      'Pincode_Aff_Relcon_BS':'Int64'},
                     errors='ignore')
                Relcon_AFFiliate_Looping_All.to_csv(
                    Outputdirectory + "Relcon_AFFiliate_Looping_All_"+TokenDictGDONonFinUpload["Relcon_AFFiliate_Looping_All"]+".csv",
                    index=False)

            if not History_Auditor_Loop_All.empty:
                self.UpdateFieldIDDataframes(History_Auditor_Loop_All,  logger)
                History_Auditor_Loop_All.to_csv(Outputdirectory + "History_Auditor_Loop_All_"+TokenDictGDONonFinUpload["History_Auditor_Loop_All"]+".csv",
                                         index=False)
            if not History_Charge_details_Loop_All.empty:
                self.UpdateFieldIDDataframes(History_Charge_details_Loop_All,  logger)
                History_Charge_details_Loop_All = History_Charge_details_Loop_All.astype \
                    ({'Pincode_OJ': 'Int64'},
                     errors='ignore')

                History_Charge_details_Loop_All.to_csv(
                    Outputdirectory + "History_Charge_details_Loop_All_"+TokenDictGDONonFinUpload["History_Charge_details_Loop_All"]+".csv",
                    index=False)
            if not History_ROC_Add_Looping_All.empty:
                self.UpdateFieldIDDataframes(History_ROC_Add_Looping_All,  logger)
                History_ROC_Add_Looping_All = History_ROC_Add_Looping_All.astype \
                    ({'Pincode_jr': 'Int64'},
                     errors='ignore')
                History_ROC_Add_Looping_All.to_csv(
                    Outputdirectory + "History_ROC_Add_Looping_All_"+TokenDictGDONonFinUpload["History_ROC_Add_Looping_All"]+".csv",
                    index=False)
            if not History_other_than_ROC_Add_Loop_All.empty:
                self.UpdateFieldIDDataframes(History_other_than_ROC_Add_Loop_All,  logger)
                History_other_than_ROC_Add_Loop_All = History_other_than_ROC_Add_Loop_All.astype \
                    ({'Pincode_AH': 'Int64'},
                     errors='ignore')
                History_other_than_ROC_Add_Loop_All.to_csv(Outputdirectory + "History_other_than_ROC_Add_Loop_All_"+TokenDictGDONonFinUpload["History_other_than_ROC_Add_Loop_All"]+".csv",
                                         index=False)
            if not History_Looping_All.empty:
                self.UpdateFieldIDDataframes(History_Looping_All,  logger)
                History_Looping_All.to_csv(Outputdirectory + "History_Looping_All_"+TokenDictGDONonFinUpload["History_Looping_All"]+".csv",
                                         index=False)
            if not History_Sh_Holding_Looping_All.empty:
                self.UpdateFieldIDDataframes(History_Sh_Holding_Looping_All, logger)
                History_Sh_Holding_Looping_All=self.validatefields(History_Sh_Holding_Looping_All, logger)
                History_Sh_Holding_Looping_All = History_Sh_Holding_Looping_All.astype \
                    ({'Shareholder Duns_history_IH': 'Int64'},
                     errors='ignore')
                # 'Identity Number_History_IK': 'Int64'
                # df['Identity Number_History_IK'] = df['Identity Number_History_IK'].astype('Int64').apply(lambda x: '{0:0>8}'.format(x))
                History_Sh_Holding_Looping_All.to_csv(
                    Outputdirectory + "History_Sh_Holding_Looping_All_"+TokenDictGDONonFinUpload["History_Sh_Holding_Looping_All"]+".csv",
                    index=False)

            if not MGMT_Director_Sec_Loop_All.empty:
                self.UpdateFieldIDDataframes(MGMT_Director_Sec_Loop_All,  logger)
                MGMT_Director_Sec_Loop_All.to_csv(Outputdirectory + "MGMT_Director_Sec_Loop_All_"+TokenDictGDONonFinUpload["MGMT_Director_Sec_Loop_All"]+".csv",
                                         index=False)
            if not MGMT_Other_Dir_Details_Loop_All.empty:
                self.UpdateFieldIDDataframes(MGMT_Other_Dir_Details_Loop_All,logger)
                MGMT_Other_Dir_Details_Loop_All.to_csv(
                    Outputdirectory + "MGMT_Other_Dir_Details_Loop_All_"+TokenDictGDONonFinUpload["MGMT_Other_Dir_Details_Loop_All"]+".csv",
                    index=False)
            #----------------------------------------------------------------------------------------
            '''DELETE SECTION = 12'''
            # ----------------------------------------------------------------------------------------
            # Deletion Looping

            if not General_EXIM_Loop_All_Delete.empty:
                General_EXIM_Loop_All_Delete.to_csv(Outputdirectory+"General_EXIM_Loop_All_Delete_"+TokenDictGDONonFinUpload["General_EXIM_Loop_All_Delete"]+".csv")
            # if not CMPL2_MCA_Looping_All_Delete.empty:
            #     CMPL2_MCA_Looping_All_Delete.to_csv(Outputdirectory+"CMPL2_MCA_Looping_All_Delete_"+TokenDictGDONonFinUpload["CMPL2_MCA_Looping_All_Delete"]+".csv")
            if not Relcon_SUBS_Looping_All_Delete.empty:
                Relcon_SUBS_Looping_All_Delete.to_csv(Outputdirectory + "Relcon_SUBS_Looping_All_Delete_"+TokenDictGDONonFinUpload["Relcon_SUBS_Looping_All_Delete"]+".csv")
            if not Relcon_AFFiliate_Looping_All_Delete.empty:
                Relcon_AFFiliate_Looping_All_Delete.to_csv(Outputdirectory +"Relcon_AFFiliate_Looping_All_Delete_"+TokenDictGDONonFinUpload["Relcon_AFFiliate_Looping_All_Delete"]+".csv")
            if not History_Auditor_Loop_All_Delete.empty:
                History_Auditor_Loop_All_Delete.to_csv(Outputdirectory + "History_Auditor_Loop_All_Delete_"+TokenDictGDONonFinUpload["History_Auditor_Loop_All_Delete"]+".csv")
            if not History_Charge_details_Loop_All_Delete.empty:
                History_Charge_details_Loop_All_Delete.to_csv(Outputdirectory + "History_Charge_details_Loop_All_Delete_"+TokenDictGDONonFinUpload["History_Charge_details_Loop_All_Delete"]+".csv")
            if not History_ROC_Add_Looping_All_Delete.empty:
                History_ROC_Add_Looping_All_Delete.to_csv(Outputdirectory + "History_ROC_Add_Looping_All_Delete_"+TokenDictGDONonFinUpload["History_ROC_Add_Looping_All_Delete"]+".csv")
            if not History_other_than_ROC_Add_Loop_All_Delete.empty:
                History_other_than_ROC_Add_Loop_All_Delete.to_csv(Outputdirectory + "History_other_than_ROC_Add_Loop_All_Delete_"+TokenDictGDONonFinUpload["History_other_than_ROC_Add_Loop_All_Delete"]+".csv")
            if not History_Looping_All_Delete.empty:
                History_Looping_All_Delete.to_csv(Outputdirectory + "History_Looping_All_Delete_"+TokenDictGDONonFinUpload["History_Looping_All_Delete"]+".csv")
            if not History_Sh_Holding_Looping_All_Delete.empty:
                History_Sh_Holding_Looping_All_Delete.to_csv(Outputdirectory + "History_Sh_Holding_Looping_All_Delete_"+TokenDictGDONonFinUpload["History_Sh_Holding_Looping_All_Delete"]+".csv")
            if not MGMT_Director_Sec_Loop_All_Delete.empty:
                MGMT_Director_Sec_Loop_All_Delete.to_csv(Outputdirectory + "MGMT_Director_Sec_Loop_All_Delete_"+TokenDictGDONonFinUpload["MGMT_Director_Sec_Loop_All_Delete"]+".csv",
                                         index=False)
            # if not MGMT_Other_Dir_Details_loop_All_Delete.empty:
            #     MGMT_Other_Dir_Details_loop_All_Delete.to_csv(
            #         Outputdirectory + "MGMT_Other_Dir_Details_loop_All_Delete_"+TokenDictGDONonFinUpload["MGMT_Other_Dir_Details_loop_All_Delete"]+".csv",
            #         index=False)
            # Upload CSV Files to Sharepoint
            MessageUploadOutput = self.sharepointoperation("Upload File", Outputdirectory + "",
                 logger, "CSV")
            if (MessageUploadOutput == "File uploaded"):
                logger.info("CSV files have been uploaded to sharepoint")

            # Upload files to FTP

            cnopts = pysftp.CnOpts()
            cnopts.hostkeys = paramiko.hostkeys.HostKeys(sftpauth["sftphostkey"])
            hostName=ftp["hostName"]
            # hostName = "ftp.dnb.com"
            # userName = "BLT356_tes"
            userName = ftp["userName"]
            pswd = ftp["pswd"]
            # pswd = "DUNS@1b2c3z"

            try:
                with pysftp.Connection(host=hostName,  username=userName,
                                       password=pswd,  cnopts=cnopts) as sftp:
                    try:
                        logger.info("Connection established ... ")

                        with sftp.cd("/puts/"):
                            # print(sftp.listdir())
                            try:
                                # # Use put method to upload a file
                                # First trasfer all delete files
                                for file in os.listdir(Outputdirectory):
                                    try:
                                        if not file.endswith(".csv"):
                                            continue
                                        if 'Delete' in file:
                                            time.sleep(5)
                                            sftp.put(os.path.join(Outputdirectory,  file),  confirm=False)
                                            # ,  confirm = False
                                            FTPStats.append(
                                                [file,  "FTP Transfer Successfull",  str(today) + "_" + str(logtime),
                                                 "No Remarks"])
                                            time.sleep(3)
                                            os.remove(os.path.join(Outputdirectory,  file))
                                    except Exception as ex:
                                        logger.error(str(ex))
                                        FTPStats.append(
                                            [file,  "FTP Transfer Failed",  str(today) + "_" + str(logtime),
                                             str(ex)])
                                        continue
                                time.sleep(120)
                                # second trasfer all Insert files
                                list_of_files = sorted(filter(lambda x: os.path.isfile(os.path.join(Outputdirectory, x)),
                                                              os.listdir(Outputdirectory)))
                                for file in list_of_files:
                                    try:

                                        if not file.endswith(".csv"):
                                            continue
                                        if 'Delete' not in file:
                                            # if "MGMT_Director_Sec_Loop" not in file:
                                            #     time.sleep(5)
                                            # elif "MGMT_Director_Sec_Loop" in file:
                                            #     time.sleep(20)
                                            # and 'MGMT_Other_Dir_Details_Loop_All' not in file
                                            time.sleep(5)
                                            sftp.put(os.path.join(Outputdirectory,  file),  confirm=False)
                                            time.sleep(20)
                                            # ,  confirm = False
                                            FTPStats.append(
                                                [file,  "FTP Transfer Successfull",  str(today) + "_" + str(logtime),
                                                 "No Remarks"])
                                            os.remove(os.path.join(Outputdirectory,  file))
                                    except Exception as ex:
                                        logger.error(str(ex))
                                        FTPStats.append(
                                            [file,  "FTP Transfer Failed",  str(today) + "_" + str(logtime),
                                             str(ex)])
                                        continue

                            except Exception as ex:
                                logger.error(str(ex))
                    except Exception as ex:

                        logger.error(str(ex))
                        FTPStats.append(
                            [file,  "FTP Transfer Failed",  str(today) + "_" + str(logtime),
                             str(ex)])

            except Exception as ex:
                logger.error("Connection Not established ... ")
                logger.error(str(ex))
                FTPStats.append(
                    ["Connection Not established ...",  "FTP Transfer Failed",  str(today) + "_" + str(logtime),
                     str(ex)])

            # Load stats file
            self.CreateStats(logger,  AutoFinancialObj,  StatsList, FTPStats)

        except Exception as ex:
            logger.error(str(ex))

    def CreateStats(self, logger, AutoFinancialObj, StatsList, FTPList):

        global Stats, FTPStatdf
        # global FTPStatdf
        FTPStatdf = pd.DataFrame()

        Stats = pd.DataFrame()
        Outputdirectory = OutPutFilesGDONonFinUpload["OutPutFilesGDONonFinUpload"]
        try:
            book = load_workbook(Outputdirectory + 'GDONonFinUpload_Stats.xlsx')
            DFSharepointFolderStatus = pd.concat([AutoFinancialObj.DFSharepointFolderDetails])
            DFSharepointFolderStatus.columns = ['Folder Name',  'File Count',  'Folder Status',  'ProcessedDateTime',
                                                'File download Count']
            Stats = Stats.append(pd.DataFrame(StatsList,  columns=['DUNS Number',  'File Name',  'WorkSheet Name',  'Status',
                                                                  'Processed Date',  'Remarks']),  ignore_index=True)
            FTPStatdf = FTPStatdf.append(
                pd.DataFrame(FTPList,  columns=['File Name',  'Status',  'Processed Date',  'Remarks']),  ignore_index=True)

            writer = pd.ExcelWriter(Outputdirectory + 'GDONonFinUpload_Stats.xlsx',
                                    engine='openpyxl')
            writer.book = book
            writer.sheets = {ws.title: ws for ws in book.worksheets}

            with writer:
                Stats.to_excel(writer,  sheet_name='CSV File log',
                               startrow=writer.sheets['CSV File log'].max_row,
                               index=False,  header=False)
                FTPStatdf.to_excel(writer,  sheet_name='FTP Stats',
                                   startrow=writer.sheets['FTP Stats'].max_row,
                                   index=False,  header=False)
                DFSharepointFolderStatus.to_excel(writer,  sheet_name='SharePoint Folder Stats',
                                                  startrow=writer.sheets['SharePoint Folder Stats'].max_row,
                                                  index=False,  header=False)

            book.save(Outputdirectory + 'GDONonFinUpload_Stats.xlsx')
            book.save(Outputdirectory + 'GDONonFinUpload_Stats_' + str(today) + '.xlsx')

            # Filtering Todays for Sharepoint Upload

            File_Stats_Today = pd.read_excel(Outputdirectory + 'GDONonFinUpload_Stats_' + str(today) + '.xlsx',
                sheet_name='CSV File log',  engine='openpyxl')
            if not File_Stats_Today.empty:
                File_Stats_Today = File_Stats_Today.dropna()
                File_Stats_Today = File_Stats_Today.loc[
                    File_Stats_Today['Processed Date'].str.contains(r'^{}*'.format(str(today)),  regex=True)]

            Folder_Stats_Today = pd.read_excel(Outputdirectory + 'GDONonFinUpload_Stats_' + str(today) + '.xlsx',
                sheet_name='SharePoint Folder Stats',  engine='openpyxl')
            if not Folder_Stats_Today.empty:
                Folder_Stats_Today=Folder_Stats_Today.dropna()
                Folder_Stats_Today = Folder_Stats_Today.loc[
                    Folder_Stats_Today['ProcessedDateTime'].str.contains(r'^{}*'.format(str(today)),  regex=True)]

            FTP_Stats_Today = pd.read_excel(
                Outputdirectory + 'GDONonFinUpload_Stats_' + str(today) + '.xlsx',
                sheet_name='FTP Stats',  engine='openpyxl')
            if not Folder_Stats_Today.empty:
                FTP_Stats_Today=FTP_Stats_Today.dropna()
                FTP_Stats_Today = FTP_Stats_Today.loc[
                    FTP_Stats_Today['Processed Date'].str.contains(r'^{}*'.format(str(today)),  regex=True)]

            with pd.ExcelWriter(
                    Outputdirectory + 'GDONonFinUpload_Stats_' + str(today) + '.xlsx',
                    engine='xlsxwriter') as writer:
                File_Stats_Today.to_excel(writer,  sheet_name='CSV File log',  index=False)
                Folder_Stats_Today.to_excel(writer,  sheet_name='SharePoint Folder Stats',  index=False)
                FTP_Stats_Today.to_excel(writer,  sheet_name='FTP Stats',  index=False)
            book.save(Outputdirectory + 'GDONonFinUpload_Stats_' + str(today) + '.xlsx')
            MessageUploadOutput = self.sharepointoperation("Upload File", Outputdirectory + 'GDONonFinUpload_Stats_' + str(
                                                               today) + '.xlsx',
                                                           logger,  "LOGS")
            if (MessageUploadOutput == "File uploaded"):
                logger.info("Output file has been uploaded to sharepoint")
                os.remove(os.path.join(Outputdirectory,
                                       'GDONonFinUpload_Stats_' + str(today) + '.xlsx'))

        except Exception as ex:
            logger.error("Stats Error")
            logger.error(str(ex))

def main():
    # Defining Variables
    global logtime,  today

    # Object creation for Logging module and Email class
    loggerObj = Logs()
    mailobj = mail()

    # Define time to set in the log file name
    logtime = str(datetime.now().strftime('%H_%M_%S'))
    today = date.today().strftime('%d_%m_%Y')

    # define the file name
    logfilename = "NonFinLogs_" + str(today) + ".txt"
    LogStatsPath =settings_ReportToDews.get(
        'team_site_url') + '/Shared%20Documents/GDO/Logs_Stats/NonFinancialUploadLogs/'
    LogPath = settings_ReportToDews.get(
        'team_site_url') + '/Shared%20Documents/GDO/Logs_Stats/NonFinancialUploadLogs/'
    logger = loggerObj.setup_logger('NonFinLogs_',  LogFileGDONonFinUpload["LogFileGDONonFinUpload"] + logfilename)
    try:

        logger.info("*********************************START*****************************************************")
        Obj1 = NonFinAutoUpload()
        ProcessStartTime = time.time()
        Obj1.autofinnonfin(logger)
        ProcessEndTime = time.time()
        TotalElapsedTime = time.strftime("%H:%M:%S %Z",  time.gmtime(ProcessEndTime - ProcessStartTime))

        if not Stats.empty:
            DataFound = [0]
            DataNotFound = [0]
            df = Stats["Status"].value_counts()
            try:
                DataFound = [df.at['File Processed']]
            except Exception as ex:
                if str(ex) == "File Not Processed":
                    DataFound = [0]
            try:
                DataNotFound = [df.at['File Not Processed']]
            except Exception as ex:
                if str(ex.args).strip() == '(\'File Not Processed\', )':
                    DataNotFound = [0]
            try:
                details = {
                    "Total Files Run": [Stats.shape[0]],
                    "Success Files": DataFound,
                    "Failed or Empty Files": DataNotFound,
                    "Processed DateTime": [date.today().strftime('%d_%m_%Y')],
                    "Run By": 'Auto Trigger Process',
                    "Total Execution Time": str(TotalElapsedTime)
                }
            except Exception as ex:
                details = {
                    "Total Files Run": [Stats.shape[0]],
                    "Success Files": DataFound,
                    "Failed or Empty Files": DataNotFound,
                    "Processed DateTime": [date.today().strftime('%d_%m_%Y')],
                    "Run By": 'Auto Trigger Process',
                    "Total Execution Time": str(TotalElapsedTime)
                }
        #
        #     # creating a Dataframe object with skipping
            df_stats = pd.DataFrame(details)
            output = build_table(df_stats,  'orange_light',  font_size='15px',  text_align='center',  width='auto', font_family='Open Sans, sans-serif')

        #     # send email only if files have failed in conversion
            if (DataNotFound != [0]):
                mailobj.SendEmailToStakeHolders("Non Fin Upload Automation Status-Failed ",  "DNBSystemMailDoNotReply@dnb.com",
                                                emailreceipient["emailreceipient"],  output,  "Non Fin Upload Automation",  LogStatsPath)

        # Send email if FTP Transfer failes

        if not FTPStatdf.empty:
            DataFound = [0]
            DataNotFound = [0]
            df = FTPStatdf["Status"].value_counts()
            try:
                DataFound = [df.at['FTP Transfer Successfull']]
            except KeyError as ex:
                logger.error("KeyError"+str(ex))
                DataFound = [0]
            except Exception as ex:
                logger.error(str(ex))
                DataFound = [0]
            try:
                DataNotFound = [df.at['FTP Transfer Failed']]
            except Exception as ex:
                if str(ex.args).strip() == '(\'FTP Transfer Failed\', )':
                    DataNotFound = [0]

            try:
                detailsFTP = {
                    "Total Files Run": [FTPStatdf.shape[0]],
                    "Success Files": DataFound,
                    "Failed Files": DataNotFound,
                    "Processed DateTime": [date.today().strftime('%d_%m_%Y')],
                    "Run By": 'Auto Trigger Process',
                    "Total Execution Time": str(TotalElapsedTime)
                }
            except Exception as ex:
                detailsFTP = {
                    "Total Files Run": [FTPStatdf.shape[0]],
                    "Success Files": DataFound,
                    "Failed Files": DataNotFound,
                    "Processed DateTime": [date.today().strftime('%d_%m_%Y')],
                    "Run By": 'Auto Trigger Process',
                    "Total Execution Time": str(TotalElapsedTime)
                }

            # creating a Dataframe object with skipping
            # one column i.e skipping age column.
            df_ftpstats = pd.DataFrame(detailsFTP)

            output = build_table(df_ftpstats,  'orange_light',  font_size='15px',  text_align='center',  width='auto',
                                 font_family='Open Sans, sans-serif')
            # send email only if files have failed in conversion
            if (DataNotFound != [0]):
                mailobj.SendEmailToStakeHolders("Non Fin Upload Automation Status - Failed FTP Transfer",
                                                "DNBSystemMailDoNotReply@dnb.com",
                                                "shethd@dnb.com",  output,  "Non Fin Upload Automation - FTP Transfer Failed",  LogStatsPath)

        logger.info(f"{TotalElapsedTime} seconds to process and upload all Non Fin files")
        MessageUploadLog = Obj1.sharepointoperation("Upload File",
                                                    LogFileGDONonFinUpload["LogFileGDONonFinUpload"] + logfilename,
                                                    logger,  "LOGS")

        if (MessageUploadLog == "File uploaded"):
            logger.info("log file has been uploaded to sharepoint")

        logger.info("**********************************END****************************************************")

    except Exception as ex:
        logger.error(str(ex))
        mailobj.SendEmailToStakeHolders("Non Fin Upload Automation Status ERROR ",  "DNBSystemMailDoNotReply@dnb.com",
                                        "Shethd@dnb.com",  str(ex),  "Non Fin Upload Automation Status",  LogPath)

if __name__ == '__main__':
    main()
    quit()