import logging
import os
import traceback
import openpyxl
import pandas as pd
import paramiko
import pysftp as pysftp
from SetLogger import Logs
from office365.runtime.auth.client_credential import ClientCredential
from office365.sharepoint.client_context import ClientContext
from datetime import date,datetime,timedelta
import time
from datetime import date
from SendEmail import SendEmail as mail
from DatabaseConfigFile import *
from SharepointSettings import settings_ReportToDews
import pyodbc
from pathlib import Path
from openpyxl import load_workbook
from pretty_html_table import build_table
import pysftp

class AutoFinancial:

    def ManageSQLConnection(self,df,logger,Action):

        try:

            sql_conn = pyodbc.connect(
                'DRIVER='+ mysql["DRIVER"] + ';SERVER='+ mysql["SERVER"] +
                ';DATABASE='+ mysql["DATABASE"] + ';UID='+ mysql["UID"] + ';PWD='+ mysql[
                    "PWD"] + '')
            cursor = sql_conn.cursor()
            cursor.fast_executemany = True

            sql_query = pd.read_sql_query(
                "SELECT * FROM [fileparser_inhousejobs] WHERE JobName='" + str(
                    AutoFinUploadJob["Job"]) + "'",
                sql_conn)

            JobID = sql_query['id']
            MY_TABLE = 'fileparser_jobhistory'
            df["JobID"] = JobID[0]
            if Action == "Insert":
                insert_to_tbl_stmt = "INSERT INTO [fileparser_jobhistory] (RunBy,OutputFilePath,LogPath,RunDuration,JobID_id,JobStatus) VALUES ('%s','%s','%s','%s',%s,'%s')" % (
                df["RunBy"][0],df["OutputFilePath"][0],df["LogPath"][0],df["RunDuration"][0],df["JobID"][0],
                str(df["JobStatus"][0]))
                # insert_to_tbl_stmt='''INSERT INTO {MY_TABLE} ('RunBy','OutputFilePath','LogPath','RunDuration','JobID') VALUES (?,?,?,?,?) '''
                # insert_to_tmp_tbl_stmt = f"INSERT INTO {MY_TABLE} ('RunBy','OutputFilePath','LogPath','RunDuration','JobID') VALUES (?,?,?,?,?)"
                cursor.execute(insert_to_tbl_stmt)
                print(f'{len(df)} rows inserted to the {MY_TABLE} table')
            else:
                sql_query1 = pd.read_sql_query(
                    "SELECT TOP 1 * FROM [fileparser_jobhistory] ORDER BY id DESC",
                    sql_conn)
                JobHistoryID = sql_query1['id']
                # "Update [fileparser_jobhistory] set RunBy = ?,OutputFilePath= ?,LogPath= ?,RunDuration= ?,JobID_id= ?,JobStatus= ? where id = ?" %(df["RunBy"][0],df["OutputFilePath"][0],df["LogPath"][0],df["RunDuration"][0],df["JobID"][0],str(df["JobStatus"][0]))
                update_to_tbl_stmt = "Update [fileparser_jobhistory] set RunBy = '%s'," \
                                     "OutputFilePath= '%s'," \
                                     "LogPath= '%s',RunDuration='%s'," \
                                     "JobID_id= '%s',JobStatus= '%s'where id = '%s'" % (
                                     str(df["RunBy"][1]),str(df["OutputFilePath"][1]),str(df["LogPath"][1]),
                                     str(df["RunDuration"][1]),str(df["JobID"][1]),str(df["JobStatus"][1]),
                                     str(JobHistoryID[0]))
                # insert_to_tbl_stmt='''INSERT INTO {MY_TABLE} ('RunBy','OutputFilePath','LogPath','RunDuration','JobID') VALUES (?,?,?,?,?) '''
                # insert_to_tmp_tbl_stmt = f"INSERT INTO {MY_TABLE} ('RunBy','OutputFilePath','LogPath','RunDuration','JobID') VALUES (?,?,?,?,?)"
                cursor.execute(update_to_tbl_stmt)
                sql_conn.commit()
                print(f'{len(df)} rows updated to the {MY_TABLE} table')
            cursor.commit()
            cursor.close()
            sql_conn.close()

        except Exception as ex:
            logger.error("SQL Error")
            logger.error(str(ex))

    def __init__(self):
        self.DFSharepointFolderDetails = pd.DataFrame(
            columns=['Folder Name','File Count','Folder Status','ProcessedDateTime'])

    def findInDict(self,needle,haystack):
        for key in haystack.keys():
            try:
                value = haystack[key]
            except:
                continue
            if key == needle:
                return value
            if isinstance(value,dict):
                x = self.findInDict(needle,value)
                if x is not None:
                    return x

    def SharepointOperation(self,action,file,logger,fileType):

        SharepointFolderDetails = []
        AutoFinancialObj = AutoFinancial()
        try:

            ctx = ClientContext(settings_ReportToDews.get('team_site_url')).with_credentials(
                ClientCredential(settings_ReportToDews['client_credentials']['client_id'],
                                 settings_ReportToDews['client_credentials']['client_secret']))

            if (action == "Upload File"):
                if (fileType=="LOGSorSTATS"):

                    path = file
                    folder_url = '/Shared Documents/CCAM/Logs_Stats/'
                    with open(path, 'rb') as content_file:
                        file_content = content_file.read()
                    target_folder = ctx.web.get_folder_by_server_relative_url(folder_url)
                    name = os.path.basename(path)
                    target_folder.upload_file(name, file_content)
                    ctx.execute_query()

                elif (fileType=="CSV"):

                    folder_url = '/Shared Documents/CCAM/ProcessedFinCSVFiles/'
                    for file in os.listdir(OutPutFileFinancial["OutPutFileFinancial"]):
                        try:
                            if not file.endswith(".csv"):
                                continue
                            target_folder = ctx.web.get_folder_by_server_relative_url(folder_url)
                            path = os.path.join(OutPutFileFinancial["OutPutFileFinancial"],file)
                            name = os.path.basename(os.path.join(OutPutFileFinancial["OutPutFileFinancial"],file))
                            with open(path, 'rb') as content_file:
                                file_content = content_file.read()
                            target_folder.upload_file(name, file_content)
                            ctx.execute_query()
                            return "File uploaded"
                        except Exception as ex:
                            logger.error("Could not upload the file to csv")
                            return "File Not uploaded"

            elif (action == "Download File"):

                try:
                    folders = 0
                    t0 = time.time()
                    try:
                        folder_url = '/Shared Documents/CCAM/VendorList/'
                        folders = ctx.web.get_folder_by_server_relative_url(folder_url).folders

                        ctx.load(folders)
                        ctx.execute_query()
                        FileListCount = []
                        # len(folders)
                        for folder,i in zip(folders,range(0,len(folders))):
                            try:
                                t0 = time.time()
                                FileCoun = 0

                                FolderName = str(folder.properties["Name"])
                                files = ctx.web.get_folder_by_server_relative_url(
                                    folder_url + FolderName+"/Input_Files/").files
                                if FolderName == "Logs_Stats" \
                                or FolderName == "Vaishnavi" \
                                or FolderName == "InputNonFinancialExcel":
                                    continue
                                # files = folder.files
                                ctx.load(files)
                                ctx.execute_query()
                                if (len(files) > 0):
                                    List = [FolderName,len(files),"File Available",str(today)+"_"+str(logtime)]
                                else:
                                    List = [FolderName,len(files),"Folder Empty",str(today)+"_"+str(logtime)]
                                SharepointFolderDetails.append(List)

                                AutoFinancialObj.DFSharepointFolderDetails.loc[
                                    len(AutoFinancialObj.DFSharepointFolderDetails)] = List
                                for cur_file,i in zip(files,range(0,len(files))):

                                    if 'Financial'in (str(cur_file.properties["Name"])) :
                                        FileCoun = FileCoun + 1

                                        download_FileName = os.path.join(InPutFilesFinancial[
                                                                             "InPutFilesFinancial"],
                                                                          FolderName + "_" + os.path.basename(
                                                                             cur_file.properties["Name"]))
                                        file_url = '/sites/ReportToDews/Shared Documents/CCAM/VendorList/'+FolderName+"/Input_Files/"+os.path.basename(
                                                                             cur_file.properties["Name"])

                                        with open(download_FileName,"wb") as local_file:
                                            file  = ctx.web.get_file_by_server_relative_url(file_url).download(
                                                local_file).execute_query()

                                        logger.info("File name: {0}".format(
                                            str(FolderName + "_" + cur_file.properties["Name"])))
                                        # file.delete_object()
                                        # ctx.execute_query()
                                FileListCount.append(FileCoun)
                            except Exception as ex:
                                logger.error(str(ex) + traceback.format_exc())
                                continue

                    except Exception as ex:
                        logger.error(str(ex) + traceback.format_exc())

                    if len(folders) != 0:
                        t1 = time.time()
                        Series = pd.Series(FileListCount)
                        AutoFinancialObj.DFSharepointFolderDetails["FileCount"] = Series
                        elapsed = time.strftime("%H:%M:%S %Z",time.gmtime(t1 - t0))

                        logger.info("Folder has been downloaded")
                        logger.info("Total time to download the files is " + str(elapsed))
                        return "Folder has been downloaded",AutoFinancialObj
                    else:
                        logger.info("No folders to download")
                        return "Folder has not been downloaded",AutoFinancialObj

                except Exception as ex:
                    logger.error(str(ex) + traceback.format_exc())
                    logger.error(str(folder.properties["Name"]) + "Folder has not been downloaded")
                    return "Folder has not been downloaded",AutoFinancialObj

            elif (action == "Delete File"):
                try:
                    folder_url = '/Shared Documents/CCAM/ProcessedFinCSVFiles/'
                    files = ctx.web.get_folder_by_server_relative_url(folder_url).files

                    ctx.load(files)
                    ctx.execute_query()
                    FileListCount = []
                    # len(folders)
                    for file, i in zip(files, range(0, len(files))):
                        try:
                            TimeCreated = (str(file.properties['TimeCreated']).split('T')[0])
                            TimeCreated = datetime.strptime(TimeCreated, '%Y-%m-%d')
                            YesterdayDate =datetime.strptime(Yesterday["Yesterday"], '%Y-%m-%d')
                            if TimeCreated==YesterdayDate:
                                file.delete_object()
                                ctx.execute_query()
                                logger.info("CSV File was deleted")
                            # FileListCount.append(FileCoun)
                        except Exception as ex:
                            logger.error(str(ex) + traceback.format_exc())
                            continue

                    return "CSV Files have been deleted", AutoFinancialObj

                except Exception as ex:
                    logger.error(str(ex) + traceback.format_exc())

        except Exception as ex:
            logger.error(str(ex) + traceback.format_exc())

    def AutoFinancialProcess(self,logger):
        Inputdirectory = InPutFilesFinancial["InPutFilesFinancial"]
        Outputdirectory = OutPutFileFinancial["OutPutFileFinancial"]
        StatsList = []
        FTPStats = []
        global Stats
        Stats = pd.DataFrame()
        # BS,PL,Fiscal,CashFlow
        dfBSAll = pd.DataFrame()
        dfPLAll = pd.DataFrame()
        dfFiscalAll = pd.DataFrame()
        dfCashflowAll = pd.DataFrame()
        try:
            logger.info("Process Started " + str(datetime.now().strftime('%d_%m_%Y %H_%M_%S')))
            logger.info("***********************************************************")
            logger.info("Process Started ")
            # Message, AutoFinancialObj = self.SharepointOperation("Delete File", "", logger, "")
            # if (Message.find('CSV Files have been deleted') != -1):
            #     logger.info("Step 1 : Folder has been downloaded from sharepoint")
            Message,AutoFinancialObj = self.SharepointOperation("Download File","",logger,"")
            if (Message.find('Folder has been downloaded') != -1):
                logger.info("Step 1 : Folder has been downloaded from sharepoint")

            # loop through the input directory
            for file in os.listdir(Inputdirectory):
                t0 = time.time()
                filename = Path(os.path.join(Inputdirectory, file))
                filename1 = filename.name
                FileWithoutExtn = os.path.splitext(filename1)[0]
                duns_number=""
                elapsed=""
                duns_number_len = 0
                try:
                    wb = openpyxl.load_workbook(filename)
                    try:
                        worksheet = wb.get_sheet_by_name("Detailed BS")
                        cell_obj = worksheet.cell(row=4, column=5)
                        duns_number = cell_obj.value
                        duns_number_len = len(duns_number)
                    except Exception as ex:
                        logger.error(str(ex))
                        Status = "File Not Processed"
                        StatsList.append(
                            ["No Duns Number Found", FileWithoutExtn, "Detailed BS Worksheet error", Status, str(today) + "_" + str(logtime),
                             str(ex)])
                        continue
                    # Date Validations

                    # Number validations
                    if (str(duns_number)!='0') and (str(duns_number)!='') and duns_number_len==9:
                        '''Read BS Data'''
                        try:
                            df_BS = pd.read_excel(filename,sheet_name='BS-UPLOAD',index_col=None,na_values=['NA'],usecols="G:I",nrows=229)
                            df_BS.columns = ['col1','col2','col3']
                            df1_transposed_BS = df_BS.T
                            df1_transposed_BS.columns = ['duns_no','Currency Type','Units of Size','Statement (End) Date','Equity Share Capital','Preference Capital','Share Capital','Employee Stock Option ','Share Forfeiture Account','Share Warrants','Capital Reserve',	'General Reserve',	'Legal Reserve',	'Specific Reserve',	'Contingency Reserve',	'Capital Redemption Reserve',	'Debenture Redemption Reserve',	'Bond Redemption Reserve',	'Revaluation Reserve',	'Surplus \ [Deficit]','Amalgamation Reserve','Debt Redemption Reserve','Securities Premium Account','Capital Grants & Subsidies',	'Deferred Taxation Liability Fund',	'Foreign Exchange Adjustments',	'Retained Earnings / [Loss]',	'Head Office Account',	'Minority Interest [Capital]',	'Share Application Money pending Allotment',	'FCCB Premium',	'Less : Calls in Arrears',	'Calls in Advance',	'Other Equity',	'Other Reserves',	'Total Shareholders Fund',	'Mortgage Loans',	'Long Term Loans : Secured',	'Long Term Loans : Unsecured',	'Long Term Loans : Hire Purchase',	'Long Term Borrowings from Financial Institutions [Secured]',	'Long Term Creditors and Borrowings',	'Long Term Bank Loans',	'Sales Tax Deferral Loans',	'Deferred Tax Liability',	'Long Term Notes Payable',	'Long Term Bills Payable ',	'Due to Parent [Long Term]',	'Due to Subsidiaries [Long Term]',	'Inter-company Loans [Long Term]',	'Due to Directors\ Shareholders \ Promoters [Long Term]','Due to Customers [Long Term]','Foreign Currency Convertible Bonds',	'Debentures and Bonds ',	'Public Deposits [Long Term]',	'Trade Deposits [Long Term]',	'Other Deposits [Long Term]',	'Security Deposits [Long Term]',	'Inter-office Adjustments [Long Term]',	'Minority Interests ',	'Provident and Pensions [Long Term]',	'Provisions',	'Deferred Income \ Deferred Liabilities',	'Mobilization Advance',	'Deferred Revenue Grants',	'Lease Liabilities [Long Term]',	'FCCB Premium [Long Term]',	'Other Non Current Liabilities',	'Less : Current Portion of Long Term Debt ',	'Total Non-Current Liabilities',	'Accounts Payable ',	'Creditors for Capital Goods',	'Acceptances',	'Bills Payable',	'Other Payables \ Accruals',	'Creditors and Borrowings',	'Deferred Income',	'Lease Liabilities',	'Notes Payable',	'Bank Overdraft',	'Loans : Secured',	'Loans : Unsecured',	'Loans : Hire Purchase',	'Borrowings from Financial Institutions [Secured]',	'Bank Loans',	'Current Portion of Long Term Debt',	'Debentures & Bonds[Short-Term]',	'Commercial Paper',	'Interest Accrued',	'Due to Customers',	'Due to Parent',	'Due to Subsidiaries',	'Inter Company Loans',	'Due to Directors \Shareholders \ Promoters',	'Public Deposits',	'Deposits from Corporates',	'Deposits from Shareholders',	'Trade Deposits',	'Other Deposits',	'Security Deposits',	'Inter Office Adjustments',	'Provident and Pensions',	'Unrealized Loss on Forward Exchange Contracts',	'Unclaimed \ Unpaid Dividends',	'Share Application Money pending Allotment [Current]',	'Provision for Income Tax',	'Provision for Fringe Benefit Tax',	'Provision for Wealth Tax',	'Provision for Retirement Benefits',	'Provision for Redemption of Debentures & Bonds',	'Provision for Dividends',	'Other Provisions',	'FCCB Premium [Short Term]',	'Calls received in Advance',	'Duties & Taxes Payable',	'bh_Deferred Taxation',	'Other Current Liabilities',	'Total Current Liabilities',	'Total Liabilities',	'Property Plant Machinery & Equipment',	'Land & Buildings',	'Plant & Equipment',	'Leasehold Land',	'Leasehold Improvements',	'Transportation Vehicles',	'Furniture Fixtures & Fitting',	'Office Equipment',	'Aircrafts \ Helicopters \ Ships \ Vessels',	'Computers \ Servers \Printers & other IT Equipment',	'CapitalWork in Progress',	'Transmission Lines & Cables',	'Laboratory Equipments',	'Land Rights',	'Asset Revaluation',	'Other Fixed Assets',	'Less Accumulated Depreciation',	'Total Fixed Assets',	'Deferred Revenue Expenditure',	'Goodwill',	'Trademark \ Copyright \ Patent',	'Preliminary Expenses',	'Miscellaneous Expenditure not written off',	'VRS Expenses not written off',	'Issue Expenses not written off',	'Technical Knowhow',	'Software',	'ProductDevelopment',	'Non Compete Fee',	'Landing Rights',	'Exploration Cost',	'Product Registrations',	'Data Access Fees',	'Preoperative Expenditure not written off',	'Other Intangibles',	'Total Intangibles',	'Investment in Subsidiaries',	'Investment in Group Companies \ Affiliates',	'Investment in Mutual Funds',	'Investment in Quoted Shares',	'Investment in Unquoted Shares',	'Investment in Shares ',	'Investment in Debentures \ Bonds',	'Investment in Government Securities',	'Investment in Joint Ventures and Partnerships',	'Investment in Approved Securities',	'Investment Properties',	'Other Investments',	'Less Provision for Diminution in Value of Investments',	'Total Investments',	'Deferred Tax Asset',	'Notes Receivable [Non Current]',	'Due from Parent [Non Current]',	'Due from Subsidiaries [Non Current]',	'Other Loans Receivable',	'Inter Company Loans [Other Assets]',	'Due from Directors \ Shareholders \ Promoters [Non Current]',	'Deferred Expenditure',	'Trade Deposits [Other Assets]',	'Other Deposits [Non Current]',	'Security Deposits [Non Current]',	'Development Properties',	'Other Assets',	'Total Other Assets',	'Cash & Bank',	'Cash',	'Balances with Bank',	'Remittances in Transit',	'Money at Call & Short Notice',	'Balance in Unclaimed Dividend Account',	'Fixed Deposit Account',	'Margin Deposit Account',	'Marketable Securities',	'Accounts Receivable',	'Notes Receivable',	'Other Receivables',	'Inventory',	'Inventory : Finished Goods',	'Inventory : Raw Material',	'Inventory : Work-in-Progress',	'Inventory : Trade Goods',	'Inventory : Others',	'Prepayments',	'Other Loans & Advances',	'Due from Parent',	'Due from Subsidiaries',	'Inter Company Loans \ Advances',	'Due from Directors \ Shareholders \ Promoters',	'Corporate Deposits [Current Assets]',	'Security Deposits [Current Assets]',	'Other Deposits [Current Assets]',	'Current Investments',	'TDS & Advance Tax [Net of Provisions]',	'Tax Refund',	'MAT Entitlement',	'Lease Rent Receivable',	'Claims Recoverable',	'CF_Deferred Taxation',	'Balance with Customs Port Trust And Excise Authorities',	'Inter-office Adjustment [Receivable]',	'Dividend Receivable',	'Interest Receivable',	'Unbilled Revenue',	'Other Current Assets','Total Current Assets','TOTAL ASSETS','Secured Loans','Unsecured Loans','Total','SectionID',]

                            duns_number = df1_transposed_BS['duns_no'].iloc[0]
                            dfBSAll = dfBSAll.append(df1_transposed_BS)
                            Status = "File Processed to CSV"
                            StatsList.append([duns_number,FileWithoutExtn,"BSCSV",Status,str(today) + "_" + str(logtime),
                                              "No Remarks"])
                        except Exception as ex:
                            logger.error("BS CSV Error")
                            Status = "File Not Processed for CSV"
                            StatsList.append([duns_number,FileWithoutExtn,"BSCSV",Status,str(today) + "_" + str(logtime),
                                              str(ex)])

                        '''read PL Worksheet into DataFrame'''
                        try:
                            df_PL = pd.read_excel(filename,sheet_name='PL-UPLOAD',index_col=None,na_values=['NA'],
                                                  usecols="G:I",nrows=167)
                            df_PL.columns = ['col1','col2','col3']
                            df1_transposed_PL = df_PL.T
                            df1_transposed_PL.columns = ['duns_no',
                                                         'Statement (End) Date',	'No of Months covered by P/L',
                                                         'Consolidated',	'Income\ Revenue\ Sales',
                                                         'Less: Direct Expenditure',
                                                         'Cost of Materials and Finished Goods Consumed',
                                                         'Purchases for Resale',
                                                         'Electricity \ Power and Fuel & Water Expenses',
                                                         'Sub Contract \ Job Work Charges',
                                                          'Plant & Machinery Repairs & Maintenance','Salaries & Wages',	'Royalty & Technical Fees',
                                                         'Transportation and Related Charges',	'Other Manufacturing Expenses',
                                                         'Plant \ Vehicle Hire Charges',	'Other Hire Charges',
                                                         'Aircraft \ Helicopters \ Vessels Repairs & Maintenance',	'Warehouse Expenses',
                                                         'Port & Survey Expenses',	'Dry Docking Expenses',	'Demurrage Charges',
                                                         'Landing Navigation and Other Airport Charges',	'Cost of Power Purchased',
                                                         'Wheeling and Transmission Charges Payable',	'Cost of Construction \ Construction Expenses',
                                                         'Freight Expenses [Direct]',	'Food & Beverages Consumed',	'Linen Room & Catering Supplies',
                                                         'Cost of Material Product Software and Hardware',
                                                         'Software Development and Business Process Management Expenses',
                                                         'Services Rendered By Business Associates and Others',	'Access Charges',
                                                         'Interconnect Charges',	'Exploration Cost',	'Education Training and Course Material',
                                                         'Provisions',	'Cost of Sales',	'Other Direct Expenditure',
                                                         'Add Capitalized Expenditure\Transfer To Deferred Revenue Expenditure',
                                                         'Free Field 1',	'Free Field 2',	'Free Field 3',	'Free Field 4',
                                                         'Gross Profit \ (Loss)',	'Add Other Operating Income',	'aP_Free Field 1',	'aQ_Free Field 2',
                                                         'Less TotalExpenditure',	'Less General & Administration Expenses',	'Staff Welfare Expenses',
                                                         'Insurance',	'Communication Expenses',	'Professional & Legal Fees',	'Technical Fees \ Charges',
                                                         'Repairs & Maintenance',	'Travelling & Conveyance Expenses',
                                                         'Staff Recruitment Expenses','Expenses towards Community Development & Donations',
                                                         'Directors''Remuneration & Fees',
                                                         'Partners''Remuneration','Security Charges',
                                                         'Consignment Fees',	'Lease \ Rent Charges',	'Petrol and Fuel Expenses',
                                                         'Internet and Spectrum Charges',	'Networking Charges',	'Other General Expenses',
                                                         'Preliminary Expenses written off',	'Add Rebate & Discount Received',	'Rebate and Penalties',
                                                         'Ao_Free Field 2',	'Less Selling & Distribution Expenses',	'Secondary Packaging',
                                                         'Advertising & Marketing Expenses',	'Business Promotion Expenses',
                                                         'Brokerage Discount& Commission',	'Freight Expenses',	'Technical Service Fees & Royalty',
                                                         'Market Research Expenses',	'Other Selling & Distribution Expenses',
                                                         'Less Employee Compensation Under ESOP',	'Less Loss on Sale of Fixed Assets',
                                                         'Less Loss on Sale of Investment',	'Less Loss on Foreign Exchange Transactions',
                                                         'Less Deferred Revenue Expenditure written off',
                                                         'Less Provision for Diminution in Value of Investments',	'Less Other Provisions',
                                                         'Less Bank & Finance Charges',	'Less Waiver of Interest',	'Less Bad Debts written off',
                                                         'Less Provision for Bad Debts',	'Less Other Expenses written off',
                                                         'Less Research & Development Expenditure',	'Less Claims for Loss & Damages',
                                                         'Less Loss on Redemption of Investments',	'Less Exploration Cost \ Survey Expenditure',
                                                         'Less Amortization of Premium on Contracts',	'Less Liquidated Damages',
                                                         'Less Depreciation \ Amortization & Depletion','Add Capitalized Expenditure \ Transfer to Deferred Revenue Expenditure - General Exp',
                                                         'AS_Free Field 1',	'AT_Free Field 2','Operating Profit','Add Other Non Operating Income',
                                                         'Dividend Income',	'Lease Rent & Hire Charges',	'Interest Income',
                                                         'Liabilities & Provisions Written Back','Profit on Sale of Fixed Assets',
                                                         'Profit on Sale of Investments',	'Profit on Foreign Exchange Transactions',
                                                         'Goodwill written back','Advances & Doubtful Debts written back',
                                                         'Unrealized Foreign Exchange Gain \ Loss',	'Provision For Tax Written Back',
                                                         'Provision in Value of Investments Written back','Insurance Claim Received',
                                                         'Income from Liquidated Damages',	'Revenue Grant',	'Surplus from Gas Pool Account',
                                                         'Prior Period Income','Premium on Investment in Shares',
                                                         'Profit from Joint Ventures \ Partnership Firms',	'Profit on Sale of Power \ Water',
                                                         'Income from Redemption of Securities',	'Income from Waiver of Interest',
                                                         'Refund of Tax & Duties',	'Miscellaneous Income',	'Earnings Before Interest & Tax [EBIT]',
                                                         'Less Interest Expenditure',	'Interest on Short Term Loans',	'Interest on Long Term Loans',
                                                         'Interest on Deposits',	'Interest on Loans & Advances','Interest on Capital',
                                                         'Other Interest',	'Profit Before Tax & Extraordinary Items',	'BF_Add \ Less Extraordinary Items',
                                                         'Less Prior Period Expenditure',	'Net Profit Before Taxation & After Extraordinary Items',
                                                         'Less Total Tax Provision',	'Tax Provision','Wealth Tax','Fringe Benefit Tax',
                                                         'Less \ Add Current Year Deferred Tax',	'Other Tax',	'Profit After Tax',
                                                         'Add \ Less Extraordinary Items','Extraordinary Items : Assets',
                                                         'Extraordinary Items : Income Tax',	'Extraordinary Items : Divestiture',
                                                         'Extraordinary Items : Others',	'Profit After Tax & Extraordinary Items',
                                                         'Prior Year Adjustment',	'Less Minority Interests',	'Less Dividends and Transfer to Reserves',
                                                         'Less Dividends',	'Less Bonus Issue from Accumulated Profits',	'Transfer to Reserves',
                                                         'Transfer to \ from Head Office Account','Plus \ [Minus] Retained Earnings \ [Loss] b/f',
                                                         'Transfer From Reserves',	'Retained Earnings \ [Loss] c/f',
                                                         'Currency Type',	'Units of Size','SectionId']
                            dfPLAll = dfPLAll.append(df1_transposed_PL)
                            Status = "File Processed to CSV"
                            StatsList.append([duns_number,FileWithoutExtn,"PLCSV",Status,str(today) + "_" + str(logtime),
                                              "No Remarks"])
                        except Exception as ex:
                            logger.error("PL CSV Error")
                            Status = "File Not Processed for CSV"
                            StatsList.append([duns_number,FileWithoutExtn,"PLCSV",Status,str(today) + "_" + str(logtime),
                                              str(ex)])

                        # Read Fiscal Data into Dataframe
                        try:
                            df_Fiscal = pd.read_excel(filename,sheet_name='FISCAL-UPLOAD',index_col=None,na_values=['NA'],
                                                  usecols="G:I",nrows=274)
                            df_Fiscal.columns = ['col1','col2','col3']
                            df1_transposed_Fiscal = df_Fiscal.T
                            df1_transposed_Fiscal.columns = ['duns_no',	'Update Date',	'Statement Date',
                                                             'Statement Type',	'Consolidated ?',	'Unit of Size (000''s)',
                                                             'Currency',	'From (Month)',	'To (Month)',
                                                             'Only Print Total Assets/Liabs',	'Cash',	'BN_Cash & Bank',
                                                             'Marketable Securities',	'BP_Inventory',	'Raw Materials',
                                                             'Work in Progress',	'Deposit-Short Term',
                                                             'BT_Accounts Receivable',	'BU_Notes Receivable',
                                                             'Provision for Bad Debts',	'Other Receivables / Accruals',
                                                             'Prepayments',	'BX_Due from Parent',	'BY_Inter-Company Loans',
                                                             'BZ_Due from Directors / Shareholders',	'Loans & Advances',
                                                             'Investments',	'CC_Deferred Taxation',	'Tax Refund',
                                                             'Other Current Assets',	'CF_Free Text',	'CG_Amount',
                                                             'CH_Free Text',	'CI_Amount',	'QC_Suppress section sub-total?',
                                                             'Property Plant & Equipment',	'Land & Buildings',
                                                             'Leasehold Improvements',	'Plant & Equipment',
                                                             'Transportation Vehicles',	'Furniture Fixtures & Fitting',
                                                             'Office Equipment',	'Assets in Construction',
                                                             'Land Rights',	'Asset Revaluation',
                                                             'Less Acc. Depreciation',	'Other Fixed Assets',
                                                             'Fixtures and Equipment',	'Furniture and Vehicles',
                                                             'CX_Free Text',	'CY_Amount',	'CZ_Free Text',
                                                             'DA_Amount',	'QD_Suppress section sub-total?',
                                                             'Investment in Subsidiary',	'Investment in Affiliates',
                                                             'Investment',	'Shares (Listed)',	'Shares (Unlisted)',
                                                             'Shares',	'Investment Properties',	'Other Investments',
                                                             'DK_Free Text',	'DL_Amount',	'DM_Free Text',
                                                             'DN_Amount',	'QE_Suppress section sub-total?',
                                                             'DQ_Notes Receivable',	'DR_Due from Parent',
                                                             'DS_Inter-Company Loans',	'DT_Due from Directors / Shareholders',
                                                             'PZ_Deferred Expenditure',	'Long-Term Deposits',
                                                             'Long-Term Loans',	'Development Properties',
                                                             'Other Assets',	'DV_Free Text',	'DW_Amount',
                                                             'DX_Free Text',	'DY_Amount',	'QF_Suppress section sub-total?',
                                                             'Intangibles',	'Goodwill',
                                                             'Trademark / Copyright / Patent',	'PT_Deferred Expenditure',
                                                             'Exploration Cost',	'Pre-operative expenses',
                                                             'Other Intangibles',	'EF_Free Text',	'EG_Amount',
                                                             'EH_Free Text',	'EI_Amount',
                                                             'QG_Suppress section sub-total?',	'EN_Accounts Payable',
                                                             'EO_Notes Payable',	'Bank Overdraft',
                                                             'EQ_Loans Hire Purchase',	'ER_Loans Secured',
                                                             'Loans Unsecured',	'ET_Bank Loans',
                                                             'Creditors & Borrowings',
                                                             'Current Portion of Long Term Debt',
                                                             'EW_Debentures & Bonds',	'EX_Due to Customers',
                                                             'Other Payables / Accruals',	'Prov. Income Tax',
                                                             'Prov. Dividends',	'FB_Provisions',
                                                             'FC_Due to Parent',	'FD_Inter-Company Loans',
                                                             'FE_Due to Directors / Shareholders',	'FF_Lease Liabilities',
                                                             'FG_Deferred Taxation',	'Deferred Income',
                                                             'FI_Provident & Pensions',	'Other Current Liabilities',
                                                             'FK_Free Text',	'FL_Amount',	'FM_Free Text',
                                                             'FN_Amount',	'QH_Suppress section sub-total?',
                                                             'Creditors and Borrowings',	'Mortgages',
                                                             'FS_Loans Secured',	'FT_Loans Unsecured',
                                                             'FU_Loans Hire Purchase',	'FV_Bank Loans',
                                                             'GE_Debentures & Bonds',	'FW_Deferred Taxation',
                                                             'Deferred Income/ Deferred Liabilities',	'FX_Provisions',
                                                             'FZ_Provident & Pensions',	'GA_Notes Payable',
                                                             'Bills Payable',	'GB_Due to Parent',
                                                             'GC_Inter-Company Loans',	'GD_Due to Directors / Shareholders',
                                                             'PV_Due to Customers',	'PW_Lease Liabilities',
                                                             'FY_Minority Interests',	'Other Non-Current Liabilities',
                                                             'GG_Free Text',	'GH_Amount',	'GI_Free Text',
                                                             'GJ_Amount',	'QI_Suppress section sub-total?',
                                                             'Capital',	'Capital Reserves',	'General Reserves',
                                                             'Legal Reserves',	'Reserves',	'Share Premium',
                                                             'Head Office Account',	'Revaluation Surplus (deficit)',
                                                             'Surplus (Deficit)',	'Foreign Exchange Adjustments',
                                                             'Retained Earnings (loss)',	'Minority Interest',
                                                             'Other Equity',	'GY_Free Text',	'GZ_Amount',
                                                             'HA_Free Text',	'HB_Amount',	'# Months covered by P/L?',
                                                             'P/L Statement (End) Date',	'HR_Statement Type',
                                                             'HS_Consolidated?',	'HT_Unit of Size (000''s)',
                                                             'HU_Currency',	'Sales Type',	'hy_Amount',
                                                             'Less: Cost of Sales',	'Other operating income',
                                                             'Total expenditure',	'Services',	'Employee Cost / Payroll',
                                                             'Selling & Administration Exp.',	'Depreciation/Amortisation',
                                                             'General operating expenses',
                                                             'Net Operating Profit (Loss) after depn and Before interest',
                                                             'Other Non-operating Income',	'Total finance expenses',
                                                             'Profit Before Extraordinary Items and Tax - India only',
                                                             'OJ_Plus(Minus) Extraordinary Items',
                                                             'Net Profit Before Taxation & After Extraordinary Items',
                                                             'Income Tax',	'Net Profit after Tax Type',	'ih_Amount',
                                                             'II_Plus(minus) Extraordinary Items',
                                                             'Extraordinary Items - Assets',
                                                             'Extraordinary Items - Income Tax',
                                                             'Extraordinary Items - Divestiture',
                                                             'Extraordinary Items - Others',
                                                             'Net Profit (Loss) After Taxation & Extraordinary Items',
                                                             'IN_Minority Interests',	'Less: Dividends & Transfers to Reserves',	'Less: Dividends',
                                                             'Less: Transfer to Reserves',	'Less: Transfer to Head Office Account',	'Prior Year Adjustments',
                                                             'Plus(-) Retained Earnings b/f',	'Transfer from reserve to retained earnings',
                                                             'Retained Earnings (Loss) C/F',	'Earnings (Loss) per Share',	'Diluted?',	'Average employees',
                                                             'Directors remuneration',	'By current person interviewed?',	'Date:',	'Statement End Date',
                                                             'Subject',	'Name',	'JK_Position Qualifier',	'Type',	'Title',	'Function',
                                                             'of Company (if NOT subject)',	'Submission Method',	'B/S Obtained from Informants',
                                                             'Statement Prepared by Accountant',	'Name of Accountant',	'F/S have been Prepared',
                                                             'ON A GOING CONCERN BASIS',	'Assuming support of',
                                                             'A/C give a True & Fair View',	'A/Cs Obtained From',	'Annual Report Signed by',
                                                             'J2_Position Qualifier',	'J3_Position Area',	'Position Title',	'J5_Position Area',
                                                             'Audited / Unaudited ?',	'Auditor',	'Auditor (not in list)',
                                                             'Accounts qualified by auditor?',	'Qualifications / Disclaimers',	'Qualifications (Cont''d)',
                                                             'Sales Trend',	'Reason1:',	'Reason2:',	'Free Text Reason',	'LX_Free Text Reason',
                                                             'Net Profit Trend',	'MB_Reason1:',	'Current Yr - % Bad Debt Provision',
                                                             'Prior Yr - % Bad Debt Provision',	'MD_Reason2:',	'ME_Free Text Reason:-',
                                                             'MF_Free Text Reason:-',	'Net Worth Trend',	'MJ_Reason1:',	'Capital Change:  From',
                                                             'Capital Change:  To',	'MM_Currency',	'MN_Reason2:',
                                                             'MP_Free Text Reason:','MQ_Free Text Reason:','Statement (End) Date','OU_Statement Type','OV_Consolidated?','OW_Unit of Size (000''s)',
                                                             'OX_Currency','QU_From (month)','QV_To (month)','Current Assets',
                                                             'Current Liabilities','Other Tangible Assets',
                                                             'Non-Current Liabilities','PF_Cash & Bank','PG_Accounts Receivable',
                                                             'Fixed Assets','PI_Accounts Payable',
                                                             'PJ_Inventory','SectionId']

                            dfFiscalAll = dfFiscalAll.append(df1_transposed_Fiscal)
                            Status = "File Processed to CSV"
                            StatsList.append([duns_number,FileWithoutExtn,"FiscalCSV",Status,str(today) + "_" + str(logtime),
                                              "No Remarks"])
                        except Exception as ex:
                            logger.error("Fiscal CSV Error")
                            Status = "File Not Processed for CSV"
                            StatsList.append([duns_number,FileWithoutExtn,"FISCALCSV",Status,str(today) + "_" + str(logtime),
                                              str(ex)])

                        # # Read Cash Flow into Dataframe
                        try:
                            df_CashFlow = pd.read_excel(filename,sheet_name='CASHFLOW-UPLOAD',index_col=None,na_values=['NA'],
                                                      usecols="F:G",nrows=78)
                            df_CashFlow.columns = ['col1','col2']
                            df1_transposed_CashFlow = df_CashFlow.T
                            df1_transposed_CashFlow.columns = ['Duns_No',	'Update Date',
                                                               'Statement Type','Statement Date',
                                                               'Number of Months',	'Unit of Size (000''s)',
                                                               'Currency',	'Net profit before tax & extra ordinary items',
                                                               'Depreciation and amortisation',	'Finance costs',
                                                               'Interest income',	'Dividend income',
                                                               'Loss/(Profit) on Sale of Investments',
                                                               'Loss/(Profit) on Sale of Assets',
                                                               'Unrealised foreign exchange (gain)/loss',
                                                               'Employee share-based payment expenses',
                                                               'Free Fields_bp','Amount_dl',
                                                               'Free Fields_dv',	'Amount_dw',
                                                               'Free Fields_dx',	'Amount_dy',
                                                               'Subtotal ',
                                                               'Operating profit before working capital changes',
                                                               'Decrease/(Increase) in Inventories',
                                                               'Decrease/(Increase) in Trade Receivable',
                                                               'Decrease/(Increase) in Other Receivables',
                                                               '(Decrease)/Increase in Trade and Other Payables',
                                                               '(Decrease)/Increase in Provision',
                                                               '(Decrease)/Increase in current Liabilites',
                                                               'Free Field_bz',	'Amount_dm','Free Field_ca',
                                                               'Amount_dn','Free Field_cb','Amount_do',
                                                               'Working Capital Adjustments',
                                                               'Cash Generated from Operations',
                                                               'Income Tax Paid',
                                                               'Cash Generated from Operating Activities',
                                                               'Purchase of Property Plant and Equipment Intangibles/Capital Work-in-Progress',
                                                               'Proceeds from sale of Property Plant and Equipment','Purchase of Investment in Subsidiaries',
                                                               'Proceeds from sale of Investments in Associate','Purchase of Current Investments',
                                                               'Proceeds from sale of Current Investments',	'Interest Received','Dividend Received',
                                                               'Rent Received',	'Inter-Corporate Deposits Repaid',
                                                               'Loans (given to)/Repaid by Subsidiaries/Others (net)',	'Free Field_cr','Amount_dp',
                                                               'Free Field_cs','Amount_dq','Free Field_ct','Amount_dr',
                                                               'Net Cash Flow used in Investing Activities','Proceeds from Issue of Equity Shares',
                                                               'Proceeds from Borrowings','Repayments of Borrowings','Proceeds from Short Term Borrowings',
                                                               'Repayments of Short Term Borrowings','Dividend Paid','Tax paid on dividend',	'Interest paid',
                                                               'Free Field_dd','Amount_ds','Free Field_de','Amount_dt',	'Free Field_df','Amount_du',
                                                               'Cash Generated from Financing Activities','Net Increase in cash & cash equivalents',
                                                               'Cash & Cash equivalents (opening balance)','Foreign Exchange Difference in Cash and Cash Equivalents',
                                                               'Cash & Cash equivalents (closing balance)','Sectionid']
                            # 'Sectionid'
                            # df1_transposed = df1_transposed.iloc[: ,1:]

                            dfCashflowAll= dfCashflowAll.append(df1_transposed_CashFlow)
                            Status = "File Processed to CSV"
                            StatsList.append([duns_number,FileWithoutExtn,"CashflowCSV",Status,str(today) + "_" + str(logtime),
                                              "No Remarks"])
                        except Exception as ex:
                            logger.error("Cashflow CSV Error")
                            Status = "File Not Processed for CSV"
                            StatsList.append([duns_number,FileWithoutExtn,"CashflowCSV",Status,str(today) + "_" + str(logtime),
                                              str(ex)])
                        t1 = time.time()
                        elapsed = time.strftime("%H:%M:%S %Z",time.gmtime(t1 - t0))
                    else:
                        t1 = time.time()
                        Status = "File Not Processed"
                        elapsed = time.strftime("%H:%M:%S %Z", time.gmtime(t1 - t0))
                        StatsList.append(
                            [duns_number,FileWithoutExtn,"All Files",Status,str(today) + "_" + str(logtime),
                             "DUNS Number zero or null or length not equal to 9"])

                except Exception as ex:
                    Status = 'File Not Processed'
                    StatsList.append([duns_number,FileWithoutExtn,elapsed,Status,str(today)+"_"+str(logtime),
                                      str(ex)])
                    logger.error(filename)
                    # os.remove( InPutFilesFinancial["InPutFilesFinancial"] + filename)
                    logger.error(str(ex))
                    continue
            logger.info("Process Completed")
            dfPLAll.to_csv(OutPutFileFinancial['OutPutFileFinancial'] + "output_PL_TokenNumber.csv",index=False)
            dfBSAll.to_csv(OutPutFileFinancial['OutPutFileFinancial'] + "output_BS_TokenNumber.csv",index=False)
            dfFiscalAll.to_csv(OutPutFileFinancial['OutPutFileFinancial'] + "output_Fiscal_TokenNumber.csv",index=False)
            dfCashflowAll.to_csv(OutPutFileFinancial['OutPutFileFinancial'] + "output_Cashflow_TokenNumber.csv",
                                           index=False)
            # Upload CSV Files to Sharepoint
            MessageUploadOutput = self.SharepointOperation\
                ("Upload File",OutPutFileFinancial["OutPutFileFinancial"] + "output_PL_TokenNumber.csv",
                 logger,"CSV")
            if (MessageUploadOutput == "File uploaded"):
                logger.info("CSV files have been uploaded to sharepoint")

            cnopts = pysftp.CnOpts()
            cnopts.hostkeys = paramiko.hostkeys.HostKeys(r'C:\Users\shethd\.ssh\known_hosts')
            hostName = "mftweb.dnb.com"
            # hostName = "ftp.dnb.com"
            userName = "BLT356_tes"
            # userName = "BLT356_test"
            # pswd = "DUNS@1b2c3z4"
            pswd = "DUNS@1b2c3z"

            try:
                with pysftp.Connection(host=hostName, username=userName,
                                       password=pswd, cnopts=cnopts) as sftp:
                    try:
                        logger.info("Connection established ... ")

                        with sftp.cd("/puts/"):
                            # print(sftp.listdir())
                            try:
                                # # Use put method to upload a file
                                # First trasfer all delete files
                                for file in os.listdir(Outputdirectory):
                                    try:
                                        if not file.endswith(".csv"):
                                            continue
                                        if 'Delete' in file:
                                            sftp.put(os.path.join(Outputdirectory, file), confirm=False)
                                            # ,  confirm = False
                                            FTPStats.append(
                                                [file, "FTP Transfer Successfull", str(today) + "_" + str(logtime),
                                                 "No Remarks"])
                                            time.sleep(1)
                                            os.remove(os.path.join(Outputdirectory, file))
                                    except Exception as ex:
                                        logger.error(str(ex))
                                        FTPStats.append(
                                            [file, "FTP Transfer Failed", str(today) + "_" + str(logtime),
                                             str(ex)])
                                        continue
                                # second trasfer all Insert files
                                for file in os.listdir(Outputdirectory):
                                    try:
                                        if not file.endswith(".csv"):
                                            continue
                                        if 'Delete' not in file:
                                            sftp.put(os.path.join(Outputdirectory, file), confirm=False)
                                            # ,  confirm = False
                                            FTPStats.append(
                                                [file, "FTP Transfer Successfull", str(today) + "_" + str(logtime),
                                                 "No Remarks"])
                                            time.sleep(1)
                                            os.remove(os.path.join(Outputdirectory, file))
                                    except Exception as ex:
                                        logger.error(str(ex))
                                        FTPStats.append(
                                            [file, "FTP Transfer Failed", str(today) + "_" + str(logtime),
                                             str(ex)])
                                        continue

                            except Exception as ex:
                                logger.error(str(ex))
                    except Exception as ex:

                        logger.error(str(ex))
                        FTPStats.append(
                            [file, "FTP Transfer Failed", str(today) + "_" + str(logtime),
                             str(ex)])

            except Exception as ex:
                logger.error("Connection Not established ... ")
                logger.error(str(ex))
                FTPStats.append(
                    ["Connection Not established ...", "FTP Transfer Failed", str(today) + "_" + str(logtime),
                     str(ex)])
                # Load stats file

            self.CreateStats(logger, AutoFinancialObj, StatsList, FTPStats)


        except Exception as ex:
            logger.error(str(ex))

    def CreateStats(self, logger, AutoFinancialObj, StatsList, FTPList):

        global Stats, ValidationStats, FTPStatdf
        # global FTPStatdf
        FTPStatdf = pd.DataFrame()
        Stats = pd.DataFrame()
        Outputdirectory = OutPutFilesReportToDews["OutPutFilesReportToDews"]
        try:
            book = load_workbook(Outputdirectory + 'AutoReportToDews_Stats.xlsx')
            DFSharepointFolderStatus = pd.concat([AutoFinancialObj.DFSharepointFolderDetails])
            DFSharepointFolderStatus.columns = ['Folder Name',  'File Count',  'Folder Status',  'ProcessedDateTime',
                                                'File download Count']
            Stats = Stats.append(pd.DataFrame(StatsList,  columns=['DUNS Number',  'File Name',  'WorkSheet Name',  'Status',
                                                                  'Processed Date',  'Remarks']),  ignore_index=True)
            FTPStatdf = FTPStatdf.append(
                pd.DataFrame(FTPList,  columns=['File Name',  'Status',  'Processed Date',  'Remarks']),  ignore_index=True)

            writer = pd.ExcelWriter(Outputdirectory + 'AutoReportToDews_Stats.xlsx',
                                    engine='openpyxl')
            writer.book = book
            writer.sheets = {ws.title: ws for ws in book.worksheets}

            with writer:
                Stats.to_excel(writer,  sheet_name='CSV File log',
                               startrow=writer.sheets['CSV File log'].max_row,
                               index=False,  header=False)
                FTPStatdf.to_excel(writer,  sheet_name='FTP Stats',
                                   startrow=writer.sheets['FTP Stats'].max_row,
                                   index=False,  header=False)
                DFSharepointFolderStatus.to_excel(writer,  sheet_name='SharePoint Folder Stats',
                                                  startrow=writer.sheets['SharePoint Folder Stats'].max_row,
                                                  index=False,  header=False)

            book.save(Outputdirectory + 'AutoReportToDews_Stats.xlsx')
            book.save(Outputdirectory + 'AutoReportToDews_Stats_' + str(today) + '.xlsx')

            # Filtering Todays for Sharepoint Upload

            File_Stats_Today = pd.read_excel(Outputdirectory + 'AutoReportToDews_Stats_' + str(today) + '.xlsx',
                sheet_name='CSV File log',  engine='openpyxl')
            if not File_Stats_Today.empty:
                File_Stats_Today = File_Stats_Today.dropna()
                File_Stats_Today = File_Stats_Today.loc[
                    File_Stats_Today['Processed Date'].str.contains(r'^{}*'.format(str(today)),  regex=True)]
            Folder_Stats_Today = pd.read_excel(Outputdirectory + 'AutoReportToDews_Stats_' + str(today) + '.xlsx',
                sheet_name='SharePoint Folder Stats',  engine='openpyxl')
            if not Folder_Stats_Today.empty:
                Folder_Stats_Today=Folder_Stats_Today.dropna()
                Folder_Stats_Today = Folder_Stats_Today.loc[
                    Folder_Stats_Today['ProcessedDateTime'].str.contains(r'^{}*'.format(str(today)),  regex=True)]

            FTP_Stats_Today = pd.read_excel(
                Outputdirectory + 'AutoReportToDews_Stats_' + str(today) + '.xlsx',
                sheet_name='FTP Stats',  engine='openpyxl')
            if not Folder_Stats_Today.empty:
                FTP_Stats_Today = FTP_Stats_Today.loc[
                    FTP_Stats_Today['Processed Date'].str.contains(r'^{}*'.format(str(today)),  regex=True)]

            with pd.ExcelWriter(
                    Outputdirectory + 'AutoReportToDews_Stats_' + str(today) + '.xlsx',
                    engine='xlsxwriter') as writer:
                File_Stats_Today.to_excel(writer,  sheet_name='CSV File log',  index=False)
                Folder_Stats_Today.to_excel(writer,  sheet_name='SharePoint Folder Stats',  index=False)
                FTP_Stats_Today.to_excel(writer,  sheet_name='FTP Stats',  index=False)

            MessageUploadOutput = self.SharepointOperation("Upload File", Outputdirectory + 'AutoReportToDews_Stats_' + str(
                                                               today) + '.xlsx',
                                                           logger,  "LOGSorSTATS")
            if (MessageUploadOutput == "File uploaded"):
                logger.info("Output file has been uploaded to sharepoint")
                # os.remove(os.path.join(Outputdirectory,
                #                        'AutoReportToDews_Stats_' + str(today) + '.xlsx'))

        except Exception as ex:
            logger.error("Stats Error")
            logger.error(str(ex))

def main():
    # Defining Variables
    global logtime, today
    # Dataframe that stores Job running details
    jobhistory = pd.DataFrame()

    # Object creation for Logging module and Email class
    loggerObj = Logs()
    mailobj = mail()
    # Define time to set in the log file name
    logtime = str(datetime.now().strftime('%H_%M_%S'))
    today = date.today().strftime('%d_%m_%Y')
    # define the file name
    logfilename = "NonFinancialUpload.txt"
    logger = loggerObj.setup_logger('NonFinancialUpload_', LogFileFinancial["LogFileFinancial"] + logfilename)
    # logger.info("Process started = > Insert Query ")
    # OutputPath = ""
    LogPath = settings_ReportToDews.get('team_site_url') + '/Shared%20Documents/CCAM/Logs_Stats/' + \
              logfilename
    try:
        Obj1 = AutoFinancial()

        # data = [
        #     {'RunBy': 'AUTO','OutputFilePath': OutputPath,'LogPath': LogPath,'RunDuration': str(ProcessStartTime),
        #      'JobStatus': str('Running')}]
        # jobhistory = jobhistory.append(data,ignore_index=True)
        # Obj1.ManageSQLConnection(jobhistory,logger,"Insert")

        ProcessStartTime = time.time()
        Obj1.AutoFinancialProcess(logger)
        ProcessEndTime = time.time()

        TotalElapsedTime = time.strftime("%H:%M:%S %Z",time.gmtime(ProcessEndTime - ProcessStartTime))

        if not Stats.empty:

            df = Stats["Status"].value_counts()
            try:
                DataFound = [df.at['File Processed']]
            except Exception as ex:
                if str(ex) == "File Not Processed":
                    DataFound = [0]
            try:
                DataNotFound = [df.at['File Not Processed']]
            except Exception as ex:
                if str(ex.args).strip() == '(\'File Not Processed\',)':
                    DataNotFound = [0]

            try:
                details = {
                    "Total Files Run": [Stats.shape[0]],
                    "Success Files": DataFound,
                    "Failed Files": DataNotFound,
                    "Processed DateTime": [date.today().strftime('%d_%m_%Y')],
                    "Run By": 'Auto Trigger Process',
                    "Total Execution Time": str(TotalElapsedTime)
                }
            except Exception as ex:
                details = {
                    "Total Files Run": [Stats.shape[0]],
                    "Success Files": DataFound,
                    "Failed Files": DataNotFound,
                    "Processed DateTime": [date.today().strftime('%d_%m_%Y')],
                    "Run By": 'Auto Trigger Process',
                    "Total Execution Time": str(TotalElapsedTime)
                }

            # creating a Dataframe object with skipping
            # one column i.e skipping age column.
            df_stats = pd.DataFrame(details)

            output = build_table(df_stats,'orange_light',font_size='15px',text_align='center',width='auto',
                                 font_family='Open Sans,sans-serif')
            # send email only if files have failed in conversion
            if (DataNotFound !=[0]):
                mailobj.SendEmailToStakeHolders("Auto Financial Upload Status","DNBSystemMailDoNotReply@dnb.com",
                                                "shethd@dnb.com",output,"Financial Upload",LogPath)

            logger.info(f"{TotalElapsedTime} seconds to to process and upload all Auto Financial files")

            MessageUploadLog = Obj1.SharepointOperation("Upload File",
                                                        LogFileFinancial["LogFileFinancial"] + logfilename,
                                                        logger,"LOGS")

            if (MessageUploadLog == "File uploaded"):
                logger.info("log file has been uploaded to sharepoint")

            OutputPath = "No Output Path"
            # data = [{'RunBy': 'AUTO','OutputFilePath': OutputPath,'LogPath': LogPath,
            #          'RunDuration': str(TotalElapsedTime),'JobStatus': str('Success')}]
            # jobhistory = jobhistory.append(data,ignore_index=True)
            # Obj1.ManageSQLConnection(jobhistory,logger,"Update")
            print(f"{TotalElapsedTime} seconds to process and upload all Auto Financial files")
        else:
            OutputPath = "No Output Path"
            output = ""
            mailobj.SendEmailToStakeHolders("No Files to Process","DNBSystemMailDoNotReply@dnb.com",
                                            "shethd@dnb.com",output,"Financial Upload",LogPath)
            logger.info(f"{TotalElapsedTime} seconds to process and upload all Auto Financial files")

            MessageUploadLog = Obj1.SharepointOperation("Upload File",
                                                        LogFileFinancial["LogFileFinancial"] + logfilename,
                                                        logger,"LOGS")

            if (MessageUploadLog == "File uploaded"):
                logger.info("log file has been uploaded to sharepoint")

            OutputPath = "No Data"

            # data = [{'RunBy': 'AUTO','OutputFilePath': OutputPath,'LogPath': LogPath,
            #          'RunDuration': str(TotalElapsedTime),'JobStatus': str('Not Run')}]
            # jobhistory = jobhistory.append(data,ignore_index=True)
            # Obj1.ManageSQLConnection(jobhistory,logger,"Update")

    except Exception as ex:
        logger.error(str(ex))
        mailobj.SendEmailToStakeHolders("Auto Financial upload ERROR ","DNBSystemMailDoNotReply@dnb.com",
                                        "shethd@dnb.com",str(ex),"Financial Upload",LogPath)

if __name__ == '__main__':
    main()
    quit()

    # Upload files to FTP
    # cnopts = pysftp.CnOpts()
    # cnopts.hostkeys = None

    # loop through the csv output folder to move all the files to ftp

    # hostName = "ftp.dnb.com"
    # userName = "UBLT356IT"
    # pswd = "P@ssW0rd@1234"
    #
    # with pysftp.Connection(host=hostName,username=userName,
    #                        password=pswd) as sftp:
    #     # localpath = r"C:\Users\shethd\OneDrive - Dun and Bradstreet\Dipti_C\Dipti\Stash_Code_Repository\DNBDataIngestSQL\PyDocParser\OutputFiles\Financial\output_BS_TokenNumber.csv"
    #     # remotepath = "output_BS_TokenNumber.csv"
    #     print(sftp.listdir())
    #     # sftp.put(localpath,remotepath)
    #     with sftp.cd("/puts/"):
    #         print(sftp.listdir())
    #         try:
    #             # localFilePath = r"C:\Users\shethd\OneDrive - Dun and Bradstreet\Dipti_C\Dipti\Stash_Code_Repository\DNBDataIngestSQL\PyDocParser\OutputFiles\Financial\Test.txt.txt"
    #             # # Define the remote path where the file will be uploaded
    #             # remoteFilePath = "uploaded.txt"
    #             # # Use put method to upload a file
    #             for file in os.listdir(Outputdirectory):
    #                 try:
    #                     if not file.endswith(".csv"):
    #                         continue
    #                     sftp.put(os.path.join(Outputdirectory,file),confirm=False)
    #                     time.sleep(25)
    #                 except Exception as ex:
    #                     logger.error(str(ex))
    #             print(sftp.listdir())
    #         except Exception as ex:
    #             logger.error(str(ex))

    # sftp.put(localFileLoc)
    # with pysftp.Connection(host=hostName,username = userName,password=pswd) as serv_details:
    #     print("Connection established ... ")
    # remoteFileLoc = '/binary'

    # serv_details.put(remoteFileLoc,localFileLoc)
    # serv_details.close()

    # Upload files to FTP
# Load stats file
            # book = load_workbook(OutPutFileFinancial["OutPutFileFinancial"] + 'AutoFinancial_Stats.xlsx')
            # writer = pd.ExcelWriter(OutPutFileFinancial["OutPutFileFinancial"] + 'AutoFinancial_Stats.xlsx',
            #                         engine='openpyxl')
            # writer.book = book
            # writer.sheets = {ws.title: ws for ws in book.worksheets}
            #
            # DFSharepointFolderStatus = pd.concat(
            #     [AutoFinancialObj.DFSharepointFolderDetails])
            # # DFSharepointFolderStatus.to_excel(writer,sheet_name='Folder Stats')
            # DFSharepointFolderStatus.columns = ['Folder Name','File Count','Folder Status','ProcessedDateTime','File download Count']
            # DFSharepointFolderStatus.to_excel(writer,sheet_name='Folder Stats',
            #                                   startrow=writer.sheets['Folder Stats'].max_row,
            #                                   index=False,header=False)
            # Stats = Stats.append(pd.DataFrame(StatsList,columns=['DUNS Number','File Name','File Type','Status',
            #                                            'Processed Date','Remarks']),ignore_index=True)
            # Stats.to_excel(writer,sheet_name='File Stats',
            #                                   startrow=writer.sheets['File Stats'].max_row,
            #                                   index=False,header=False)
            #
            # writer.save()
            # book.save(OutPutFileFinancial["OutPutFileFinancial"] + 'AutoFinancial_Stats.xlsx')
            # MessageUploadOutput = self.SharepointOperation("Upload File",
            #                                                OutPutFileFinancial["OutPutFileFinancial"] + 'AutoFinancial_Stats.xlsx',
            #                                                logger,"LOGS")
            # if (MessageUploadOutput == "File uploaded"):
            #     logger.info("Output file has been uploaded to sharepoint")