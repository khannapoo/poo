import datetime
import logging
class PyDocParser:

    def __init__(self ,name ,requestor ,business ,startdate ,runduration ,logurl ,statsurl ):
        self._name = name
        self._requestor = requestor
        self._business = business
        self._startdate = startdate
        self._runduration = runduration
        self._logurl = logurl
        self._statsurl = statsurl

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        assert isinstance(value,str),"Enter valid name of the process"
        self._name = value

    @property
    def business(self):
        return self._business

    @business.setter
    def business(self, value):
        assert isinstance(value, str), "Enter valid name of the Business"
        self._business = value

    @property
    def startdate(self):
        return self._startdate

    @startdate.setter
    def startdate(self, value):
        assert datetime.datetime.strptime(value,'%d-%m-%Y'), "Incorrect data format, should be DD-MM-YYYY"
        self._startdate = value

    @property
    def runduration(self):
        return self._runduration

    @runduration.setter
    def runduration(self, value):
        self._runduration = value

    @property
    def logurl(self):
        return self._logurl

    @logurl.setter
    def logurl(self, value):

        self._logurl = value

    @property
    def statsurl(self):
        return self._statsurl

    @statsurl.setter
    def statsurl(self, value):
        self._statsurl = value

    def setup_logger(self,level=logging.DEBUG):
        # logging.basicConfig(logger_name,format='[%(asctime)s] [%(filename)s:%(lineno)s - %(funcName)20s()] %(levelname)s - %(message)s',datefmt='%m-%d %H:%M:%S',filemode='a',level="INFO")
        # Create logger object
        logger = logging.getLogger(self.name)
        today = datetime.date.today().strftime('%d_%m_%Y')
        # format the log output
        formatter = logging.Formatter(
            '[%(asctime)s] [%(filename)s:%(lineno)s - %(funcName)20s()] %(levelname)s - %(message)s',
            datefmt='%m-%d %H:%M:%S')

        # Create file handler
        fileHandler = logging.FileHandler(str(self.name)+today+".txt", mode='a')
        streamHandler = logging.StreamHandler()
        # Set the Formatter
        fileHandler.setFormatter(formatter)
        streamHandler.setFormatter(formatter)

        logger.setLevel(level)
        logger.addHandler(fileHandler)
        logger.addHandler(streamHandler)

        return logger


    # Attributes
    # processname
    # requestor
    # business
    # startdate
    # totalduration
    # logurl
    # statsurl
